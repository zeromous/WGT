#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wgtprn.c                                           
  Contains:     wgtprintf                                          
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter     Windows 95 Version               
*/



/*
  Prints a string at xloc,yloc using the font wgtprfon.  Takes     
  format parameters the same as printf, making it very easy to     
  print formatted output in different fonts.                       
*/
void WGTAPI wgtprintf (int x, int y, wgtfont font, char *fmt, ...)
{
va_list  argptr;                     /* Argument list pointer*/
char str[251];                       /* Buffer to build string into*/

  va_start (argptr, fmt);              /* Initialize va_ functions*/

  vsprintf (str, fmt, argptr);         /* prints string to buffer*/
  wouttextxy (x, y, font, str);
  /* Send string in graphics mode */

  va_end (argptr);                     /* Close va_ functions*/
}
