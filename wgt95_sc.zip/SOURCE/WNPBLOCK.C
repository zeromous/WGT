#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wnpblock.c                                         
  Contains:     wputblock, wnewblock, wallocblock                  
  Last Revised: June 5, 1996                                       
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/

/*
  Put a block using either copy or xray modes                      
void WGTAPI wputblock_software (int x, int y, block src, int method)
{
int width, height;    // Width and height of the src block
int display, maxy;    // clipped width and height
int ctr;
LPBYTE dst;             // Destination bits 
LPBYTE srcbits;         // Source bits 
long pitch,pitch2;

  if (src == NULL)
    return;

  width = wgetblockwidth (src);
  height = wgetblockheight (src);

  if (x + width > bx)                     // Clip the right side
    display = (bx + 1) - x;
  else display = width;

  srcbits = wgetblocksurface (src, &pitch);

  if (srcbits == NULL)                    // Nothing to blt 
     return;

  if (x < tx)                             // Clip the left side
    {
     srcbits += tx - x;
     display -= tx - x;   
     x = tx;
    }                                   

  if (display <= 0)                       // Trivially rejected
    {
     wunlocksurface (src);
     return;
    }
  
  maxy = y + height - 1;                  // Clip bottom
  if (maxy > by) 
    maxy = by;

  if (y < ty)                             // Clip top
    {
     srcbits += (ty - y)*pitch;   
     y = ty;
    }                                    
  
  dst = wgetblocksurface(src, &pitch2);
  if (dst == NULL)
    return;
  dst += y * pitch2 + x;

  if (method == 0)
    for (ctr = y; ctr <= maxy; ctr++)
      {
       memcpy(dst, srcbits, display);
       srcbits += pitch;
       dst += pitch2;
      } 
  else
    for (ctr = y; ctr <= maxy; ctr++)
      {
       putxray (dst, srcbits, display);
       srcbits += pitch;
       dst += pitch2;
      } 

  wunlocksurface (dst);
  wunlocksurface (src);
}
*/

/*
  Put a block using either copy or xray modes                      
*/
void WGTAPI wputblock (int x, int y, block src, int method)
{
        int             width, height;
        DWORD           dwTransType;
        RECT            rcRect;
        RECT            dRect;
        DDBLTFX         ddbltfx;
        int             sx1, sy1;
        DDCOLORKEY      ddck;
        int             result;

  if (src == NULL)
    return;

  width = wgetblockwidth (src);
  height = wgetblockheight (src);

  /* Falls completely out of clipping range */
  if (((x + width) <= tx) || (x > bx) ||
       ((y + height) <= ty) || (y > by))
        return;

  if (x < tx)                             /* Clip left side */
    {
     width -= tx - x;
     sx1 = tx - x;
     x = tx;
    }
  else sx1 = 0;

  if (x + width > bx)                 /* Clip right side */
     width = (bx + 1) - x;

  if  (y < ty)                            /* Clip top */
    {
     height -= ty - y;
     sy1 = ty - y;
     y = ty;
    }
  else sy1 = 0;

  if (y + height > by)                /* Clip bottom */
     height = (by + 1) - y;

  dwTransType = DDBLT_WAIT; // | DDBLT_ASYNC;

  if ((width == 0) || (height == 0))
     return;

  rcRect.left   = sx1;
  rcRect.top    = sy1;
  rcRect.right  = sx1 + width;
  rcRect.bottom = sy1 + height;

  dRect.left   = x;
  dRect.top    = y;
  dRect.right  = x + width;
  dRect.bottom = y + height;

  memset (&ddbltfx, 0, sizeof (ddbltfx));
  ddbltfx.dwSize = sizeof (ddbltfx);
  ddbltfx.dwFillColor = 0;

  if (method == XRAY)
  {
    dwTransType |= DDBLT_KEYSRC;

    // Set the transparent color to 0
    ddck.dwColorSpaceLowValue  = 0;
    ddck.dwColorSpaceHighValue = 0;
    result = IDirectDrawSurface4_SetColorKey (src, DDCKEY_SRCBLT, &ddck);
    if (result != DD_OK)
     if (diagnostics_level & 2)
      wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
  }

  result = IDirectDrawSurface4_Blt (wgtbltdest, &dRect, src, &rcRect, dwTransType,
           &ddbltfx);
  if (result != DD_OK)
  {
    if (diagnostics_level & 2)
      {
       wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
       wgt_log_message ("Src x=%d, y=%d, x2=%d, y2=%d\n", rcRect.left, rcRect.top, rcRect.right, rcRect.bottom);
       wgt_log_message ("Dst x=%d, y=%d, x2=%d, y2=%d\n", dRect.left, dRect.top, dRect.right, dRect.bottom);
       wgt_log_message ("Clip (%d, %d, %d, %d)\n", tx,ty,bx,by);
      }
  }
}



/*
  Allocate memory and get a new block, return the pointer          
*/
block WGTAPI wnewblock (int x, int y, int x2, int y2)
{
  DDSURFACEDESC2 ddsd;
  block         pdds;
  int           result;

  ZeroMemory (&ddsd, sizeof (ddsd));
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT |DDSD_WIDTH;
  ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
  ddsd.dwWidth = x2 - x + 1;
  ddsd.dwHeight = y2 - y + 1;

  result = IDirectDraw4_CreateSurface(wgtpdd, &ddsd, &pdds, NULL);
  if (result != DD_OK)
  {
      if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
        return NULL;
  }

  wcopyscreen (x, y, x2, y2, wgtbltdest, 0, 0, pdds);
  return pdds;
}


/*
  Allocate memory and for a new block, return the pointer          
*/
block WGTAPI wallocblock (int width, int height)
{
  DDSURFACEDESC2 ddsd;
  block         pdds;
  int           result;

  
  if (diagnostics_level & 2)
    wgt_log_message ("Allocblock: w %i  h %i", width, height);

  if ((width <= 0) || (height <= 0))
    return NULL;
  

  ZeroMemory (&ddsd, sizeof (ddsd));
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_PIXELFORMAT;
  ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
  ddsd.dwWidth = width;
  ddsd.dwHeight = height;
  ddsd.ddpfPixelFormat.dwSize = sizeof(DDPIXELFORMAT);
  ddsd.ddpfPixelFormat.dwFlags = DDPF_PALETTEINDEXED8 | DDPF_RGB;
  ddsd.ddpfPixelFormat.dwRGBBitCount = 8;

  result = IDirectDraw4_CreateSurface(wgtpdd, &ddsd, (LPDIRECTDRAWSURFACE4 *)&pdds, NULL);
  if (result != DD_OK)
  {
      if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
        return NULL;
  }
  return pdds;
}


