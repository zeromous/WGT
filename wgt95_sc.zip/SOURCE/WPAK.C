#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                
 
  Module:       wpak.c                                             
  Contains:     wsavepak, wloadpak                                 
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Chris Egerter         Windows 95 Version           
*/


/*
  Save a block in WGT's PAK format                                 
  This is a format I developed while writing a 640x350x16c drawing 
  program.  It uses run length encoding and is often a bit better  
  than the PCX format.  No palette information is stored.          
*/
short WGTAPI wsavepak (char *filename, block image)
{
short i, sty, stx, done, rep, dun;
int width, height;
LPBYTE c;
FILE *out;
LPBYTE blkbits;
long pitch;

  if  ((out = fopen (filename, "wb")) == NULL)
    return 1;
  
  width = wgetblockwidth (image);            /* get width and height */
  height = wgetblockheight (image);

  fwrite (&width, 2, 1, out);              /* write width and height */
  fwrite (&height, 2, 1, out);

  c = wmalloc (width);
  blkbits = wgetblocksurface (image, &pitch);
  if (blkbits == NULL)
    {
     fclose (out);
     return (0);
    }

  for  (sty = 0; sty < height; sty++)       /* row loop */
  {
    done = 0;
    memcpy (c, blkbits, width);             /* store values into array */
    blkbits += pitch;
    
    rep = 1;                           /* number of times a pixel repeats */
    stx = - 1;                         /* starting x value */
    do
    {
      stx++;
      if  ((c[stx] == c[stx + 1]) & (stx != width - 1))
        /* if a pixel = the next one */
      {
        rep++;                         /* increase the repition counter */
        if  (rep == 255)               /* repeats a maximum of 255 times */
        {
          fputc (rep, out);            /* write out the rep count */
          fputc (c[stx], out);         /* write out the repeating colour */
          rep = 1;                     /* reset rep count */
          stx++;
        }
      }
      else
      {
        if  (rep != 1)
        /* if there was more than one repeating pixel */
        {
          fputc (rep, out);            /* write out rep count and colour */
          fputc (c[stx], out);
          rep = 1;
        }
        else if  (rep == 1)
        /* otherwise a single isolated colour */
        {
          /* This loop checks to see how many unrepeated pixels are
          stored in a row. Instead of writing 1 rep count, and the
          colour for each one (which would double the size of
          the image), we just write the number of non-repeating
          pixels, and then write them one after another. */
          
          dun = 0;
          do
          {
            if  ((c[stx] != c[stx + 1]) & (c[stx + 1] !=
                c[stx + 2]) & (stx != width - 1))
              /* if the next one isn't the same, and the one
              after that isn't a repeater */
            {
              rep++;
              if  (rep == 255)
              {
                dun = 1;
              }
            }
            else
              dun = 1;
            stx++;
          } while  (dun != 1);
          if  (rep > 1)                /* more than one non-repeater */
          {
            fputc (0, out);            /* control code */
            fputc (rep, out);          /* # of non-repeating */
            for  (i = stx - rep; i < stx; i++)
            {
              fputc (c[i], out);
              /* write out all non-repeating */
            }
            stx--;
          }
          else
          {
            fputc (1, out);
            /* only 1 non-repeater, write it out normally */
            stx--;
            fputc (c[stx], out);
          }
          rep = 1;
          done = 0;
        }
      }
      if  (stx > width - 2)
        done = 1;
    } while  (done != 1);
    /* end of line */
  }
  fputc (0, out);                      /* end of data */
  fputc (1, out);

  wfree (c);
  wunlocksurface (image);
  
  fclose (out);
  return 0;
}



/*
  Loads a block from WGT's PAK format                              
*/
block WGTAPI wloadpak (char *filename)
{
block buffer;
LPBYTE blkbits;
short width, height;
short p,ccc,done;
long pitch;
int xcount;

  
  /* load in from the library file if needed */
  if  (wgtlibrary == NULL)
  {
    if  ((libf = fopen (filename, "rb")) == NULL)
      return NULL;
  }
  else
  {
    if  ((libf = fopen (wgtlibrary, "rb")) == NULL)
      return NULL;
    readheader ();
    findfile (filename);
    if  (lresult == 1)
      fseek (libf, lfpos, SEEK_SET);
    if  (checkpassword (password) == 0)
    {
      wfatalerror ("Incorrect password");
    }
  }
  
  if  ((wgtlibrary != NULL) & (lresult == 0)) goto lpakstop;
  fread (&width, 2, 1, libf);                 /* width and height */
  fread (&height, 2, 1, libf);

  buffer = wallocblock (width, height);
  if  (buffer == NULL)
    return NULL;     /* not enough memory */

  blkbits = wgetblocksurface (buffer, &pitch);
  xcount = 0;
  done = 0;
    
    
  /* now start uncompressing the picture */
  do
    {
     p = fgetc (libf);                /* get the control code */
     ccc = fgetc (libf);              /* and the colour */
     if (p != 0)                      /* repeating pixel */
       {
        memset (blkbits, ccc, p);
        blkbits += p;
        xcount += p;
       }

     if ((p == 0) & (ccc == 1))       /* end of file */
       done = 1;
     if ((p == 0 ) & (ccc > 1))       /* non-repeating */
       {
        fread (blkbits, 1, ccc, libf);     /* read in ccc pixels */
        blkbits += ccc;
        xcount += ccc;
       }

     if (xcount == width)
       {
        blkbits += pitch - width;
        xcount = 0;
       }
    } while  (done != 1);              /* until end */
  lpakstop:
  ;
  fclose (libf);
  wunlocksurface (buffer);
  return buffer;
}
