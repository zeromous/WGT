#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wwarp.c                                            
  Contains:     wwarp                                              
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/


/*
  Calculates the line and stores y values.                         
  See wline for the basic line routine.                            
*/
void WGTAPI wsline (int x, int y, int x2, int y2, int *y_array)
{
int t, distance;
int wx, wy, dx, dy, bdx, bdy, incx, incy;
  
  dx = x2 - x;
  dy = y2 - y;
  t = 0; wx = 0; wy = 0;
  if (dy < 0)
    incy = - 1;
  else
    incy = 1;

  if (dx < 0)
    incx = - 1;
  else
    incx = 1;

  bdx = abs (dx);
  bdy = abs (dy);
  if (bdx > bdy)
    distance = bdx;
  else
    distance = bdy;
  y_array += x; 

  if (distance == bdx)
    {
     while (t <= distance)
       {
        if ((x >= tx) && (y >= ty) && (y <= by) && (x <= bx))
          *y_array = y;
        /* instead of plotting pixels, just store the y value in an array */

        wy += bdy;
        x += incx;
        y_array++;
        t++;

        if (wy >= distance)
          {
           wy -= distance;
           y += incy;
          }
       }
    }
  else
    {
     while (t <= distance)
       {
        if ((x >= tx) && (y >= ty) && (y <= by) && (x <= bx))
          *y_array = y;
        wx += bdx;

        if (wx >= distance)
          {
           wx -= distance;
           x += incx;
           y_array++;
          }

        y += incy;
        t++;
       }
   }
}
 

/*
  Warps a block on the screen, by vertically resizing between      
  tpy and bty for each column.                                     
*/
void WGTAPI wwarp (int sx, int ex, int *tpy, int *bty, block ptr,
                   int mode)
{
int column;
int wid;

short finalwidth;
short origwidth;
unsigned int xstepper;

  origwidth = wgetblockwidth (ptr);
  /* Get the original width of the block */

  finalwidth = abs (ex - sx) + 1;
  /* Find the new width */

  xstepper = ((int)(origwidth) << 16) / ((int)(finalwidth));
  /* Calculate the amount to add to the source bitmap for every pixel across.
  This is done using a fixed point number by multiplying it by 65536 (<<16)
  and using 0-65535 as a fractional amount. */

  column = 0;
  
  for (wid = sx; wid <= ex; wid++)
    {
     wresize_column (wid, tpy[wid], bty[wid], ptr, column >> 16, mode);
     column += xstepper;
    }
}
