#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wflipb.c                                           
  Contains:     wflipblock                                         
  Last Revised: April 28, 1996                                     
                                                                   
  Written by:   Barry Egerter       Windows 95 Version             
*/



/*
  Flip a block horizontally(1) or vertically(0)                   
*/
void WGTAPI wflipblock (block image, int direction)
{
int width,height;
int ctr,ctr2;
unsigned char *temp;
unsigned char *temp2;
unsigned char *pr2;
unsigned char *blkbits;
long pitch;

  width = wgetblockwidth (image);         /* Find width and height of block */
  height = wgetblockheight (image);
  temp = wmalloc (width);
  temp2 = wmalloc (width);
  blkbits = wgetblocksurface (image, &pitch);
  if (blkbits == NULL)
     return;

  if (direction == 1)                       /* Horizontal flip */
    {
     for (ctr = 1; ctr <= height; ctr++)
       /* Use each row */
       {
        memcpy (temp, blkbits, width);
        /* Copy row to buffer */

        for (ctr2 = 0; ctr2 <= width - 1; ctr2++)
          temp2[width - 1 - ctr2] = temp[ctr2];
        /* Reverse elements to another buffer */

        memcpy (blkbits, temp2, width);     /* Copy back to original block */
        blkbits += pitch;                   /* Advance pr to next row */
      }
    }
  else if (direction == 0)                  /* Vertical flip */
    {
     pr2 = blkbits + (height*pitch) - pitch; /* pr2 points to last row */
     for (ctr = 1; ctr <= (height / 2); ctr++)
      /* Only flip halfway */
       {
        memcpy (temp, blkbits, width);   /* Get row of image data */
        memcpy (blkbits, pr2, width);    /* Copy last row to first */
        memcpy (pr2, temp, width);       /* Put first row on last */
        blkbits += pitch;                /* Move to next row */
        pr2 -= pitch;                    /* Decrement last row */
       }
   }
  wfree (temp);
  wfree (temp2);
  wunlocksurface (image);
}


