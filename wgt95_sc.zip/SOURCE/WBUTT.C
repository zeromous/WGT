#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wbutt.c                                            
  Contains:     wbutt                                              
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter           Windows 95 Version         
*/


/*
  Draws a 3-Dimenstional Button with colors 253,254,255           
*/
void WGTAPI wbutt (int x, int y, int x2, int y2)
{
int ctr;

  if (diagnostics_level & 2)
        wgt_log_message ("Entry of wbutt");
  if  (y2 < y)     /* swap y's */
    {
     ctr = y;
     y = y2;
     y2 = ctr;
    }

  if  (x2 < x)     /* swap x's */
    {
     ctr = x;
     x = x2;
     x2 = ctr;
    }

  wsetcolor (0);
  wrectangle (x - 1, y - 1, x2 + 1, y2 + 1);  /* Clear area for button */

  wsetcolor (254);
  wbar (x, y, x2, y2);                 /* Draw inner bar */
  wsetcolor (255);
  wline (x2, y, x2, y2);               /* Outline right and bottom edges */
  wline (x2, y2, x, y2);
  
  wsetcolor (253);                     /* Use a different shade */
  wline (x, y, x2, y);                 /* Outline upper and left edges */
  wline (x, y, x, y2);
  if (diagnostics_level & 2)
        wgt_log_message ("Exit of wbutt");  
}
