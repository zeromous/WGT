#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wpal.c                                             
  Contains:     wloadpalette, wsavepalette                         
  Last Revised: March 24, 1996                                     
                                                                   
  Written by:   Barry Egerter          Windows 95 Version          
*/

/*
 Loads a palette file                                            
*/
void WGTAPI wloadpalette (char *filename, color *pal)
{
int r, g, b, i;

  if  (wgtlibrary == NULL)
  /* Not loading from within library file */
  {
    if  ((libf = fopen (filename, "rb")) == NULL)
    {
      wfatalerror ("Unable to open palette file: %s", filename);
    }
  }
  else
  /* Attempt to load from within a library file */
  {
    if  ((libf = fopen (wgtlibrary, "rb")) == NULL)
    {
      wfatalerror ("Unable to open palette file: %s", filename);
    }
    readheader ();                     /* Read library file header */
    findfile (filename);               /* Find palette file */
    if  (lresult == 1)
      fseek (libf, lfpos, SEEK_SET);   /* Prepare to load data */
    if  (checkpassword (password) == 0)
    {
      wfatalerror ("Incorrect password");
    }
  }
  
  if  ((wgtlibrary != NULL) & (lresult == 0)) goto lpalstop;
  /* File was not found in library file */

  for  (i = 0; i < 256; i++)           /* Load in RGB values */
  {
    r = fgetc (libf);
    g = fgetc (libf);
    b = fgetc (libf);
    wsetrgb ((unsigned char)i, (unsigned char)r, (unsigned char)g, (unsigned char)b, pal);         /* Set current palette */
  }
  lpalstop:
  ;
  fclose (libf);

}


/*
 Saves a palette file                                            
*/
void WGTAPI wsavepalette (char *filename, color *pal)
{
  FILE *palfile;

  if  ((palfile = fopen (filename, "wb")) != NULL)
    /* Open file for write */
  {
    fwrite (pal, 768, 1, palfile);      /* Output palette data */
    fclose (palfile);
  }
}


