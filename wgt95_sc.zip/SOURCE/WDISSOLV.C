#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
         Source Code    Copyright 1996 Egerter Software            

  Module:       wdissolv.c                                         
  Contains:     wdissolve                                          
  Last Revised: April 29, 1996                                     
                                                                   
  Written by:   Chris Egerter             Windows 95 Version       
*/


extern short bx, by, tx, ty;

/*
  Fades in a picture using a pattern defined by you                
*/
void WGTAPI wdissolve (block sourceimage, short *pattern, int speed)
{
short j, k, l, t, a, b;
unsigned short addr;
unsigned short addr2;
unsigned char *bits;
long pitch;

  bits = wgetblocksurface (sourceimage, &pitch);
  if (bits == NULL)
    return;

  t = *pattern;
  pattern++;

  for  (j = 0; j < t; j++)
    {
     a = *pattern;
     pattern++;
     b = *pattern;
     pattern++;
     Sleep (speed);
     for (k = 0; k < WGT_SYS.yres; k += 16)
      /* Since the fade pattern matrix is 16x16, we change every
      16th pixel at the same time. */
       {
        for (l = 0; l < WGT_SYS.xres; l += 16)
          {
           if ((k + b < by + 1) & (l + a < bx + 1) & (k + b >= ty)
               & (l + a >= tx))
           /* Make sure the pixel is within clipping */
             {
              addr = ((k + b) * WGT_SYS.screenwidth + l + a);
              addr2 = ((k + b) * pitch + l + a);
              abuf[addr] = bits[addr2];
             }
          }
       }
    }
  wunlocksurface (sourceimage);
}

