#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wtpoly.c                                           
  Contains:     wtexturedpoly                                      
                                                                   
  Last Revised: April 29, 1996                                     
                                                                   
  Written by:   Chris Egerter        Windows 95 Version            
*/


/* These arrays contain information about each scan line of the
   polygon. Each scan line can only have two intersections with
   the polygon, to keep things simple. */

extern int *pinit_array;
extern int *pstartx;          /* The first X coord                    */
extern int *pendx;            /* The last X coord                     */
extern int *pinten1;          /* First pixel coord out of texture  X1 */
extern int *pinten2;          /*                                   Y1 */
extern int *polyx2;           /* Last pixel coord out of texture   X2 */
extern int *polyy2;           /*                                   X3 */
extern int polygon_buffer_size;

/* Defines a vertex of the polygon */
/*
typedef struct
    {
    short x,y;  // Coordinate on the screen
    short sx,sy; // Coordinate on the texture
    } tpolypoint;
  */

unsigned char * wgttexture;
int wgttexturewidth;

static int xwhole, ywhole, xincone, yincone;
static unsigned char xpart, ypart;

#ifdef __WATCOMC__
void WGTAPI wtexture_line_normal (int len, unsigned char *temp, unsigned char *textr);
#pragma aux wtexture_line_normal = \
    "xor ebx,ebx" \
    "xor edx,edx" \
    "textloop: mov al,[esi]" \
    "mov [edi],al" \
    "add esi,dword ptr xwhole" \
    "add bl,byte ptr xpart" \
    "jnc noxcarry" \
    "add esi,dword ptr xincone" \
    "noxcarry: add dl,byte ptr ypart" \
    "jnc noycarry" \
    "add esi,dword ptr yincone" \
    "noycarry: inc edi" \
    "loop textloop" \
    parm [ecx] [edi] [esi] \
    modify exact [ecx esi edi eax edx ebx] nomemory;
#else
void WGTAPI wtexture_line_normal (int len, unsigned char *temp, unsigned char *textr)
{
	__asm {
		mov ecx,len
		mov edi,temp
		mov esi,textr
		xor ebx,ebx
		xor edx,edx
		textloop: mov al,[esi]
		mov [edi],al
		add esi,dword ptr xwhole
		add bl,byte ptr xpart
		jnc noxcarry
		add esi,dword ptr xincone
		noxcarry: add dl,byte ptr ypart
		jnc noycarry
		add esi,dword ptr yincone
		noycarry: inc edi
		loop textloop
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI wtexture_line_xray (int len, unsigned char *temp, unsigned char *textr);
#pragma aux wtexture_line_xray = \
    "xor ebx,ebx" \
    "xor edx,edx" \
    "xtextloop: mov al,[esi]" \
    "or al,al" \
    "je notmove" \
    "mov [edi],al" \
    "notmove: add esi,dword ptr xwhole" \
    "add bl,byte ptr xpart" \
    "jnc noxcarry" \
    "add esi,dword ptr xincone" \
    "noxcarry: add dl,byte ptr ypart" \
    "jnc noycarry" \
    "add esi,dword ptr yincone" \
    "noycarry: inc edi" \
    "loop xtextloop" \
    parm [ecx] [edi] [esi] \
    modify exact [ecx esi edi eax edx ebx] nomemory;
#else
void WGTAPI wtexture_line_xray (int len, unsigned char *temp, unsigned char *textr)
{
	__asm {
		mov ecx,len
		mov edi,temp
		mov esi,textr
		xor ebx,ebx
		xor edx,edx
		xtextloop: mov al,[esi]
		or al,al
		je notmove
		mov [edi],al
		notmove: add esi,dword ptr xwhole
		add bl,byte ptr xpart
		jnc noxcarry
		add esi,dword ptr xincone
		noxcarry: add dl,byte ptr ypart
		jnc noycarry
		add esi,dword ptr yincone
		noycarry: inc edi
		loop xtextloop
	}
}
#endif

/* Draws one scanline of the textured polygon. */
/* Where:
     x1 is the first x coordinate
     x2 is the second x coordinate
     y is the scanline to draw the line on
     sxn is the x coordinate on the texture relating to (x1,y)
     syn is the y coordinate on the texture relating to (x1,y)
     dxn is the x coordinate on the texture relating to (x2,y)
     dyn is the y coordinate on the texture relating to (x2,y)
*/
void WGTAPI wtextline (int x1, int x2, int y, int sxn, int syn,
                int dxn, int dyn, int mode)
{
int t; /* Temporary for swap */
int xincr; /* X offset into texture, amount to increase every pixel */
int yincr; /* Y offset into texture, amount to increase every pixel */
short xofs,xfrac;
short yofs,yfrac;
int width;
int clipcalc;
int len;
unsigned char *temp;
unsigned char * textr;

  textr = wgttexture;
  width = wgttexturewidth;
  temp = abuf;
  temp += y * WGT_SYS.screenwidth;

  if (x1 > x2)
    {
     t = x1;
     x1 = x2;
     x2 = t;
     t = sxn;
     sxn = dxn;
     dxn = t;
     t = syn;
     syn = dyn;
     dyn = t;
    }

  xofs = (int)sxn;
  yofs = (int)syn;

  if (x2 != x1)
    {
     xincr = ((int)(dxn - sxn)<<8) / (int)((x2 - x1));
     yincr = ((int)(dyn - syn)<<8) / (int)((x2 - x1));
    }
  else
    {
     xincr = 0;
     yincr = 0;
    }

  xfrac = 0;
  yfrac = 0;
  if (x1 < tx)
    {
     clipcalc = tx - x1;
     textr += (clipcalc * xincr) / 256;
     textr += ((clipcalc * yincr) / 256) * width;
     xfrac = (clipcalc * xincr) % 256;
     yfrac = (clipcalc * yincr) % 256;
     x1 = tx;
    }

  if (x2 > bx)
    x2 = bx;
  
  temp += x1;

  xwhole = xincr / 256;
  ywhole = yincr / 256;
  xpart = abs (xincr - xwhole * 256);
  ypart = abs (yincr - ywhole * 256);

  if (xincr > 0)
    xincone = 1;
  else
    xincone = -1;
  if (yincr > 0)
    yincone = width;
  else
    yincone = -width;

  ywhole *= width;

  len = x2 - x1 + 1;

  if (len > 0)
    {
     xwhole += ywhole;
     textr += xofs + (yofs * width);
     if (mode == 0) /* no xray */
       wtexture_line_normal (len, temp, textr);
     else /* xray mode */
       wtexture_line_xray (len, temp, textr);
    }
}




void WGTAPI wtpolyline (int x1, int y1, int sxn, int syn,
                        int x2, int y2, int dxn, int dyn)
{
int tmx, tmy, y;
int x, m;

int col, colinc;
int col2, colinc2;

  if (y2 !=y1)
    {
     if (y2<y1)
       {
        tmy = y1;
        y1 = y2;
        y2 = tmy;
        tmx = x1;
        x1 = x2;
        x2 = tmx;
 
        tmx = sxn;
        sxn = dxn;
        dxn = tmx;

        tmy = syn;
        syn = dyn;
        dyn = tmy;
       }

    x = (int)x1<<8;
    m = ((int)(x2 - x1)<<8) / ((int)(y2 - y1));
    col = (int)sxn<<8;
    colinc = ((int)(dxn - sxn)<<8) / (int)(y2 - y1);

    col2 = (int)syn<<8;
    colinc2 = ((int)(dyn - syn)<<8) / (int)(y2 - y1);
    x++;
    y1++;

    for (y = y1; y <= y2; y++)
      {
       if ((y >= 0) && (y  <WGT_SYS.yres))
       if (pstartx[y] == -16000)
         {
          pstartx[y] = x>>8;
          pinten1[y] = col>>8;
          pinten2[y] = col2>>8;
         }
       else
         {
          pendx[y] = x>>8;
          polyx2[y] = col>>8;
          polyy2[y] = col2>>8;
         }
       x += m;
       col += colinc;
       col2 += colinc2;
      }
  }
}


void WGTAPI wtexturedpoly (tpolypoint *vertexlist, int numvertex,
                           int x, int y, block tex, int mode)
{
int i;
tpolypoint *curpt,*nextpt;

  curpt = vertexlist;
  nextpt = vertexlist+1;

  wgttexture = wgetblocksurface (tex, &wgttexturewidth);

  memcpy (pstartx, pinit_array, polygon_buffer_size << 1);
  memcpy (pendx, pinit_array, polygon_buffer_size << 1);

  for (i=0; i<numvertex-1; i++)
    {
     wtpolyline (curpt->x + x, curpt->y + y, curpt->sx, curpt->sy,
                nextpt->x + x, nextpt->y + y, nextpt->sx, nextpt->sy);
     curpt++;
     nextpt++;
    }

  nextpt = vertexlist;
  wtpolyline (curpt->x + x, curpt->y + y, curpt->sx, curpt->sy,
              nextpt->x + x, nextpt->y + y, nextpt->sx, nextpt->sy);

  for (i=0; i<WGT_SYS.yres; i++)
    {
     if (pstartx[i] != -16000)
       {
        if (pendx[i] == -16000)
          pendx[i] = pstartx[i];  /* A single point for some reason */

        /* Draw one scan line of the polygon */
        wtextline (pstartx[i], pendx[i], i, pinten1[i], pinten2[i], polyx2[i], polyy2[i], mode);
       }
    }
 wunlocksurface (tex);
}

