#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                
                                                                   
  Module:       wblock.c                                           
  Contains:     wsaveblock, wloadblock                             
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Chris Egerter         Windows 95 Version           
*/



/*
�����������������������������������������������������������������ͻ
� Saves a block to disk                                           �
�����������������������������������������������������������������ͼ
*/
short WGTAPI wsaveblock (char *filename, block image)
{
int w, h;
FILE *out;
LPBYTE blkbits;
long pitch;

  if (diagnostics_level & 2)
        wgt_log_message ("Entry of wsaveblock");
  if ((out = fopen (filename, "wb")) == NULL)
    return 1;

  w = wgetblockwidth (image);
  h = wgetblockwidth (image);
  blkbits = wgetblocksurface (image, &pitch);
  if (blkbits == NULL)
    {
     fclose (out);
     return (0);
    }

  fwrite (&w, 2, 1, out);
  fwrite (&h, 2, 1, out);

  while (h)
    {
     fwrite (blkbits, w, 1, out);           /* write data */
     blkbits += pitch;
     h--;
    }

  wunlocksurface (image);
  fclose (out);
  if (diagnostics_level & 2)
        wgt_log_message ("Exit of wsaveblock");
  return 0;
}


block WGTAPI wloadblock (char *filename)
{
block ptr;
LPBYTE blkbits;
long pitch;
short width, height;

  if  (wgtlibrary == NULL)
  {
    if  ((libf = fopen (filename, "rb")) == NULL)
      return NULL;
  }
  else
  {
    if  ((libf = fopen (wgtlibrary, "rb")) == NULL)
      return NULL;
    readheader ();
    findfile (filename);
    if  (lresult == 1)
      fseek (libf, lfpos, SEEK_SET);
    if  (checkpassword (password) == 0)
      wfatalerror ("Incorrect password");
  }

  if  ((wgtlibrary != NULL) & (lresult == 0)) goto lblkstop;
  fread (&width, 2, 1, libf);                 /* read width and height */
  fread (&height, 2, 1, libf);

  ptr = wallocblock (width, height);
  if (ptr == NULL)
    {
     fclose (libf);
     return NULL;
    }

  blkbits = wgetblocksurface (ptr, &pitch);
  if (blkbits == NULL)
    {
     fclose (libf);
     return NULL;
    }

  while (height)
    {
     fread (blkbits, width, 1, libf);/* read picture data */
     blkbits += pitch;
     height--;
    }

  wunlocksurface (ptr);
    
  lblkstop:
  ;
  fclose (libf);
  return ptr;
}

