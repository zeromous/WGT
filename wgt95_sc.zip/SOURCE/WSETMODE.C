#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wsetmode.c
  Contains:     vga256, wgetmode, wsetmode, vgadetected            
  Last Revised: April 25, 1995        Windows 95 Version           
                                                                   
  Written by:   Barry Egerter                                      
*/

IDirectDrawPalette * wgtddpal;
IDirectDrawSurface4 * wgtpdds;   /* DirectDraw primary surface */

int WGT_Windowed = FALSE;      //LR -- assume full screen

/*
  Start up the graphics system                                    
*/
void WGTAPI vga256 (void)
{
        PALETTEENTRY    newpal[256];
        int             i;
        int             result;

 //
 // build a 332 palette as the default.
 //
 for (i=0; i<256; i++)
   {
    newpal[i].peRed   = 0;//(BYTE)(((i >> 5) & 0x07) * 255 / 7);
    newpal[i].peGreen = 0;//(BYTE)(((i >> 2) & 0x07) * 255 / 7);
    newpal[i].peBlue  = 0;//(BYTE)(((i >> 0) & 0x03) * 255 / 3);
    newpal[i].peFlags = 0;//(BYTE)0;
   }

   result = IDirectDraw4_CreatePalette (wgtpdd, DDPCAPS_8BIT | DDPCAPS_ALLOW256, newpal, &wgtddpal, NULL);
   if (result != DD_OK)
     if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));

   result = IDirectDrawSurface4_SetPalette (wgtpdds, wgtddpal);
   if (result != DD_OK)
      if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
}


/*
BOOL
FAR PASCAL TitleHandler(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg)
  {
    case WM_COMMAND:
      if (LOWORD(wParam) == IDOK)
        EndDialog(hwnd, TRUE);
      break;

    case WM_INITDIALOG:
      return TRUE;
  }
  return FALSE;
}
*/


/*
  Sets a video mode.  This can be used to change to any mode, but  
  WGT won't show things on the screen right because of the linear  
  addressing (1 byte=1 pixel)                                      
*/
extern HINSTANCE hInstance;
extern HWND hWndMain;
HRESULT WGTAPI wsetmode (DWORD dwWidth, DWORD dwHeight,
    DWORD dwBPP, DWORD dwRefreshRate, DWORD dwFlags)
{
   HRESULT         res;

   WGT_SYS.screenwidth = (short)dwWidth;
   WGT_SYS.screenheight = (short)dwHeight;

   if (diagnostics_level & 2)
     wgt_log_message ("setmode %i %i\n", (int)dwWidth, (int)dwHeight);

   if (!WGT_Windowed)    // %% TO DO: set window size!
     {
      res = IDirectDraw4_SetDisplayMode (wgtpdd, dwWidth, dwHeight, dwBPP, dwRefreshRate, dwFlags);

      if( res != DD_OK && (diagnostics_level & 2) )
        wgt_log_message (" --- FAILURE %d", res, getErrorString( res ) );
     }
   else
     res = DD_OK;

   return res;
}


