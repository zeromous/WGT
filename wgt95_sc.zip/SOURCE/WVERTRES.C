#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wvertres.c                                         
  Contains:     wvertres                                           
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/



/*
  Resizes a block to a new height only                             
*/
/* See wresize for the basic resize routine */
void WGTAPI wvertres (int x, int y, int y2, block image)
{
int width,height,base,yy,temp;
int fy,ctr2;
int same2,incr2;
LPBYTE blkbits;
long pitch;

  width = wgetblockwidth (image);
  height = wgetblockheight (image);      /* store width and height */

  if (y > y2)                            /* swap y's if needed */
    {
     temp = y;
     y = y2;
     y2 = temp;
    }

  incr2 = (int)((float)(y2 - y + 1) / (float)height * 2000.0);
  /* find increment  */
  fy = y2;
  yy = y;
  ctr2 = 0;
  same2 = 0;
  base = 0;

  blkbits = wgetblocksurface (image, &pitch);
  if (blkbits == NULL)
    return;

  while (yy <= fy)
    {
     if (incr2 >= 2000)
       while ((same2 - ctr2 > 999) & (yy < fy))
         {
          memcpy (&abuf[(yy)*WGT_SYS.screenwidth + x],
                  &blkbits[(base)*pitch], width);
          yy ++;
          ctr2 += 2000;
         }
     else
       while (same2 < ctr2)
         {
          same2 += incr2;
          base ++;
         }

     if (yy < fy)
      memcpy (&abuf[(yy)*WGT_SYS.screenwidth + x],
              &blkbits[(base)*pitch], width);

     same2 += incr2;
     ctr2 += 2000;
     base ++;
     yy ++;
   }

 wunlocksurface (image);
}
