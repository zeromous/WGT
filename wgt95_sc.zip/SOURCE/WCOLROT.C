#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wcolrot.c                                          
  Contains:     wcolrotate                                         
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Chris Egerter           Windows 95 Version         
*/


/*
  Rotate the colors in a direction                                 
*/
void WGTAPI wcolrotate (unsigned char start, unsigned char finish, 
                        int dir, color *pal)
{
color temp;
unsigned char *dst;
unsigned char *src;
int t;
  
  
  if (start > finish)      /* Make sure start color # < end color # */
    {
     t = start;
     start = finish;
     finish = t;
    }

  if (dir == 0)                       /* Rotating up */
    {
     dst = &pal[start].r;              /* Preserve first color */
     temp.r = *dst;
     dst = &pal[start].g;
     temp.g = *dst;
     dst = &pal[start].b;
     temp.b = *dst;

     dst = (unsigned char *) &pal[start];
     /* Find starting address */
     src = (unsigned char *) &pal[start + 1];
     /* Going to move everything up 1 */
 
     memmove (dst, src, abs (start - finish + 1) * 3);
     /* Move it */

     dst = &pal[finish - 1].r;         /* Store first color at end */
     *dst = temp.r;
     dst = &pal[finish - 1].g;
     *dst = temp.g;
     dst = &pal[finish - 1].b;
     *dst = temp.b;
    }
  else                                 /* Rotating down */
    {
     src = &pal[finish].r;             /* Store last color */
     temp.r = *src;
     src = &pal[finish].g;
     temp.g = *src;
     src = &pal[finish].b;
     temp.b = *src;

     src = (unsigned char *) &pal[start];
     /* Get starting address */
     dst = (unsigned char *) &pal[start + 1];
     /* Going to move everything down 1 */
     memmove (dst, src, abs (start - finish) * 3);
     /* Move it */
    
     src = &pal[start].r;              /* Store last color in position 1 */
     *src = temp.r;
     src = &pal[start].g;
     *src = temp.g;
     src = &pal[start].b;
     *src = temp.b;
    }
}
