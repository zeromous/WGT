#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wmiscb.c                                           
  Contains:     wfreeblock, wgetblockwidth, wgetblockheight,       
                wgetblocksurface                                   
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/

/*
  Free memory allocated by a block                                 
*/
void WGTAPI wfreeblock (block ptr)
{
  int               result;

  if (ptr == NULL)
  {
     if (diagnostics_level & 2)
        wgt_log_message ("ERROR - Attempt to free NULL block");
        return;
  }
  result = IDirectDrawSurface4_Release (ptr);
  if (result != DD_OK)
     if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
}


/*
  Return the width of a block in pixels                            
*/
short WGTAPI wgetblockwidth (block ptr)
{
  DDSURFACEDESC2                ddsd;
  int                           result;

  if (ptr == NULL)
  {
        return 0;
  }
  memset (&ddsd, 0, sizeof(ddsd));
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;

  result = IDirectDrawSurface4_GetSurfaceDesc (ptr, &ddsd);
  if (result != DD_OK)
    if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
  return ((short)ddsd.dwWidth);
}


/*
  Return the height of a block in pixels                           
*/
short WGTAPI wgetblockheight (block ptr)
{
  DDSURFACEDESC2                ddsd;
  int                           result;

  if (ptr == NULL)
  {
        return 0;
  }
  memset (&ddsd, 0, sizeof(ddsd));
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
  result = IDirectDrawSurface4_GetSurfaceDesc (ptr, &ddsd);
  if (result != DD_OK)
     if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));

  return ((short)ddsd.dwHeight);
}


/*
  Return the width and height of a block in pixels                 
*/
void WGTAPI wgetblockdimensions (block ptr, short *width, short *height)
{
  DDSURFACEDESC2                ddsd;
  int                           result;

  if (ptr == NULL)
  {
     if (diagnostics_level & 2)
        wgt_log_message ("ERROR - Attempt to get dimensions of NULL block");
        return;
  }
  memset (&ddsd, 0, sizeof(ddsd));
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
  result = IDirectDrawSurface4_GetSurfaceDesc (ptr, &ddsd);
  if (result != DD_OK)
     if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));

  *width = (short)ddsd.dwWidth;
  *height = (short)ddsd.dwHeight;
}


/*
  Return the pointer to a surface                                  
*/
LPBYTE WGTAPI wgetblocksurface (block ptr, long *pitch)
{
  DDSURFACEDESC2                ddsd;
  int                           result;


  memset (&ddsd, 0, sizeof(ddsd));
  ddsd.dwSize = sizeof(ddsd);
  ddsd.dwFlags = DDLOCK_WAIT;
  result = IDirectDrawSurface4_Lock (ptr, NULL, &ddsd, DDLOCK_WAIT, NULL);
  if (result != DD_OK)
  {
     if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
        return NULL;
  }
  *pitch = ddsd.lPitch;
  return (ddsd.lpSurface);
}

/*-----
  Closes a surface (unlocks)                                      
*/
void WGTAPI wunlocksurface (block image)
{
  int                   result;

  result = IDirectDrawSurface4_Unlock (image, NULL);
  if (result != DD_OK)
     if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
}



