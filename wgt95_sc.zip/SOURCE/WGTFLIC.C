/*
                       WordUp Graphics Toolkit 95                             
                   AUTODESK FLI/FLC Animation Decoder/Player                  
                                                                              
  WordUp Graphics Toolkit source Copyright 1997 Egerter Software              
  Licensed for personal use only                                              
                                                                              
   Written by:                                             Last revised:      
                         Barry Egerter                      Sept 14, 1997     


      PROJECT                                                                 
  Compile this as a standalone LIB which eventually needs to be linked with   
  the WGT95.LIB file.   This file also has an include file called WGTFLIC.H   
                                                                              
      DATA FILES                                                              
  NONE                                                                        
                                                                              
*/
#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <conio.h>
#include <dos.h>
#include <memory.h>
#include <wgt95.h>

/*              ----REVISION HISTORY----

                1.0     Initial Release
                1.1     Altered WMEM_LOADFLI and WMEM_GETANIFRAME (10/01/95)
                        to correct the memory corruption issues
                1.2     Fixed the palette chunk routine

*/

#define FLIC_OK                 0
#define FLIC_NOTFOUND           1
#define FLIC_INVALIDRES         2
#define FLIC_INVALIDHEADER      3
#define FLIC_INVALIDFRAME       4
#define FLIC_INVALIDCHUNK       5
#define FLIC_DONE               6


static int flic_color=1;                /* Adjust palette? */

typedef struct {                        /* MAIN FLI header */
    int         size;                   /* Size of file */
    unsigned short magic;               /* 44817 = FLI, 44818 = FLC */
    short       frames;                 /* Frames in animation */
    short       width;                  /* Animation width */
    short       height;                 /* Animation height */
    short       depth;                  /* Bits per pixel (8) */
    short       flags;                  /* Set to 0x0003 after ring frame */
    short       speed;                  /* Delay in msec between frames */
    short       reserved;               /* Unused word, set to 0 */
    int         created;                /* MSDOS format date/time */
    int         creator;                /* Serial # of AnimPro */
    int         updated;                /* MSDOS format date/time */
    int         updater;                /* Yet another serial # */
    short       aspectx;                /* Aspect ratio of x-axis */
    short       aspecty;                /* Aspect ratio of y-axis */
    unsigned short reserved2[19];       /* 38 unused bytes, set to zeroes */
    int         oframe1;                /* Offset of frame 1 in file */
    int         oframe2;                /* Offset of frame 2 in file */
    unsigned short reserved3[20];       /* 40 unused bytes, set to zeroes */
} flicheader;

typedef struct {                        /* FRAME header */
    int                 size;           /* Size of frame in bytes */
    unsigned short      magic,chunks;   /* 61946 indicates frame */
    unsigned char       expand[8];      /* Not used */
} frameheader;

typedef struct {                        /* Chunk header */
    int                 size;           /* Size in bytes of chunk */
    unsigned short      typ;            /* Type of chunk */
} chunkheader;

typedef struct {                        /* Packet information */
    unsigned char       skip;
    unsigned char       number;
} packetc;

static  frameheader     framehdr;
static  chunkheader     chunkhdr;
static  int             flickctr;
static  LPBYTE          secondframe;
static  unsigned char * buffer;
static  unsigned char * buf;
static  FILE          * flihandle;
static  HANDLE          flic_libfMapping;          /* Memory mapped file */
static  LPBYTE          flic_libfBits;             /* Pointer to memory mapped space */

        flicheader      flichdr;        /* Global structure */
        int             framenumber;    /* Current frame of animation */
        int             flic_updatey;
        int             flic_updatey2;
        int             flic_update = 0;



static int openflifile (char *filename)
/* Open binary FLI file for reading */
{
  /* Standard WGT library loading procedure */
  if  (wgtlibrary == NULL)             /* Not loading from library file */
  {
    flihandle = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                           FILE_FLAG_RANDOM_ACCESS, NULL);
    if (flihandle == INVALID_HANDLE_VALUE)
    {
       return FLIC_NOTFOUND;
    }
  }
  else                /* Load Flic from within library file */
  {
    flihandle = CreateFile(wgtlibrary, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                           FILE_FLAG_RANDOM_ACCESS, NULL);
    if (flihandle == INVALID_HANDLE_VALUE)
    {
       return FLIC_NOTFOUND;
    }
  }

  flic_libfMapping = CreateFileMapping (flihandle, NULL, PAGE_READONLY, 0, 0, NULL);
  if (flic_libfMapping == NULL)
  {
    CloseHandle (flihandle);
    return FLIC_NOTFOUND;
  }

  flic_libfBits = MapViewOfFile (flic_libfMapping, FILE_MAP_READ, 0, 0, 0);
  if (flic_libfBits == NULL)
  {
    CloseHandle (flihandle);
    CloseHandle (flic_libfMapping);
    return FLIC_NOTFOUND;
  }

  if (wgtlibrary != NULL)
  {
    readheader ();
    findfile (filename);
    if (lresult == 1)
        flic_libfBits += lfpos;              /* Prepare to load data */
    if (checkpassword (password) == 0)
      wfatalerror ("Incorrect password");
  }
  return FLIC_OK;
}


void closeflic (void)
{
  UnmapViewOfFile (flic_libfBits);
  CloseHandle (flihandle);
  CloseHandle (flic_libfMapping);
}


static int readfliheader (void)
/* Read FLI header info, done once per file only */
{
  memcpy (&flichdr, flic_libfBits, 128);     /* Header is 128 bytes */
  flic_libfBits += 128;
  if ((flichdr.magic != 44817) && (flichdr.magic != 44818))
       /* Must have AF11h or AF12h as magic # */
  {
    return FLIC_INVALIDHEADER;
  }
  if (flichdr.magic == 44817)
    flichdr.speed *= 14;
  return FLIC_OK;
}


static int readframeheader (void)
{
  memcpy (&framehdr, flic_libfBits, 16);
  flic_libfBits += 16;                       /* Frame header is 16 bytes */

  if ( (framehdr.magic != 0xf1fa) && (framehdr.magic != 0xf100))
  /* Magic # must be 61946, or 161 for FLC    */
    return FLIC_INVALIDFRAME;
  else return FLIC_OK;
}


static void readchunkheader (void)
{
  memcpy (&chunkhdr, buf, 6);      /* Chunk header is only 6 bytes */
  buf += 6;
}


static void fli256color (void)
/* Chunk type 4 indicates setting the palette */
{
  color p[256];
  unsigned char *ptr;
  unsigned short packets;
  packetc values;
  int temp, count, amount, ctr;
    
  wreadpalette (0, 255, p);
  memcpy (&packets, buf, 2);        /* See how many packets to read */
  buf += 2;
  ptr = (unsigned char *)&p[0];
  temp = 0;
  for (count = 1; count <= packets; count++)
  {
    memcpy (&values, buf, 2);       /* Find out how many colors to skip */
    buf += 2;
    if (values.number == 0)         /* # of colors to set =1-255, 0=256 */
      amount = 256; 
    else amount = values.number;

    temp += values.skip;
    ptr += (values.skip*3);         /* Skip 3 bytes (RGB) each color */
    memcpy (ptr, buf, amount*3);    /* Read palette data from chunk */
    buf+=amount*3;
    if (amount*3 & 1)  /* Odd byte padding */
      buf++;


    for (ctr = temp; ctr< temp + amount; ctr++)
    {
      p[ctr].r = p[ctr].r / 4;
      p[ctr].g = p[ctr].g / 4;
      p[ctr].b = p[ctr].b / 4;
    }
    temp += amount;
    ptr += amount * 3;
  }
  if (flic_color)
    wsetpalette (0, 255, p);
}




static void flimini (void)
{
  buf += chunkhdr.size - 6;
}


#ifdef __WATCOMC__
void word_copy (unsigned char *dest, short value, int times);
#pragma aux word_copy = \
  "cld" \
  "rep stosw" \
parm [edi] [ax] [ecx] \
modify exact [edi ax ecx] nomemory;
#else
void word_copy (unsigned char *dest, short value, int times)
{
        __asm {
                mov edi,dest
                mov ax,value
                mov ecx,times
                cld
                rep stosw
        }
}
#endif


static void flidelta (void)
/* Chunk type 7 indicates line compressed data using run-length encoding */
{
  unsigned short nlines;
  unsigned char *screenptr;
  short packets;
  unsigned short packet_type;
  unsigned short dval;
  short packet;
  unsigned char lastbyte;
  signed char size_count;
  int temp, x, y, ctr;
  int addbyte;
    
  flic_updatey = 999; 
  flic_updatey2 = 0;
  addbyte = 0;
  memcpy (&nlines, buf, 2);             /* Number of lines in chunk */
  buf += 2;
  y = 0;
  for (temp = 0; temp < nlines; temp++)
  {
    do {
      memcpy (&packet_type, buf, 2);    /* Get optional word */
      buf += 2;
      packets = packet_type;
      packet_type = (packet_type & 0xc000);
      x = 0;
      screenptr = abuf + (y * flichdr.width);
      if (packet_type == 0)               /* Packet count */
      {
        for (packet = 0; packet < packets; packet++)
        {
          screenptr += *buf;                      /* Skip_count value */
          buf++;
          size_count = *buf;              /* Read size_count variable */
          buf++;
          if (size_count >= 0)    /* If +, read size_count WORDS as data */
          {
            ctr = size_count * 2;
            memcpy (screenptr, buf, ctr);
            buf += ctr;
            screenptr += ctr;
          }
            else   /* If -, repeat word value abs(size_count) times */
          {
            memcpy (&dval, buf, 2);
            buf += 2;
            word_copy (screenptr, dval, -size_count);
            screenptr += ((-size_count) << 1);
          }  
        }
        if (addbyte)
        {
          *screenptr = lastbyte;
          screenptr++;
          addbyte = 0;
        }
        y++;
        if (y > flic_updatey2)
          flic_updatey2 = y;
      }
      else if (packet_type == 0xc000)     /* Line skip count */
      { 
        y += -packets; 
        if (y < flic_updatey)
          flic_updatey = y; 
      }
      else if (packet_type == 0x8000)     /* Last byte to add to line */
      { 
        memcpy (&lastbyte, (&packets)+1, 1);      /* Copy last byte from lo */
        addbyte = 1;
      }
    } while (packet_type != 0);
  }
  /* Set variables so that we know the maximum amount of screen updated */
  if (flic_updatey > flichdr.height - 1)
    flic_updatey = 0;
  flic_update = 1;
}


static void flicolor (void)
/* Chunk type 11 indicates setting the palette */
{
  color p[256];
  unsigned char *ptr;
  unsigned short packets;
  packetc values;
  int count,amount;
    
  wreadpalette (0, 255, p);
  ptr = (unsigned char *)&p[0];
  memcpy (&packets, buf, 2);         /* See how many packets to read */
  buf += 2;
  for (count = 1; count <= packets; count++)
  {
    memcpy (&values, buf, 2);   /* Find out how many colors to skip */
    buf += 2;
    if (values.number == 0)         /* # of colors to set =1-255, 0=256 */
      amount = 256; 
    else amount = values.number;
        
    ptr += values.skip * 3;       /* Skip 3 bytes (RGB) each color */
    memcpy (ptr, buf, amount*3);  /* Read palette data from chunk */
    buf += amount * 3;
    ptr += amount * 3;
  }
  if (flic_color)
    wsetpalette (0, 255, p); /* Only allow palette change
                                                 if variable is set */
}


static void flilc (void)
/* Chunk type 12 indicates line compressed data using run-length encoding */
{
  unsigned char *screenptr;
  unsigned short tsame,number;
  unsigned char packets,packet;
  signed char size_count;
  int x,y;
    
  memcpy (&tsame, buf, 2);     /* Number of lines to remain unchanged */
  buf += 2;
  memcpy (&number, buf, 2);    /* Number of lines to update */
  buf += 2;
  x = 0;
  for (y = tsame; y < tsame + number; y++)
  {
    memcpy (&packets, buf, 1);   /* Each line may contain several packets */
    buf++;
    x = 0;
    screenptr = abuf + (y * flichdr.width);
    for (packet = 1; packet <= packets; packet++)
    {
      screenptr += *buf;
      buf++;
      memcpy (&size_count, buf, 1);  /* Read size_count variable */
      buf++;
      if (size_count > 0)  /* If +, read that many bytes as raw image data */
      {
        memcpy (screenptr, buf, size_count);
        buf += size_count;
        screenptr += size_count;
      }
        else   /* If -, repeat color value -size_count times */
      {
        memset (screenptr, *buf, -size_count);
        buf++;
        screenptr -= size_count;
      }
    }
  }
  flic_updatey = tsame; 
  flic_updatey2 = tsame + number - 1;
  /* Set variables so that we know the maximum amount of screen updated */
  flic_update = 1;
}


static void fliblack (void)
/* Chunk type 13 indicates clear screen */
{
  memset (&abuf[0], 0, flichdr.width * flichdr.height);
  flic_updatey = 0; 
  flic_updatey2 = flichdr.height - 1;
  flic_update = 1;
}


static void flibrun (void)
/* Chunk type 15 indicates a full screen of bytewise run-length compressed 
   data. Usually used for first frame of file. See FLILC() for comments */
{
  unsigned char *screenptr;
  int count,x,y;
  unsigned char packets;
  signed char size_count;
    
  for (y = 0; y < flichdr.height; y++)
  {
    x = 0;
    memcpy (&packets, buf, 1);
    buf++;
    screenptr = abuf + (y * flichdr.width);
    for (count = 0; count < packets; count++)
    {
      memcpy (&size_count, buf, 1);
      buf++;
      if (size_count > 0)
      {
        memset (screenptr, *buf, size_count);
        buf++;
        screenptr += size_count;
      } 
        else
      {
        memcpy (screenptr, buf, -size_count);
        buf += -size_count;
        screenptr -= size_count;
      }
    }
  }
  flic_updatey = 0; 
  flic_updatey2 = flichdr.height - 1;
  flic_update = 1;
}


static void flicopy (void)
/* Chunk type 16 indicates next 64000 bytes are raw screen data */
{
  memcpy (abuf, buf, flichdr.width * flichdr.height); /* Load screen data */
  buf += (flichdr.width * flichdr.height);
  flic_updatey = 0; 
  flic_updatey2 = flichdr.height - 1;
  flic_update = 1;
}


static void fliprefix(void)
{
  buf += framehdr.size - 16;
}


/* Advance to the next frame in the animation and perform the actual
   updates. Return any errors which occur during this process. */
int nextframe (void)
{
  framenumber++;

  if (framenumber == 2)
    secondframe = flic_libfBits;  /* When last frame is read in,
                                we need to return here to loop
                                animation */
    
  if (framenumber > flichdr.frames + 1) /* Reached last frame of FLI ? */
  {
    framenumber = 2;                    /* Yes, start over at frame 2 */

    flic_libfBits = secondframe;
  }

  if ((readframeheader ()) == FLIC_INVALIDFRAME)
    return FLIC_INVALIDFRAME;
  buffer = malloc (framehdr.size - 16);    /* Get buffer for compressed data */

  memcpy (buffer, flic_libfBits, framehdr.size - 16);
  flic_libfBits += (framehdr.size - 16);
  buf = buffer;

  if (framehdr.magic == 0xf100) 
  {
    fliprefix();
  }
  else for (flickctr = 1; flickctr <= framehdr.chunks; flickctr++)
  {
    readchunkheader ();
    switch (chunkhdr.typ)             /* Perform required operation */
    {                                 /* based on type of chunk */
      case 4  : fli256color(); break;
      case 7  : flidelta (); break;
      case 11 : flicolor (); break;
      case 12 : flilc ();    break;
      case 13 : fliblack (); break;
      case 15 : flibrun ();  break;
      case 16 : flicopy ();  break;
      case 18 : flimini ();  break;
      default : return FLIC_INVALIDCHUNK;
    }
  }
  free( buffer );

  if (framenumber > flichdr.frames)
    return FLIC_DONE;
  else return FLIC_OK;
}


int openflic (char *filename, int mode_flic, int update_colors)
/* Prepare WGT for animation of an FLI/FLC file */
{
  if (openflifile (filename) == FLIC_NOTFOUND)  /* Open the file */
    return FLIC_NOTFOUND;

  if (readfliheader () == FLIC_INVALIDHEADER)  /* Read the main header data */
    return FLIC_INVALIDHEADER;

  flic_color = update_colors;
  framenumber = 0;
  return FLIC_OK;
}


void copyflic (void)
/* Copy changes (made since last call) to visual screen. This obtains
   optimum graphics performace by copying minimum amount of image necessary */
{
//  if (flic_update == 1)
//    wcopyscreen (0, flic_updatey, flichdr.width - 1, flic_updatey2, flicscreen, 0, flic_updatey, NULL);
}
