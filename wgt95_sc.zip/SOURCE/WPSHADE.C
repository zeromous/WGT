#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wpshade.c                                          
  Contains:     wputblock_shade                                    
  Last Revised: April 28, 1996                                     
                                                                   
  Written by:   Chris Egerter        Windows 95 Version            
*/



#ifdef __WATCOMC__
void WGTAPI wshade_block (unsigned char *shadetable, unsigned char *source,
                   unsigned char *dest, int length);
#pragma aux wshade_block = \
 "push ebp" \
 "cld" \
 "mov ebp, edx" \
 "mov ebx, 0" \
 "shadeloop: mov bl, [esi]" \
 "mov al, [ebp + ebx]" \
 "mov [edi], al" \
 "inc esi" \
 "inc edi" \
 "dec ecx" \
 "jnz shadeloop" \
 "pop ebp" \
parm [edx] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI wshade_block (unsigned char *shadetable, unsigned char *source,
                   unsigned char *dest, int leng)
{
	__asm {
		mov edx,shadetable
		mov esi,source
		mov edi,dest
		mov ecx,leng
		push ebp
		cld
		mov ebp, edx
		mov ebx, 0
		shadeloop: mov bl, [esi]
		mov al, [ebp + ebx]
		mov [edi], al
		inc esi
		inc edi
		dec ecx
		jnz shadeloop
		pop ebp
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI wshade_xray_block (unsigned char *shadetable, unsigned char *source,
                        unsigned char *dest, int length);
#pragma aux wshade_xray_block = \
 "push ebp" \
 "cld" \
 "mov ebp, edx" \
 "mov ebx, 0" \
 "shadeloop: mov bl, [esi]" \
 "and bl, bl" \
 "je noshade" \
 "mov al, [ebp + ebx]" \
 "mov [edi], al" \
 "noshade: inc esi" \
 "inc edi" \
 "dec ecx" \
 "jnz shadeloop" \
 "pop ebp" \
parm [edx] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI wshade_xray_block (unsigned char *shadetable, unsigned char *source,
                        unsigned char *dest, int leng)
{
	__asm {
		mov edx,shadetable
		mov esi,source
		mov edi,dest
		mov ecx,leng
		push ebp
		cld
		mov ebp, edx
		mov ebx, 0
		shadeloop: mov bl, [esi]
		and bl, bl
		je noshade
		mov al, [ebp + ebx]
		mov [edi], al
		noshade: inc esi
		inc edi
		dec ecx
		jnz shadeloop
		pop ebp
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI wshade_source_block (unsigned char *shadetable, unsigned char *source,
                          unsigned char *dest, int length);
#pragma aux wshade_source_block = \
 "push ebp" \
 "cld" \
 "mov ebp, edx" \
 "mov ebx, 0" \
 "shadeloop: mov bl, [esi]" \
 "and bl, bl" \
 "je noshade" \
 "mov bl, [edi]" \
 "mov al, [ebp + ebx]" \
 "mov [edi], al" \
 "noshade: inc esi" \
 "inc edi" \
 "dec ecx" \
 "jnz shadeloop" \
 "pop ebp" \
parm [edx] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI wshade_source_block (unsigned char *shadetable, unsigned char *source,
                          unsigned char *dest, int leng)
{
	__asm {
		mov edx,shadetable
		mov esi,source
		mov edi,dest
		mov ecx,leng
		push ebp
		cld
		mov ebp, edx
		mov ebx, 0
		shadeloop: mov bl, [esi]
		and bl, bl
		je noshade
		mov bl, [edi]
		mov al, [ebp + ebx]
		mov [edi], al
		noshade: inc esi
		inc edi
		dec ecx
		jnz shadeloop
		pop ebp
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI wshade_translucent_block (unsigned char *shadetable,
                               unsigned char *source, unsigned char *dest,
                               int length);
#pragma aux wshade_translucent_block = \
 "push ebp" \
 "cld" \
 "mov ebp, edx" \
 "mov ebx, 0" \
 "shadeloop: mov bl, [esi]" \
 "and bl, bl" \
 "je noshade" \
 "mov bh, [edi]" \
 "mov al, [ebp + ebx]" \
 "mov [edi], al" \
 "noshade: inc esi" \
 "inc edi" \
 "dec ecx" \
 "jnz shadeloop" \
 "pop ebp" \
parm [edx] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI wshade_translucent_block (unsigned char *shadetable,
                               unsigned char *source, unsigned char *dest,
                               int leng)
{
	__asm {
		mov edx,shadetable
		mov esi,source
		mov edi,dest
		mov ecx,leng
		push ebp
		cld
		mov ebp, edx
		mov ebx, 0
		shadeloop: mov bl, [esi]
		and bl, bl
		je noshade
		mov bh, [edi]
		mov al, [ebp + ebx]
		mov [edi], al
		noshade: inc esi
		inc edi
		dec ecx
		jnz shadeloop
		pop ebp
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI wshade_mono_block (unsigned char *source, unsigned char *dest,
                        int length, unsigned char col);
#pragma aux wshade_mono_block = \
 "push ebp" \
 "cld" \
 "mov ebp, edx" \
 "mov ebx, 0" \
 "monoloop: mov bl, [esi]" \
 "and bl, bl" \
 "je nomono" \
 "mov [edi], al" \
 "nomono: inc esi" \
 "inc edi" \
 "dec ecx" \
 "jnz monoloop" \
 "pop ebp" \
parm [esi] [edi] [ecx] [al] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI wshade_mono_block (unsigned char *source, unsigned char *dest,
                        int leng, unsigned char col)
{
	__asm {
		mov esi,source
		mov edi,dest
		mov ecx,leng
		mov al,col
		push ebp
		cld
		mov ebp, edx
		mov ebx, 0
		monoloop: mov bl, [esi]
		and bl, bl
		je nomono
		mov [edi], al
		nomono: inc esi
		inc edi
		dec ecx
		jnz monoloop
		pop ebx
	}
}
#endif

void WGTAPI wputblock_shade (int x, int y, block src,
                             unsigned char *shadetable, int mode)
{
int width, height, display, maxy;
int ctr;
LPBYTE dst;
LPBYTE srcbits;
long pitch;

  if (src == NULL)
    return;

  width = wgetblockwidth (src);
  height = wgetblockheight (src);

  if (x + width > bx)
    display = (bx + 1) - x;
  else
    display = width;

  srcbits = wgetblocksurface (src, &pitch);
  if (!srcbits)
    goto _exit;             //LR --don't crash!

  if (x < tx)
    {
     srcbits += tx - x;
     display -= tx - x;
     x = tx;
    }                                    /* clip x */

  if (display <= 0)
    {
_exit:
     wunlocksurface (src);
     return;
    }

  maxy = y + height - 1;
  if (maxy > by)
    maxy = by;

  if (y < ty)
    {
     srcbits += (ty - y) * width;
     y = ty;
    }                                    /* clip y */

  dst = &abuf[y * WGT_SYS.screenwidth + x];

  if (mode == SHADE_NORMAL)
    for (ctr = y; ctr <= maxy; ctr++)
      {
       wshade_block (shadetable, srcbits, dst, display);
       srcbits += pitch;
       dst += WGT_SYS.screenwidth;
      }

  else if (mode == SHADE_XRAY)
    for (ctr = y; ctr <= maxy; ctr++)
      {
       wshade_xray_block (shadetable, srcbits, dst, display);
       srcbits += pitch;
       dst += WGT_SYS.screenwidth;
      }

  else if (mode == SHADE_SHADOW)
    for (ctr = y; ctr <= maxy; ctr++)
      {
       wshade_source_block (shadetable, srcbits, dst, display);
       srcbits += pitch;
       dst += WGT_SYS.screenwidth;
      }

  else if (mode == SHADE_TRANSLUCENT)
    for (ctr = y; ctr <= maxy; ctr++)
      {
       wshade_translucent_block (shadetable, srcbits, dst, display);
       srcbits += pitch;
       dst += WGT_SYS.screenwidth;
      }
  else if (mode == SHADE_MONO)
    for (ctr = y; ctr <= maxy; ctr++)
      {
       wshade_mono_block (srcbits, dst, display, *shadetable);
       srcbits += pitch;
       dst += WGT_SYS.screenwidth;
      }

 wunlocksurface (src);
}
