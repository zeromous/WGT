#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wellipse.c                                         
  Contains:     wellipse, wfill_ellipse                            
                                                                   
  Last Revised: February 19, 1996                                  
  Written By:   Barry Egerter               Windows 96 Version     
*/


/*
  Draws an ellipse                                                 
*/
void WGTAPI wellipse (int x_center, int y_center,
                      int x_radius, int y_radius)
{
int x,y;
int aa, aa2, bb, bb2, d, dx, dy;

  x = 0;
  y = y_radius;
  aa = (int)x_radius * (int)x_radius;
  aa2 = 2 * aa;
  bb = (int)y_radius * (int)y_radius;
  bb2 = 2 * bb;

  d = bb - aa * (int)y_radius + aa / 4;
  dx = 0;
  dy = aa2 * (int)y_radius;

  wputpixel (x_center, y_center - y);
  wputpixel (x_center, y_center + y);
  wputpixel (x_center - x_radius, y_center);
  wputpixel (x_center + x_radius, y_center);

  while (dx < dy)
    {
     if  (d > 0)
       {
        y--;
        dy -= aa2;
        d -= dy;
       }
     x++;
     dx += bb2;
     d += bb + dx;

     wputpixel (x_center + x, y_center + y);
     wputpixel (x_center - x, y_center + y);
     wputpixel (x_center + x, y_center - y);
     wputpixel (x_center - x, y_center - y);
    }

  d += (3 * (aa - bb) / 2 - (dx + dy)) / 2;
  while  (y > 0)
    {
     if  (d < 0)
       {
        x++;
        dx += bb2;
        d += bb + dx;
       }

     y--;
     dy -= aa2;
     d += aa - dy;
     wputpixel (x_center + x, y_center + y);
     wputpixel (x_center - x, y_center + y);
     wputpixel (x_center + x, y_center - y);
     wputpixel (x_center - x, y_center - y);
    }
}



/*
  Draws a filled ellipse                                           
*/
void WGTAPI wfill_ellipse (int x_center, int y_center,
                           int x_radius, int y_radius)
{
int x, y;
int aa, aa2, bb, bb2, d, dx, dy;

  x = 0;
  y = y_radius;
  aa = (int)x_radius * (int)x_radius;
  aa2 = 2 * aa;
  bb = (int)y_radius * (int)y_radius;
  bb2 = 2 * bb;
  d = bb - aa * (int)y_radius + aa / 4;
  dx = 0;              
  dy = aa2 * (int)y_radius;

  while (dx < dy)
    {
     if (d > 0)
       {
        wline (x_center + x, y_center + y, x_center - x, y_center + y);
        wline (x_center + x, y_center - y, x_center - x, y_center - y);
        y--;
        dy -= aa2;
        d -= dy;
       }

     x++;
     dx += bb2;
     d += bb + dx;
    }

  wline (x_center + x, y_center + y, x_center - x, y_center + y);
  wline (x_center + x, y_center - y, x_center - x, y_center - y);

  d += (3 * (aa - bb) / 2 - (dx + dy)) / 2;

  while  (y > 0)
    {
     if  (d < 0)
       {
        x++;
        dx += bb2;
        d += bb + dx;
       }

     y--;
     dy -= aa2;
     d += aa - dy;

     wline (x_center + x, y_center + y, x_center - x, y_center + y);
     wline (x_center + x, y_center - y, x_center - x, y_center - y);
    }
}



