#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>


/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wbezier.c                                          
  Contains:     wbezier                                            
                                                                   
  Last Revised: February 19, 1996       Windows 95 Version         
*/



/*
  Bezier curve algorithm submitted to us by Claude Morais          
*/
void WGTAPI wbezier (tpolypoint *rawpts, int numraw, tpolypoint *curvepts,
                     int numcurve)
{
double *combi;
double deltat, temp;
double prod, quot;
double sumx, sumy;
int  tmp, count;

  
  if (diagnostics_level & 2)
        wgt_log_message ("Entry of wbezier");
  combi = wmalloc (sizeof (double) * numraw);
  
  numraw--;
  deltat = 1.0 / (numcurve - 1);
  combi[0] = combi[numraw] = 1.0;
  
  for (tmp = 0; tmp <= (numraw - 2); tmp++)
    combi[tmp + 1] = (combi[tmp] * (numraw - tmp)) / (tmp + 1);
  
  for (count = 0; count < numcurve; count++)
    {
     if ((temp = count * deltat) <= 0.5)
       {
        quot = prod = 1.0 - temp;
        for (tmp = 1; tmp < numraw; tmp++)
          prod *= quot;

        quot = temp / quot;
        sumx = rawpts[numraw].x;
        sumy = rawpts[numraw].y;
        for (tmp = numraw - 1; tmp >= 0; tmp--)
          {
           sumx = combi[tmp]* rawpts[tmp].x + quot* sumx;
           sumy = combi[tmp]* rawpts[tmp].y + quot* sumy;
          }
       }
     else
       {
        quot = prod = temp;
        for (tmp = 1; tmp < numraw; tmp++)
          prod *= quot;
      
        quot = (1.0 - temp) / quot;
        sumx = rawpts[0].x;
        sumy = rawpts[0].y;
        for (tmp = 1; tmp <= numraw; tmp++)
          {
           sumx = combi[tmp]* rawpts[tmp].x + quot* sumx;
           sumy = combi[tmp]* rawpts[tmp].y + quot* sumy;
          }
       }
     curvepts[count].x = (short)(sumx*prod);
     curvepts[count].y = (short)(sumy*prod);
    }
  wfree (combi);
  if (diagnostics_level & 2)
        wgt_log_message ("Exit of wbezier");
}
