#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wscpoly.c                                          
  Contains:     wscan_convertpoly, wdraw_scanpoly, wfree_scanpoly  
                                                                   
  Last Revised: April 29, 1996                                     
                                                                   
  Written by:   Chris Egerter         Windows 95 Version           
*/


/* take binary sign of a, either -1, or 1 if >= 0 */
#define SGN(a)          (((a)<0) ? -1 : 1)

/* absolute value of a */
#define ABS(a)          (((a)<0) ? -(a) : (a))

extern short polygon_buffer_size;

/*
  Adds a point at (x,y) to a point buffer                         
*/
static void WGTAPI addpolypoint (short x, short y, wscanpoly *newp)
{
short points;
short *temp;

  if (newp->numpoints[y] == 0)          /* This is the first point on this row */
    {
     newp->pointbuffer[y] = malloc(2);   /* Allocate room for the point */
     newp->numpoints[y] = 2;             /* Set the number of points on this row */
     *(short *)newp->pointbuffer[y] = x;
     /* Store the x coordinate of this line */
    }
  else                            /* Points already exist on this row. */
    {
     points = newp->numpoints[y] + 2;
     temp = malloc (points);
     memcpy (temp, newp->pointbuffer[y], points - 2);
     free (newp->pointbuffer[y]);
     newp->pointbuffer[y] = temp;
     /* Make room for the new point */
     temp += (newp->numpoints[y]/2);
     *(short *)temp = x;
     /* Copy the new point into the row buffer */
     newp->numpoints[y] += 2; 
     /* Add another word to the size of this row buffer */
    }
}


/*
  Sorts two integers inside a point buffer (used with qsort)      
*/
static int wpolysort_function (const void *a, const void *b)
{
  return( *(short *)a - *(short *)b );
}



/*
  Sorts the points in a point buffer using qsort               
*/
static void WGTAPI sortpolypoints (short i, wscanpoly *newp)
{
  if (newp->numpoints[i] > 2)     /* Sort points, smallest x value first */
    qsort (newp->pointbuffer[i], newp->numpoints[i] / 2, 2, wpolysort_function);

   /* Each element is 2 bytes (1 word) and the number of elements in the 
   list is newp->numpoints[i] / 2, since numpoints[i] is stored in bytes. */
}


/*
  Calculate the x coordinates on the last line                     
*/
static void WGTAPI wpolyline (short x1, short y1, short x2, short y2,
                              wscanpoly *newp)
{
  short tmx, tmy, y;
  int x, m;

  if (y2 != y1)
    {
     if (y2 < y1)
       {
        tmy = y1;
        y1 = y2;
        y2 = tmy;
        tmx = x1;
        x1 = x2;
        x2 = tmx;
       }

     x = (int)x1 << 8;
     m = ((int)(x2 - x1) << 8) / ((int)(y2 - y1));
     x += m;
     y1++;

     for (y = y1; y <= y2; y++)
       {
        if ((y >= 0) && (y < WGT_SYS.yres))     /* In the legal range */
          addpolypoint ((short)(x >> 8), y, newp);
        x += m;
       }
   }
}           


/*
  Scan converts any polygon                                        
*/
void WGTAPI wscan_convertpoly (tpolypoint *vertexlist, int numvertex,
                               wscanpoly *scanpoly)
{
short i;
tpolypoint *curpt, *nextpt;

  curpt = vertexlist;
  nextpt = vertexlist + 1;

  scanpoly->pointbuffer = malloc (polygon_buffer_size * 4);
  scanpoly->numpoints = malloc (polygon_buffer_size * 2);

  for (i = 0; i < WGT_SYS.yres; i++)
    {
     scanpoly->pointbuffer[i] = NULL;
     scanpoly->numpoints[i] = 0;
    }


  for (i = 0; i < numvertex - 1; i++)
    {
     wpolyline (curpt->x, curpt->y, nextpt->x, nextpt->y, scanpoly);
     curpt += 1;
     nextpt += 1;
    }

  nextpt = vertexlist;
  wpolyline (curpt->x, curpt->y, nextpt->x, nextpt->y, scanpoly);

  for (i = 0; i < WGT_SYS.yres; i++)
    sortpolypoints (i, scanpoly);
}


/*
  Draws a scan-converted polygon                                   
*/
void WGTAPI wdraw_scanpoly (int x, int y, wscanpoly *scanpoly,
                            void (WGTAPI *customline)(int,int,int))
{
short *temp;
short i, j, ctr;
short end;

  if (customline == NULL)
    customline = (void *)whline;

  for (i = 0; i < WGT_SYS.yres; i++)
    {
     if (scanpoly->numpoints[i] > 0)
       {
        end = scanpoly->numpoints[i] / 4;
        temp = scanpoly->pointbuffer[i];
        ctr = i + y;
        if ((ctr >= 0) && (ctr < WGT_SYS.yres))
          for (j = 0; j < end; j++)
            (*customline)((*temp++) + x, (*temp++) + x, ctr);
      }
    }
}

/*
  Frees a scanned polygon                                          
*/
void WGTAPI wfree_scanpoly (wscanpoly *scanpoly)
{
short i;

  for (i = 0; i < polygon_buffer_size; i++)
    {
     if (scanpoly->numpoints[i] > 0)
       free (scanpoly->pointbuffer[i]);
    }

 free (scanpoly->pointbuffer);
 free (scanpoly->numpoints);
}

