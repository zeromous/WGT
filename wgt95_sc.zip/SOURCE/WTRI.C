#include <wgt5.h>
#include <malloc.h>

static struct {
  char patch_id[8];
  char fname[12];
  float version;
} patch_struct = {"WGTPATCH", "wtri", 1.0} ;

short *leftedge;
short *rightedge;

unsigned short *leftcolor;
unsigned short *rightcolor;

long *leftx;
long *rightx;
long *lefty;
long *righty;

block wgttexture;

extern short tx, bx, ty, by;

int slopesasm;

/*
�����������������������������������������������������������������ͻ
� Stores the x coordinates of a line into a table                 �
�����������������������������������������������������������������ͼ
*/
void scanedge_asm (int x, int length, short *edgelist, int slope);
#pragma aux scanedge_asm = \
  "scanloop: mov eax, ebx" \
  "shr eax, 16" \
  "stosw" \
  "add ebx, edx" \
  "dec cx" \
  "jnz scanloop" \
parm [ebx] [ecx] [edi] [edx] \
modify exact [eax ebx ecx edx esi edi] nomemory;


void scanedge (short *edgelist, short x1, short y1, short x2, short y2)
{
int x;
short length;
int slope;

 if (y2 >= ty)
 {
  x = (int)x1<<16;               /* Make a 16.16 fixed point number */
  slope = ((int)(x2 - x1 + 1)<<16) / (int)(y2 - y1 + 1);

  if (y1 < ty)
  {
   x += slope * ((int) ty -(int)y1);
   y1 = ty;
  }

 if (y2 > by)
   y2 = by;

 edgelist = &edgelist[y1];

 length = y2 - y1 + 1;

 if (length > 0)
  scanedge_asm (x, length, edgelist, slope);
 }

}


void wtriangle_solid (tpoint *ftri)
{
tpoint *top, *mid, *bot, *swaptri;
short y;
short l1, l2;

 top = &ftri[0];                /* Set up our original order */
 mid = &ftri[1];
 bot = &ftri[2];

 if (mid->y < top->y)           /* Sort the vertices by y coordinate */
   {
    swaptri = top;
    top = mid;
    mid = swaptri;
   }

 if (bot->y < top->y)
   {
    swaptri = top;
    top = bot;
    bot = swaptri;
   }

 if (bot->y < mid->y)
   {
    swaptri = mid;
    mid = bot;
    bot = swaptri;
   }


 if ((bot->y >= tx) && (top->y <= by))  /* on the screen at all */
   {
    /* The longest side must be from the top to the bottom, and the other
       side is split into two lines, from top to mid, and mid to bot.
       We scan the longest edge into the left buffer (doesn't matter which
       one) and the other edges in the right. */

    scanedge (leftedge, top->x, top->y, bot->x, bot->y);
    scanedge (rightedge, top->x, top->y, mid->x, mid->y);
    scanedge (rightedge, mid->x, mid->y, bot->x, bot->y);

    l1 = top->y;        /* Top y line to draw */
    l2 = bot->y;        /* Bottom y line draw */

    if (l2 > by)        /* Clip if needed */
	l2 = by;
    if (l1 < ty)
	l1 = ty;

    for (y = l1; y < l2; y++)  /* Draw each horizontal line */
      whline (leftedge[y], rightedge[y], y);
   }
}



/*
void gourasm (block dst, int length, int colorvalue, int step);
#pragma aux gourasm = \
  "mov esi,ecx" \
  "cmp ecx,1" \
  "je  gour_one" \
  "shr ecx,1" \
  "gourlineloop: mov dl,ah" \
  "add eax,ebx" \
  "mov dh,ah" \
  "add eax,ebx" \
  "mov [edi],dx" \
  "add edi,2" \
  "dec ecx" \
  "jnz gourlineloop" \
  "and esi,1" \
  "jz  gour_done" \
  "gour_one: mov [edi],ah" \
  "gour_done:" \
  parm [edi] [ecx] [eax] [ebx] \
  modify exact [eax ebx ecx edi esi];
*/
#pragma aux gourasm "_*" parm caller [edi] [ecx] [eax] [ebx] modify exact [eax ebx ecx edi esi];
extern void gourasm (block dst, int length, int colorvalue, int step);

void gour32asm (long *dst, int length, int colorvalue, int step);
#pragma aux gour32asm = \
  "gour32lineloop: mov [edi],eax" \
  "add eax,ebx" \
  "add edi,4" \
  "dec ecx" \
  "jnz gour32lineloop" \
  parm [edi] [ecx] [eax] [ebx] \
  modify exact [eax ebx ecx edi esi];


void gour16asm (unsigned short *dst, int length, int colorvalue, int step);
#pragma aux gour16asm = \
  "gour16lineloop: mov [edi],ax" \
  "add eax,ebx" \
  "add edi,2" \
  "dec ecx" \
  "jnz gour16lineloop" \
  parm [edi] [ecx] [eax] [ebx] \
  modify exact [eax ebx ecx edi esi];




void wgourline_tri (short x1, short x2, short y, unsigned short n1, 
		    unsigned short n2)
{
  extern short tx,ty,bx,by;
  block temp;
  int numcolors;
  int colorvalue;
  int length;
  short dist;
  int step;

   if (x1 > x2)
    {
     dist = x1;
     x1 = x2;
     x2 = dist;
     dist = n1;
     n1 = n2;
     n2 = dist;
    }

 if ((x2 >= tx) && (x1 <= bx))
  {
  length = x2 - x1 + 1;
  numcolors = n2 - n1;
  step = ((int)numcolors) / length;
  colorvalue = n1;
  
  if (x2 > bx)
      x2 = bx;
  if (x1 < tx)
   {
    colorvalue += step * (tx-x1);
    x1 = tx;
   }

  length = x2 - x1 + 1;
  temp = abuf + (y * WGT_SYS.xres) + x1;

  if (length > 0)
    gourasm (temp, length, colorvalue, step);
 }
}

#pragma aux transgourasm "_*" parm caller [edi] [ecx] [eax] [ebx] modify exact [eax ebx ecx edi esi];
extern void transgourasm (block dst, int length, int colorvalue, block table);


void wtransgourline_tri (short x1, short x2, short y, unsigned short n1, 
			 unsigned short n2, block shadetable)
{
  extern short tx,ty,bx,by;
  block temp;
  int numcolors;
  int colorvalue;
  int length;
  short dist;
  int step;

   if (x1 > x2)
    {
     dist = x1;
     x1 = x2;
     x2 = dist;
     dist = n1;
     n1 = n2;
     n2 = dist;
    }

 if ((x2 >= tx) && (x1 <= bx))
  {
  length = x2 - x1 + 1;
  numcolors = n2 - n1;
  step = ((int)numcolors) / length;
  colorvalue = n1;
  
  if (x2 > bx)
      x2 = bx;
  if (x1 < tx)
   {
    colorvalue += step * (tx-x1);
    x1 = tx;
   }

  length = x2 - x1;
  temp = abuf + (y * WGT_SYS.xres) + x1;

  slopesasm = step;

  if (length > 0)
    transgourasm (temp, length, colorvalue, shadetable);
 }
}


void wgscanedge (short *edgelist, unsigned short *colorlist,
		 short x1, short y1, unsigned short firstcolor,
		 short x2, short y2, unsigned short lastcolor)
{
int x;
int slope;


int length;

int numcolors;

int colorvalue;
int step;
int dist;

 if (y2 >= ty)
 {
  x = (long)x1<<16;              /* Make a 16.16 fixed point number */
  slope = ((long)(x2 - x1 + 1)<<16) / (long)(y2 - y1 + 1);

  length = y2 - y1 + 1;

  numcolors = lastcolor - firstcolor + 1;
  colorvalue = firstcolor;
  step = ((int)numcolors) / (int)length;

  if (y1 < ty)
  {
   dist = ty - y1;         /* Find number of pixels to be clipped */

   x += slope * dist;
   y1 = ty;
   /* Set left coordinate to the left clippin coordinate*/

   colorvalue += dist * step;
     /* Add dist color steps onto the starting value */

  }

 if (y2 > by)
   y2 = by;

 edgelist = &edgelist[y1];

 length = y2 - y1 + 1;

 if (length > 0)
 {
  scanedge_asm (x, length, edgelist, slope);

  /* Now calculate the shading */

  colorlist += y1;
  /* Make a pointer to the first pixel */

  gour16asm (colorlist, length, colorvalue, step);
 }
 }
}




void wtriangle_gouraud (tpoint *gtri)
{
tpoint *top, *mid, *bot, *swaptri;
short y;
short l1, l2;

 top = &gtri[0];                /* Set up our original order */
 mid = &gtri[1];
 bot = &gtri[2];

 if (mid->y < top->y)           /* Sort the vertices by y coordinate */
   {
    swaptri = top;
    top = mid;
    mid = swaptri;
   }

 if (bot->y < top->y)
   {
    swaptri = top;
    top = bot;
    bot = swaptri;
   }

 if (bot->y < mid->y)
   {
    swaptri = mid;
    mid = bot;
    bot = swaptri;
   }


 if ((bot->y >= tx) && (top->y <= by))  /* on the screen at all */
   {
    /* The longest side must be from the top to the bottom, and the other
       side is split into two lines, from top to mid, and mid to bot.
       We scan the longest edge into the left buffer (doesn't matter which
       one) and the other edges in the right. */

    wgscanedge (leftedge, leftcolor, top->x, top->y, top->col << 8,
				     bot->x, bot->y, bot->col << 8);
    wgscanedge (rightedge, rightcolor, top->x, top->y, top->col << 8, 
				       mid->x, mid->y, mid->col << 8);
    wgscanedge (rightedge, rightcolor, mid->x, mid->y, mid->col << 8, 
				       bot->x, bot->y, bot->col << 8);


    l1 = top->y;        /* Top y line to draw */
    l2 = bot->y;        /* Bottom y line draw */

    if (l2 > by)        /* Clip if needed */
	l2 = by;
    if (l1 < ty)
	l1 = ty;

    for (y = l1; y <= l2; y++)  /* Draw each horizontal line */
       wgourline_tri (leftedge[y], rightedge[y], y, leftcolor[y], rightcolor[y]);

   }
}


void wtriangle_translucent_gouraud (tpoint *gtri, block shadetable)
{
tpoint *top, *mid, *bot, *swaptri;
short y;
short l1, l2;

 top = &gtri[0];                /* Set up our original order */
 mid = &gtri[1];
 bot = &gtri[2];

 if (mid->y < top->y)           /* Sort the vertices by y coordinate */
   {
    swaptri = top;
    top = mid;
    mid = swaptri;
   }

 if (bot->y < top->y)
   {
    swaptri = top;
    top = bot;
    bot = swaptri;
   }

 if (bot->y < mid->y)
   {
    swaptri = mid;
    mid = bot;
    bot = swaptri;
   }


 if ((bot->y >= tx) && (top->y <= by))  /* on the screen at all */
   {
    /* The longest side must be from the top to the bottom, and the other
       side is split into two lines, from top to mid, and mid to bot.
       We scan the longest edge into the left buffer (doesn't matter which
       one) and the other edges in the right. */

    wgscanedge (leftedge, leftcolor, top->x, top->y, top->col << 8,
				     bot->x, bot->y, bot->col << 8);
    wgscanedge (rightedge, rightcolor, top->x, top->y, top->col << 8, 
				       mid->x, mid->y, mid->col << 8);
    wgscanedge (rightedge, rightcolor, mid->x, mid->y, mid->col << 8, 
				       bot->x, bot->y, bot->col << 8);


    l1 = top->y;        /* Top y line to draw */
    l2 = bot->y;        /* Bottom y line draw */

    if (l2 > by)        /* Clip if needed */
	l2 = by;
    if (l1 < ty)
	l1 = ty;
    
    for (y = l1; y < l2; y++)  /* Draw each horizontal line */
       wtransgourline_tri (leftedge[y], rightedge[y], y, leftcolor[y], rightcolor[y], shadetable);

   }
}


/*
void wtextline_asm (int xy, int slopes, block source, block dest, int length);
#pragma aux wtextline_asm = \
 "push ebp" \
 "push ecx" \
 "cld" \
 "mov ebp, eax" \
 "mov ebx, 0" \
 "shr ecx, 1" \
 "cmp ecx, 0" \
 "je onetexpixel"\
 "tlineloop: mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov al, [esi + ebx]" \
 "add edx, ebp" \
 "mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov ah, [esi + ebx]" \
 "add edx, ebp" \
 "stosw" \
 "dec ecx" \
 "jnz tlineloop" \
 "onetexpixel: pop ecx" \
 "and ecx, 1" \
 "jz tlinedone" \
 "mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov al, [esi + ebx]" \
 "mov [edi], al" \
 "tlinedone: pop ebp" \
parm [edx] [eax] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
*/
#pragma aux wtextline_asm "_*" parm caller [edx] [eax] [esi] [edi] [ecx] modify exact [eax ebx ecx edx edi esi];
extern void wtextline_asm (int xy, int slopes, block source, block dest, int length);



void wtextline_tri (long x1, long y1, long x2, long y2,
		short dstx1, short dstx2, short dsty)
{
block dest;

int xdiff, ydiff;
unsigned int xy;
int slopes;
int length;
int dist;
int xstep, ystep;

  if (dstx1 > dstx2)  /* Swap screen x's and texture x/y */
  {
    dist = dstx1;
    dstx1 = dstx2;
    dstx2 = dist;

    dist = x1;
    x1 = x2;
    x2 = dist;

    dist = y1;
    y1 = y2;
    y2 = dist;
  }

if ((dstx2 >= tx) && (dstx1 <= bx))
 {
  length = dstx2 - dstx1 + 1;

  xdiff = x2 - x1 + 256;
  ydiff = y2 - y1 + 256;

  xstep = xdiff / length;
  ystep = ydiff / length;
  slopes = (ystep << 16) + xstep;

  if (dstx1 < tx)
   {
    dist = tx - dstx1;
    x1 += xstep * dist;
    y1 += ystep * dist;
    dstx1 = tx;
   }

  if (dstx2 >= bx)
      dstx2 = bx;
  length = dstx2 - dstx1 + 1;

  if (length > 0)
   {
    xy = (y1 << 16) + x1;
    dest = abuf + (dsty * WGT_SYS.xres) + dstx1;
    wtextline_asm (xy, slopes, wgttexture, dest, length);
   }
 }
}


void wtscanedge (short *edgelist, long *xlist, long *ylist,
		short x1, short y1, long tx1, long ty1,
		short x2, short y2, long tx2, long ty2)
{
long x;
long slope;


int length;

int xdiff, ydiff;
int xstart, ystart;

int xstep, ystep;
long dist;

 if (y2 >= 0)
 {
  x = (long)x1<<16;              /* Make a 16.16 fixed point number */
  slope = ((long)(x2 - x1+1)<<16) / (long)(y2 - y1+1);

  length = y2 - y1 + 1;

  xdiff = tx2 - tx1;
  ydiff = ty2 - ty1;

  xstart = tx1;
  ystart = ty1;

  xstep = xdiff / length;
  ystep = ydiff / length;

  if (y1 < ty)
  {
   dist = ty - y1;         /* Find number of pixels to be clipped */

   x += slope * dist;
   y1 = ty;
   /* Set left coordinate to the left clippin coordinate*/

   xstart += dist * xstep;
   ystart += dist * ystep;
     /* Add x/y to starting texture coordinates */

  }

 if (y2 > by)
   y2 = by;

 edgelist = &edgelist[y1];

 length = y2 - y1 + 1;

 if (length > 0)
 { 
  scanedge_asm (x, length, edgelist, slope);


  /* Now calculate the tmapping coords */

  xlist += y1;
  ylist += y1;
  /* Make a pointer to the first pixel */

  gour32asm (xlist, length, xstart, xstep);
  gour32asm (ylist, length, ystart, ystep);
 }
 }
}




void wtriangle_texture (tpoint *ttri, block texture)
{
tpoint *top, *mid, *bot, *swaptri;
short y;
short l1, l2;

int topsx, topsy, midsx, midsy, botsx, botsy;

 top = &ttri[0];                /* Set up our original order */
 mid = &ttri[1];
 bot = &ttri[2];

 if (mid->y < top->y)           /* Sort the vertices by y coordinate */
   {
    swaptri = top;
    top = mid;
    mid = swaptri;
   }

 if (bot->y < top->y)
   {
    swaptri = top;
    top = bot;
    bot = swaptri;
   }

 if (bot->y < mid->y)
   {
    swaptri = mid;
    mid = bot;
    bot = swaptri;
   }


 if ((bot->y >= tx) && (top->y <= by))  /* on the screen at all */
   {
    /* The longest side must be from the top to the bottom, and the other
       side is split into two lines, from top to mid, and mid to bot.
       We scan the longest edge into the left buffer (doesn't matter which
       one) and the other edges in the right. */

    
    topsx = top->sx << 8;    
    topsy = top->sy << 8;    
    midsx = mid->sx << 8;    
    midsy = mid->sy << 8;    
    botsx = bot->sx << 8;    
    botsy = bot->sy << 8;    

    wtscanedge (leftedge, leftx, lefty,    top->x, top->y, topsx, 
	topsy, bot->x, bot->y, botsx, botsy);
    wtscanedge (rightedge, rightx, righty, top->x, top->y, topsx, 
	topsy, mid->x, mid->y, midsx, midsy);
    wtscanedge (rightedge, rightx, righty, mid->x, mid->y, midsx, 
	midsy, bot->x, bot->y, botsx, botsy);


    l1 = top->y;        /* Top y line to draw */
    l2 = bot->y;        /* Bottom y line draw */

    if (l2 > by)        /* Clip if needed */
	l2 = by;
    if (l1 < ty)
	l1 = ty;

    wgttexture = texture + 4;
    
    for (y = l1; y <= l2; y++)  /* Draw each horizontal line */
       wtextline_tri (leftx[y], lefty[y], rightx[y], righty[y],
		  leftedge[y], rightedge[y], y);

   }
}



/* Shaded tmapping */
block shadeptrasm;

/*
void wtextlineshade_asm (int xy, block shadetable, block source, block dest,
	int length);
#pragma aux wtextlineshade_asm = \
 "push ebp" \
 "push ecx" \
 "cld" \
 "mov ebp, eax" \
 "mov ebx, 0" \
 "shr ecx, 1" \
 "cmp ecx, 0" \
 "je onetexpixel"\
 "tlineloop: mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov al, [esi + ebx]" \
 "add edx, slopesasm" \
 "mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov ah, [esi + ebx]" \
 "add edx, slopesasm" \
 "mov bx, 0" \
 "mov bl, al" \
 "mov al, [ebp + ebx]" \
 "mov bl, ah" \
 "mov ah, [ebp + ebx]" \
 "stosw" \
 "dec ecx" \
 "jnz tlineloop" \
 "onetexpixel: pop ecx" \
 "and ecx, 1" \
 "jz tlinedone" \
 "mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov al, [esi + ebx]" \
 "mov bh, 0" \
 "mov bl, al" \
 "mov al, [ebp + ebx]" \
 "mov [edi], al" \
 "tlinedone: pop ebp" \
parm [edx] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
*/
#pragma aux wtextlineshade_asm "_*" parm caller [edx] [eax] [esi] [edi] [ecx] modify exact [eax ebx ecx edx edi esi];
extern void wtextlineshade_asm (int xy, block shadetable, block source, block dest, int length);


void wtextlineshade (long x1, long y1, long x2, long y2,
		     short dstx1, short dstx2, short dsty)
{
block dest;

int xdiff, ydiff;
unsigned int xy;
int slopes;
int length;
int dist;
int xstep, ystep;

  if (dstx1 > dstx2)  /* Swap screen x's and texture x/y */
  {
    dist = dstx1;
    dstx1 = dstx2;
    dstx2 = dist;

    dist = x1;
    x1 = x2;
    x2 = dist;

    dist = y1;
    y1 = y2;
    y2 = dist;
  }

if ((dstx2 >= tx) && (dstx1 <= bx))
 {
  length = dstx2 - dstx1 + 1;

  xdiff = x2 - x1 + 256;
  ydiff = y2 - y1 + 256;

  xstep = xdiff / length;
  ystep = ydiff / length;
  slopes = (ystep << 16) + xstep;

  if (dstx1 < tx)
   {
    dist = tx - dstx1;
    x1 += xstep * dist;
    y1 += ystep * dist;
    dstx1 = tx;
   }

  if (dstx2 >= bx)
      dstx2 = bx;
  length = dstx2 - dstx1 + 1;

  if (length > 0)
   {
    xy = (y1 << 16) + x1;
    dest = abuf + (dsty * WGT_SYS.xres) + dstx1;
    slopesasm = slopes;
    wtextlineshade_asm (xy, shadeptrasm, wgttexture, dest, length);
   }
 }
}


void wtriangle_flat_shaded_texture (tpoint *ttri, block texture, short shade,
				    block shadetable)
{
tpoint *top, *mid, *bot, *swaptri;
short y;
short l1, l2;

 top = &ttri[0];                /* Set up our original order */
 mid = &ttri[1];
 bot = &ttri[2];

 if (mid->y < top->y)           /* Sort the vertices by y coordinate */
   {
    swaptri = top;
    top = mid;
    mid = swaptri;
   }

 if (bot->y < top->y)
   {
    swaptri = top;
    top = bot;
    bot = swaptri;
   }

 if (bot->y < mid->y)
   {
    swaptri = mid;
    mid = bot;
    bot = swaptri;
   }


 if ((bot->y >= tx) && (top->y <= by))  /* on the screen at all */
   {
    /* The longest side must be from the top to the bottom, and the other
       side is split into two lines, from top to mid, and mid to bot.
       We scan the longest edge into the left buffer (doesn't matter which
       one) and the other edges in the right. */

    wtscanedge (leftedge, leftx, lefty,    top->x, top->y, top->sx << 8, 
	top->sy << 8, bot->x, bot->y, bot->sx << 8, bot->sy << 8);
    wtscanedge (rightedge, rightx, righty, top->x, top->y, top->sx << 8, 
	top->sy << 8, mid->x, mid->y, mid->sx << 8, mid->sy << 8);
    wtscanedge (rightedge, rightx, righty, mid->x, mid->y, mid->sx << 8, 
	mid->sy << 8, bot->x, bot->y, bot->sx << 8, bot->sy << 8);


    l1 = top->y;        /* Top y line to draw */
    l2 = bot->y;        /* Bottom y line draw */

    if (l2 > by)        /* Clip if needed */
	l2 = by;
    if (l1 < ty)
	l1 = ty;

    wgttexture = texture + 4;
    shadeptrasm = shadetable + shade * 256L;

    for (y = l1; y <= l2; y++)  /* Draw each horizontal line */
       wtextlineshade (leftx[y], lefty[y], rightx[y], righty[y],
		  leftedge[y], rightedge[y], y);

   }
}



/* Gouraud shaded texture mapping */
int tgourstep;
int lengthasm;
#pragma aux wtextlinegour_asm "_*" parm caller [edx] [esi] [edi] [ecx] modify exact [eax ebx ecx edx esi edi];
extern void wtextlinegour_asm (int xy, block source, block dest, int tgourval);

/*
void wtextlinegour_asm (int xy, block source, block dest, 
	int length);
#pragma aux wtextlinegour_asm = \
 "push ebp" \
 "cld" \
 "mov ebp, shadeptrasm" \
 "mov ebx, 0" \
 "tlineloop: mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov al, [esi + ebx]" \
 "add edx, slopesasm" \
 "mov bx, tgourval" \
 "add bx, tgourstep" \
 "mov tgourval, bx" \
 "mov bl, al" \
 "mov al, [ebp + ebx]" \
 "mov [edi], al" \
 "inc edi" \
 "dec ecx" \
 "jnz tlineloop" \
 "tlinedone: pop ebp" \
parm [edx] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
*/

void wtextgourline (long x1, long y1, long x2, long y2,
		     short dstx1, short dstx2, short col1, short col2,
		     short dsty)
{
block dest;

int xdiff, ydiff;
unsigned int xy;
int slopes;
int length;
int dist;
int xstep, ystep;
int numcolors;
int colorvalue;
int colstep;

  if (dstx1 > dstx2)  /* Swap screen x's and texture x/y */
  {
    dist = dstx1;
    dstx1 = dstx2;
    dstx2 = dist;

    dist = x1;
    x1 = x2;
    x2 = dist;

    dist = y1;
    y1 = y2;
    y2 = dist;
  
    dist = col1;
    col1 = col2;
    col2 = dist;
   }

if ((dstx2 >= tx) && (dstx1 <= bx))
 {
  length = dstx2 - dstx1 + 1;
  numcolors = col2 - col1 + 1;
  colstep = ((int)numcolors) / length;
  
  colorvalue = col1;

  xdiff = x2 - x1 + 256;
  ydiff = y2 - y1 + 256;

  xstep = xdiff / length;
  ystep = ydiff / length;
  slopes = (ystep << 16) + xstep;

  if (dstx1 < tx)
   {
    dist = tx - dstx1;
    x1 += xstep * dist;
    y1 += ystep * dist;
    colorvalue += colstep * dist;
    dstx1 = tx;
   }

  if (dstx2 >= bx)
      dstx2 = bx;
  length = dstx2 - dstx1 + 1;

  if (length > 0)
   {
    xy = (y1 << 16) + x1;
    dest = abuf + (dsty * WGT_SYS.xres) + dstx1;
    slopesasm = slopes;
    tgourstep = colstep;
    lengthasm = length;
    wtextlinegour_asm (xy, wgttexture, dest, colorvalue);
   }
 }
}


void wtgscanedge (short *edgelist, long *xlist, long *ylist, unsigned short *colorlist,
		short x1, short y1, long tx1, long ty1, short firstcolor,
		short x2, short y2, long tx2, long ty2, short lastcolor)
{
long x;
long slope;


int length;

int xdiff, ydiff;
int xstart, ystart;

int xstep, ystep;
long dist;

int numcolors;
int colorvalue;
int colorstep;

 if (y2 >= ty)
 {
  x = (long)x1<<16;              /* Make a 16.16 fixed point number */
  slope = ((long)(x2 - x1+1)<<16) / (long)(y2 - y1+1);

  length = y2 - y1 + 1;

  numcolors = lastcolor - firstcolor + 1;
  colorvalue = firstcolor;
  colorstep = ((int)numcolors) / (int)length;

  xdiff = tx2 - tx1 + 256;
  ydiff = ty2 - ty1 + 256;

  xstart = tx1;
  ystart = ty1;

  xstep = xdiff / length;
  ystep = ydiff / length;

  if (y1 < ty)
  {
   dist = ty - y1;         /* Find number of pixels to be clipped */

   x += slope * dist;
   y1 = ty;
   /* Set left coordinate to the left clippin coordinate*/

   xstart += dist * xstep;
   ystart += dist * ystep;
   colorvalue += dist * colorstep;
     /* Add x/y to starting texture coordinates */

  }

 if (y2 > by)
   y2 = by;

 edgelist = &edgelist[y1];

 length = y2 - y1 + 1;

 if (length > 0)
 { 
  scanedge_asm (x, length, edgelist, slope);


  /* Now calculate the tmapping coords */

  xlist += y1;
  ylist += y1;
  /* Make a pointer to the first pixel */

  gour32asm (xlist, length, xstart, xstep);
  gour32asm (ylist, length, ystart, ystep);

  
  colorlist += y1;
  /* Make a pointer to the first pixel */

  gour16asm (colorlist, length, colorvalue, colorstep);
 }
 }
}



void wtriangle_gouraud_shaded_texture (tpoint *ttri, block texture, 
				       block shadetable)
{
tpoint *top, *mid, *bot, *swaptri;
short y;
short l1, l2;

 top = &ttri[0];                /* Set up our original order */
 mid = &ttri[1];
 bot = &ttri[2];

 if (mid->y < top->y)           /* Sort the vertices by y coordinate */
   {
    swaptri = top;
    top = mid;
    mid = swaptri;
   }

 if (bot->y < top->y)
   {
    swaptri = top;
    top = bot;
    bot = swaptri;
   }

 if (bot->y < mid->y)
   {
    swaptri = mid;
    mid = bot;
    bot = swaptri;
   }


 if ((bot->y >= tx) && (top->y <= by))  /* on the screen at all */
   {
    /* The longest side must be from the top to the bottom, and the other
       side is split into two lines, from top to mid, and mid to bot.
       We scan the longest edge into the left buffer (doesn't matter which
       one) and the other edges in the right. */

    wtgscanedge (leftedge, leftx, lefty, leftcolor,
	top->x, top->y, top->sx << 8, top->sy << 8, top->col << 8, 
	bot->x, bot->y, bot->sx << 8, bot->sy << 8, bot->col << 8);
      
    wtgscanedge (rightedge, rightx, righty, rightcolor,
	top->x, top->y, top->sx << 8, top->sy << 8, top->col << 8, 
	mid->x, mid->y, mid->sx << 8, mid->sy << 8, mid->col << 8);
    wtgscanedge (rightedge, rightx, righty, rightcolor,
	mid->x, mid->y, mid->sx << 8, mid->sy << 8, mid->col << 8, 
	bot->x, bot->y, bot->sx << 8, bot->sy << 8, bot->col << 8);


    l1 = top->y;        /* Top y line to draw */
    l2 = bot->y;        /* Bottom y line draw */

    if (l2 > by)        /* Clip if needed */
	l2 = by;
    if (l1 < ty)
	l1 = ty;

    wgttexture = texture + 4;
    shadeptrasm = shadetable;

    for (y = l1; y <= l2; y++)  /* Draw each horizontal line */
     {
      wtextgourline (leftx[y], lefty[y], rightx[y], righty[y],
		  leftedge[y], rightedge[y], leftcolor[y], rightcolor[y], y);
     }
   }
}





/* Translucent texture */
#pragma aux wtranstextline_asm "_*" parm caller [edx] [esi] [edi] [ecx] modify exact [eax ebx ecx edx esi edi];
extern void wtranstextline_asm (int xy, block source, block dest, int length);

/*#pragma aux wtranstextline_asm = \
 "push ebp" \
 "cld" \
 "mov ebp, shadeptrasm" \
 "mov ebx, 0" \
 "tlineloop: mov ebx, edx" \
 "shr ebx, 16" \
 "mov bl, dh" \
 "mov bl, [esi + ebx]" \
 "mov bh, [edi]" \
 "add edx, eax" \
 "mov bl, [ebp + ebx]" \
 "mov [edi], bl" \
 "inc edi" \
 "dec ecx" \
 "jnz tlineloop" \
 "tlinedone: pop ebp" \
parm [edx] [eax] [esi] [edi] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
*/



void wtranstextline (long x1, long y1, long x2, long y2,
		     short dstx1, short dstx2, short dsty)
{
block dest;

int xdiff, ydiff;
unsigned int xy;
int slopes;
int length;
int dist;
int xstep, ystep;

  if (dstx1 > dstx2)  /* Swap screen x's and texture x/y */
  {
    dist = dstx1;
    dstx1 = dstx2;
    dstx2 = dist;

    dist = x1;
    x1 = x2;
    x2 = dist;

    dist = y1;
    y1 = y2;
    y2 = dist;
  }

if ((dstx2 >= tx) && (dstx1 <= bx))
 {
  length = dstx2 - dstx1 + 1;

  xdiff = x2 - x1 + 256;
  ydiff = y2 - y1 + 256;

  xstep = xdiff / length;
  ystep = ydiff / length;
  slopes = (ystep << 16) + xstep;

  if (dstx1 < tx)
   {
    dist = tx - dstx1;
    x1 += xstep * dist;
    y1 += ystep * dist;
    dstx1 = tx;
   }

  if (dstx2 >= bx)
      dstx2 = bx;
  length = dstx2 - dstx1;

  if (length > 0)
   {
    xy = (y1 << 16) + x1;
    dest = abuf + (dsty * WGT_SYS.xres) + dstx1;
    slopesasm = slopes;
    wtranstextline_asm (xy, wgttexture, dest, length);
   }
 }
}


void wtriangle_translucent_texture (tpoint *ttri, block texture, block shadetable)
{
tpoint *top, *mid, *bot, *swaptri;
short y;
short l1, l2;

int topsx, topsy, midsx, midsy, botsx, botsy;

 top = &ttri[0];                /* Set up our original order */
 mid = &ttri[1];
 bot = &ttri[2];

 if (mid->y < top->y)           /* Sort the vertices by y coordinate */
   {
    swaptri = top;
    top = mid;
    mid = swaptri;
   }

 if (bot->y < top->y)
   {
    swaptri = top;
    top = bot;
    bot = swaptri;
   }

 if (bot->y < mid->y)
   {
    swaptri = mid;
    mid = bot;
    bot = swaptri;
   }


 if ((bot->y >= tx) && (top->y <= by))  /* on the screen at all */
   {
    /* The longest side must be from the top to the bottom, and the other
       side is split into two lines, from top to mid, and mid to bot.
       We scan the longest edge into the left buffer (doesn't matter which
       one) and the other edges in the right. */

    
    topsx = top->sx << 8;    
    topsy = top->sy << 8;    
    midsx = mid->sx << 8;    
    midsy = mid->sy << 8;    
    botsx = bot->sx << 8;    
    botsy = bot->sy << 8;    

    wtscanedge (leftedge, leftx, lefty,    top->x, top->y, topsx, 
	topsy, bot->x, bot->y, botsx, botsy);
    wtscanedge (rightedge, rightx, righty, top->x, top->y, topsx, 
	topsy, mid->x, mid->y, midsx, midsy);
    wtscanedge (rightedge, rightx, righty, mid->x, mid->y, midsx,
	midsy, bot->x, bot->y, botsx, botsy);


    l1 = top->y;        /* Top y line to draw */
    l2 = bot->y;        /* Bottom y line draw */

    if (l2 > by)        /* Clip if needed */
	l2 = by;
    if (l1 < ty)
	l1 = ty;

    wgttexture = texture + 4;
    shadeptrasm = shadetable;

    for (y = l1; y < l2; y++)  /* Draw each horizontal line */
       wtranstextline (leftx[y], lefty[y], rightx[y], righty[y],
		       leftedge[y], rightedge[y], y);

   }
}





void winit_triangle_renderer (short maxrows)
{
 leftedge = malloc (maxrows * sizeof(short));
 rightedge = malloc (maxrows * sizeof(short));

 leftcolor = malloc (maxrows * sizeof(unsigned short));
 rightcolor = malloc (maxrows * sizeof(unsigned short));

 leftx = malloc (maxrows * sizeof(long));
 rightx = malloc (maxrows * sizeof(long));
 lefty = malloc (maxrows * sizeof(long));
 righty = malloc (maxrows * sizeof(long));
}


void wdeinit_triangle_renderer (void)
{
 free (leftedge);
 free (rightedge);

 free (leftcolor);
 free (rightcolor);

 free (leftx);
 free (rightx);
 free (lefty);
 free (righty);
}


/* Some other techniques captured from an IRC session (unused) */
/* Volt's stuff
[erg]   true
[Volt]  ; eax = color
[Volt]  ; ebx = left side x
[Volt]  ; ecx = right side ratio
[Volt]  ; edx = right side x
[Volt]  ; esi = left side ratio
[Volt]  ; edi = screen address
[Volt]  align 4
[Volt]  nctopDrawLoop:
[Volt]  mov bp, bx
[Volt]  add edi, ebp
[Volt]  mov bp, dx
[Volt]  sub bp, bx
[Volt]  xchg ebp, ecx
[Volt]  shr ecx, 1
[Volt]  even
[Volt]  rep stosw
[Volt]  jnc nctopNoMod
[Volt]  stosb
[Volt]  align 4
[Volt]  nctopNoMod:
[Volt]  mov ecx, ebp
[Volt]  xor ebp, ebp
[Volt]  mov bp, dx
[Volt]  sub edi, ebp
[Volt]  add edi, 320
[LOCAL]         PAUSED, CLICK ON ENTRY BOX TO RESUME
[Volt]  add ebx, esi
[Volt]  adc ebx, 0
[Volt]  add edx, ecx
[Volt]  adc edx, 0
[Volt]  dec [rCount]
[Volt]  jnz nctopDrawLoop
[Volt]  that does scan + fill...20 instructions


[Volt]  words were faster on my machine...
[erg]   but i had just this - add edi, ebp
[erg]   <Volt> mov bp, dx
[erg]   <Volt> sub bp, bx
[erg]   <Volt> xchg ebp, ecx
[erg]   <Volt> shr ecx, 1
[erg]   <Volt> even
[erg]   <Volt> rep stosw
[erg]   <Volt> jnc nctopNoMod
[erg]   <Volt> stosb
[erg]   <Volt> align 4
[erg]   <Volt> nctopNoMod:
[erg]   <Volt> mov ecx, ebp
<GooRoo>        what about clipping?
[Volt]  faster to vid mem
[erg]   <Volt> xor ebp, ebp
[erg]   <Volt> mov bp, dx
[erg]   <Volt> sub edi, ebp
[erg]   <Volt> add edi, 320
[erg]   <Volt> add ebx, esi
[erg]   <Volt> adc ebx, 0
[erg]   <Volt> add edx, ecx
[erg]   <Volt> adc edx, 0
[erg]   <Volt> dec [rCount]
[erg]   <Volt> jnz nctopDrawLoop
[erg]   [1] 00:58 er
[erg]   in reply to you <volt>
[Volt]  goo: I have 2 separate fills, one for totally unclipped and one for any type of clipped polies
*/
