#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       xor.c                                              
  Contains:     wxorbox                                            
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter      Windows 95 Version              
*/


/*
  Xor's a box on the screen with the color col                     
*/
void WGTAPI wxorbox (int x, int y, int x2, int y2, int col)
{
int i,j;                     /* Loop Control */
LPBYTE temp;                 /* Temp pointer to screen */

  if (y2 < y)                /* swap y's */
    {
     i = y;
     y = y2;
     y2 = i;
    }

  if (x2 < x)                /* swap x's */
    {
     i = x;
     x = x2;
     x2 = i;
    }
  
  if (y2 > by)
    y2 = by;                 /* Clip box */
  if (x2 > bx)
    x2 = bx;
  if (y < ty)
    y = ty;
  if (x < tx)
    x = tx;

  temp = &abuf[y * WGT_SYS.screenwidth + x];     /* Move to first offset */

  for (j = y; j <= y2; j++)
    {
     for  (i = x; i <= x2; i++)
       {
        /* This can be change to perform any logical operation
        on the pixels, such as & or | */
        *temp = *temp ^ col;
        /* XOR the pixel on screen with col and put it back on screen */
        temp++;                          /* Go to next pixel */
       }                                 /* x loop */
     temp += (WGT_SYS.screenwidth - 1) - (x2 - x);   /* Advance to next row */
   }                                     /* y loop */
}

