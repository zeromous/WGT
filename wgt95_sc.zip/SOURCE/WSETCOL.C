#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wsetcol.c                                          
  Contains:     wsetrgb, wsetcolor, wsetpalette, wreadpalette      
  Last Revised: February 20, 1996                                  
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/


/*
  Sets the RGB value of a palette register                         
*/
void WGTAPI wsetrgb (unsigned char num,
                     unsigned char red,
                     unsigned char green,
                     unsigned char blue, color *pal)
{
  if (red > 63)
    red = 63;             /* Check for maximum values */
  if (green > 63)
    green = 63;
  if (blue > 63)
    blue = 63;
  
  pal += num;                          /* Adjust pointer to proper index */
  pal->r = red;                        /* Set values for RGB */
  pal->g = green;
  pal->b = blue;
}



/*
  Sets the current drawing color                                   
*/
void WGTAPI wsetcolor (int col)
{
  currentcolor = col;
}


/*
  Set a block of the palette                                       
*/
void WGTAPI wsetpalette (int start, int finish,
                         color *pal)
{
        int                     i;
        PALETTEENTRY            newpal[256];
        int                     result;

  for (i = start; i <= finish; i++)
    {
     newpal[i - start].peRed   = pal[i].r << 2;
     newpal[i - start].peGreen = pal[i].g << 2;
     newpal[i - start].peBlue  = pal[i].b << 2;
     newpal[i - start].peFlags = (BYTE)0;
    }

  if (wgtddpal != NULL)
    {
     result = IDirectDraw4_WaitForVerticalBlank(wgtpdd,DDWAITVB_BLOCKBEGIN,NULL);
     i = finish - start + 1;
     result = IDirectDrawPalette_SetEntries (wgtddpal, 0, start, i, newpal);
     if (result != DD_OK)
       if (diagnostics_level & 2)
          wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
    }
}


/*
  Read a block of the palette                                      
*/
void WGTAPI wreadpalette (unsigned char start, unsigned char finish,
                          color *pal)
{
        int             i;
        PALETTEENTRY    newpal[256];
        int             result;

  if (wgtddpal != NULL)
    {
     result = IDirectDrawPalette_GetEntries (wgtddpal,0, start, (int)finish-(int)start+1, newpal);
     if (result != DD_OK)
        if (diagnostics_level & 2)
          wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));

     for (i = start; i <= finish; i++)
       {
        pal[i].r = newpal[i].peRed >> 2;
        pal[i].g = newpal[i].peGreen >> 2;
        pal[i].b = newpal[i].peBlue >> 2;
       }
    }
}
