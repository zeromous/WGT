#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <time.h>
#include <stdio.h>
#include <stdarg.h>
#include <ddraw.h>
#include <wgt95.h>
/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wgt95.c                                            
  Contains:     wcls                                               
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter            Windows 95 Version        
*/


/* Contains the procedure declarations and some misc functions */

short tx = 0,ty = 0,bx = 319,by = 199; /* clipping variables */
unsigned char currentcolor;

LPBYTE abuf;              /* pointer to the active screen */
LPDIRECTDRAW4 wgtpdd;     /* DirectDraw object */

WGT_SYS_STRUCT WGT_SYS;

short eggrules;

short wgterror;  /* Error status for WGT */
int     diagnostics_level;
/*
  Clears the screen                                                
*/
void WGTAPI wcls (unsigned char col)
{
  memset (abuf, col, WGT_SYS.screenwidth * WGT_SYS.screenheight);
}

/* Clears the screen using color fill */
void WGTAPI wclsfill (unsigned char col)
{
DDBLTFX ddbltfx;
int result;

  ddbltfx.dwSize = sizeof(ddbltfx);
  ddbltfx.dwFillColor = col;    //LR -- ?currentcolor;
  result = IDirectDrawSurface4_Blt (wgtbltdest, NULL, NULL, NULL, DDBLT_COLORFILL | DDBLT_WAIT,
           &ddbltfx);

  if (result != DD_OK)
    if (diagnostics_level & 2)
    wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
}


void WGTAPI wgt_init_log (void)
{
  time_t                time_of_day;
  char                  buffer[256];

  time_of_day = time (NULL);
  strftime (buffer, 80, "%A %B %d, %Y", localtime(&time_of_day));

  remove ("wgt95.log");
  wgt_log_message (buffer);
  wgt_log_message ("Log file initialized.....");
  wgt_log_message ("-------------------------");
}

void WGTAPI wgt_log_message (char *msg, ... )
{
  FILE *                outfile;
  time_t                time_of_day;
  char                  buffer[256];
  va_list               arglist;

  time_of_day = time (NULL);
  strftime (buffer, 256, "%H:%M:%S ", localtime(&time_of_day));
  outfile = fopen ("wgt95.log", "at");
  fprintf (outfile, "%s", buffer);
  va_start (arglist, msg);
  vfprintf (outfile, msg, arglist);
  va_end (arglist);
  fprintf (outfile, "\n");
  fclose (outfile);
}

typedef struct
{
    HRESULT     rval;
    LPSTR       str;
} ERRLIST;

static ERRLIST elErrors[] =
{
    { DD_OK, "DD_OK" },
    { DDERR_ALREADYINITIALIZED, "DDERR_ALREADYINITIALIZED" },
    { DDERR_CANNOTATTACHSURFACE, "DDERR_CANNOTATTACHSURFACE" },
    { DDERR_CANNOTDETACHSURFACE, "DDERR_CANNOTDETACHSURFACE" },
    { DDERR_CURRENTLYNOTAVAIL, "DDERR_CURRENTLYNOTAVAIL" },
    { DDERR_EXCEPTION, "DDERR_EXCEPTION" },
    { DDERR_GENERIC, "DDERR_GENERIC" },
    { DDERR_HEIGHTALIGN, "DDERR_HEIGHTALIGN" },
    { DDERR_INCOMPATIBLEPRIMARY, "DDERR_INCOMPATIBLEPRIMARY" },
    { DDERR_INVALIDCAPS, "DDERR_INVALIDCAPS" },
    { DDERR_INVALIDCLIPLIST, "DDERR_INVALIDCLIPLIST" },
    { DDERR_INVALIDMODE, "DDERR_INVALIDMODE" },
    { DDERR_INVALIDOBJECT, "DDERR_INVALIDOBJECT" },
    { DDERR_INVALIDPARAMS, "DDERR_INVALIDPARAMS" },
    { DDERR_INVALIDPIXELFORMAT, "DDERR_INVALIDPIXELFORMAT" },
    { DDERR_INVALIDRECT, "DDERR_INVALIDRECT" },
    { DDERR_LOCKEDSURFACES, "DDERR_LOCKEDSURFACES" },
    { DDERR_NO3D, "DDERR_NO3D" },
    { DDERR_NOALPHAHW, "DDERR_NOALPHAHW" },
    { DDERR_NOCLIPLIST, "DDERR_NOCLIPLIST" },
    { DDERR_NOCOLORCONVHW, "DDERR_NOCOLORCONVHW" },
    { DDERR_NOCOOPERATIVELEVELSET, "DDERR_NOCOOPERATIVELEVELSET" },
    { DDERR_NOCOLORKEY, "DDERR_NOCOLORKEY" },
    { DDERR_NOCOLORKEYHW, "DDERR_NOCOLORKEYHW" },
    { DDERR_NOEXCLUSIVEMODE, "DDERR_NOEXCLUSIVEMODE" },
    { DDERR_NOFLIPHW, "DDERR_NOFLIPHW" },
    { DDERR_NOGDI, "DDERR_NOGDI" },
    { DDERR_NOMIRRORHW, "DDERR_NOMIRRORHW" },
    { DDERR_NOTFOUND, "DDERR_NOTFOUND" },
    { DDERR_NOOVERLAYHW, "DDERR_NOOVERLAYHW" },
    { DDERR_NORASTEROPHW, "DDERR_NORASTEROPHW" },
    { DDERR_NOROTATIONHW, "DDERR_NOROTATIONHW" },
    { DDERR_NOSTRETCHHW, "DDERR_NOSTRETCHHW" },
    { DDERR_NOT4BITCOLOR, "DDERR_NOT4BITCOLOR" },
    { DDERR_NOT4BITCOLORINDEX, "DDERR_NOT4BITCOLORINDEX" },
    { DDERR_NOT8BITCOLOR, "DDERR_NOT8BITCOLOR" },
    { DDERR_NOTEXTUREHW, "DDERR_NOTEXTUREHW" },
    { DDERR_NOVSYNCHW, "DDERR_NOVSYNCHW" },
    { DDERR_NOZBUFFERHW, "DDERR_NOZBUFFERHW" },
    { DDERR_NOZOVERLAYHW, "DDERR_NOZOVERLAYHW" },
    { DDERR_OUTOFCAPS, "DDERR_OUTOFCAPS" },
    { DDERR_OUTOFMEMORY, "DDERR_OUTOFMEMORY" },
    { DDERR_OUTOFVIDEOMEMORY, "DDERR_OUTOFVIDEOMEMORY" },
    { DDERR_OVERLAYCANTCLIP, "DDERR_OVERLAYCANTCLIP" },
    { DDERR_OVERLAYCOLORKEYONLYONEACTIVE, "DDERR_OVERLAYCOLORKEYONLYONEACTIVE" },
    { DDERR_PALETTEBUSY, "DDERR_PALETTEBUSY" },
    { DDERR_COLORKEYNOTSET, "DDERR_COLORKEYNOTSET" },
    { DDERR_SURFACEALREADYATTACHED, "DDERR_SURFACEALREADYATTACHED" },
    { DDERR_SURFACEALREADYDEPENDENT, "DDERR_SURFACEALREADYDEPENDENT" },
    { DDERR_SURFACEBUSY, "DDERR_SURFACEBUSY" },
    { DDERR_SURFACEISOBSCURED, "DDERR_SURFACEISOBSCURED" },
    { DDERR_SURFACELOST, "DDERR_SURFACELOST" },
    { DDERR_SURFACENOTATTACHED, "DDERR_SURFACENOTATTACHED" },
    { DDERR_TOOBIGHEIGHT, "DDERR_TOOBIGHEIGHT" },
    { DDERR_TOOBIGSIZE, "DDERR_TOOBIGSIZE" },
    { DDERR_TOOBIGWIDTH, "DDERR_TOOBIGWIDTH" },
    { DDERR_UNSUPPORTED, "DDERR_UNSUPPORTED" },
    { DDERR_UNSUPPORTEDFORMAT, "DDERR_UNSUPPORTEDFORMAT" },
    { DDERR_UNSUPPORTEDMASK, "DDERR_UNSUPPORTEDMASK" },
    { DDERR_VERTICALBLANKINPROGRESS, "DDERR_VERTICALBLANKINPROGRESS" },
    { DDERR_WASSTILLDRAWING, "DDERR_WASSTILLDRAWING" },
    { DDERR_XALIGN, "DDERR_XALIGN" },
    { DDERR_INVALIDDIRECTDRAWGUID, "DDERR_INVALIDDIRECTDRAWGUID" },
    { DDERR_DIRECTDRAWALREADYCREATED, "DDERR_DIRECTDRAWALREADYCREATED" },
    { DDERR_NODIRECTDRAWHW, "DDERR_NODIRECTDRAWHW" },
    { DDERR_PRIMARYSURFACEALREADYEXISTS, "DDERR_PRIMARYSURFACEALREADYEXISTS" },
    { DDERR_NOEMULATION, "DDERR_NOEMULATION" },
    { DDERR_REGIONTOOSMALL, "DDERR_REGIONTOOSMALL" },
    { DDERR_CLIPPERISUSINGHWND, "DDERR_CLIPPERISUSINGHWND" },
    { DDERR_NOCLIPPERATTACHED, "DDERR_NOCLIPPERATTACHED" },
    { DDERR_NOHWND, "DDERR_NOHWND" },
    { DDERR_HWNDSUBCLASSED, "DDERR_HWNDSUBCLASSED" },
    { DDERR_HWNDALREADYSET, "DDERR_HWNDALREADYSET" },
    { DDERR_NOPALETTEATTACHED, "DDERR_NOPALETTEATTACHED" },
    { DDERR_NOPALETTEHW, "DDERR_NOPALETTEHW" },
    { DDERR_BLTFASTCANTCLIP, "DDERR_BLTFASTCANTCLIP" },
    { DDERR_NOBLTHW, "DDERR_NOBLTHW" },
    { DDERR_NODDROPSHW, "DDERR_NODDROPSHW" },
    { DDERR_OVERLAYNOTVISIBLE, "DDERR_OVERLAYNOTVISIBLE" },
    { DDERR_NOOVERLAYDEST, "DDERR_NOOVERLAYDEST" },
    { DDERR_INVALIDPOSITION, "DDERR_INVALIDPOSITION" },
    { DDERR_NOTAOVERLAYSURFACE, "DDERR_NOTAOVERLAYSURFACE" },
    { DDERR_EXCLUSIVEMODEALREADYSET, "DDERR_EXCLUSIVEMODEALREADYSET" },
    { DDERR_NOTFLIPPABLE, "DDERR_NOTFLIPPABLE" },
    { DDERR_CANTDUPLICATE, "DDERR_CANTDUPLICATE" },
    { DDERR_NOTLOCKED, "DDERR_NOTLOCKED" },
    { DDERR_CANTCREATEDC, "DDERR_CANTCREATEDC" },
    { DDERR_NODC, "DDERR_NODC" },
    { DDERR_WRONGMODE, "DDERR_WRONGMODE" },
    { DDERR_IMPLICITLYCREATED, "DDERR_IMPLICITLYCREATED" },
};

/*
 * getErrorString
 */
LPSTR WGTAPI getErrorString( HRESULT ddrval )
{
    int i;

    for( i=0;i<sizeof( elErrors )/sizeof( elErrors[0] );i++ )
    {
        if( ddrval == elErrors[i].rval )
        {
            return elErrors[i].str;
        }
    }
    return "Unknown Error Code";


} /* getErrorString */
