#include <stdlib.h>
#include <conio.h>
#include <dos.h>
#include <windows.h>
#include <wgt95.h>

/*
                    WordUp Graphics Toolkit 95                     
     Source Code    Copyright 1997 Egerter Software                

  Module:       wticker.c                                          
  Contains:     winittimer, wdonetimer, wsettimerspeed,            
                wstarttimer, wstoptimer                            
                                                                   
  Last Revised: July 21, 1997                                  
*/



#define TICKS(hz) (hz)
volatile int    wtimer_paused;
int             wtimer_rate;
static HANDLE   wtimer_thread;
static HANDLE   wtimer_Event;
volatile int    wtimer_time;
static void     TimerThread(void);
static CRITICAL_SECTION wtimer_cs;
int                             wtimer_hashighperf;
int                             wtimer_perffreq;

static void (*wusertimer)(void);

static long wtimer_gettime (void)
{
#ifdef __WATCOMC__
__int64 ticks;
#else
_int64 ticks;
#endif

  if (wtimer_hashighperf)
    {
     QueryPerformanceCounter ((LARGE_INTEGER*)&ticks);
     return (long)ticks;
    }

  return (long)timeGetTime ();
}


static void TimerThread(void)
{
long mylasttime;
int x;
int tickers;

    mylasttime = wtimer_gettime ();
 

    while (1)
    {
        // wait till it's time to wake up

        x = wtimer_gettime() - mylasttime;
        while (x < wtimer_rate)
        {
            Sleep(0);
            x = wtimer_gettime() - mylasttime;
        }
        mylasttime = wtimer_gettime();

        // increment our notion of time
        EnterCriticalSection(&wtimer_cs);
        if (!wtimer_paused)
        {
         tickers = x / wtimer_rate;
         mylasttime -= x % wtimer_rate;
         wtimer_time += tickers;

         if (wusertimer != NULL)
            while (tickers--)
              (*wusertimer) ();
            SetEvent(wtimer_Event);                     
        }   // let the other thread go now...

        LeaveCriticalSection(&wtimer_cs);
    }
}


void WGTAPI winittimer (void)
{
  wtimer_paused = FALSE;
}


void WGTAPI wdonetimer (void)
{
  // kill the thread
  TerminateThread(wtimer_thread,0);
  // remove the Event
  CloseHandle(wtimer_Event);
  // and the CS
  DeleteCriticalSection(&wtimer_cs);
}


void WGTAPI wsettimerspeed (int speed)
{
#ifdef __WATCOMC__
__int64 freq;
#else
_int64 freq;
#endif

BOOL highperf;
  
  wtimer_hashighperf = 0;

  if (speed)
  {
   highperf = QueryPerformanceFrequency ((LARGE_INTEGER*)&freq);
   if (!highperf)
          wtimer_rate = 1000 / speed;
   else
        {
     wtimer_hashighperf = 1;
         wtimer_perffreq = (int)freq;
     wtimer_rate = wtimer_perffreq / speed;
        }
  }
}


void WGTAPI wstarttimer (wtimerproc timer, int speed)
{
    DWORD id;
    // initialize our critical section
    InitializeCriticalSection(&wtimer_cs);

    EnterCriticalSection(&wtimer_cs);
    wtimer_paused = FALSE;
    // create our Event item
    wtimer_Event = CreateEvent (
        NULL,
        FALSE,  // auto-reset
        FALSE,  // initially not-signalled
        NULL
        );

    // create our timer thread
    wtimer_time = 0;   // start at time-slice zero
    wsettimerspeed (speed);   // speed in Hertz
    
    wtimer_thread = CreateThread(
        NULL,
            0,
        (LPTHREAD_START_ROUTINE) TimerThread,
        NULL,
        0,
        &id
        );  
    SetThreadPriority( wtimer_thread, THREAD_PRIORITY_NORMAL);
//    SetThreadPriority( wtimer_thread, THREAD_PRIORITY_ABOVE_NORMAL);
    wusertimer = timer;
    LeaveCriticalSection(&wtimer_cs);
}


void WGTAPI wstoptimer (void)
{
  wtimer_paused = TRUE;
}

