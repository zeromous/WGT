#include <string.h>
#include <stdlib.h>
#include <malloc.h>
#include <stdarg.h>
#include <stdio.h>
#include <wgt95.h>

typedef struct wmemptr
{
  char  name[255];
  void  *address;
  int   size;
  struct wmemptr *next;
} HEAPLIST;
  
static   HEAPLIST *MemArray = 0;
static   int InitFlag = 0;
static   int MaxMemAtOneTime = 0;
static   int TotalMemInUse = 0;
static   int TotalElements = 0;

int DebugMemory = 0;

#define  HDR_BYTES            0xEE
#define  HDR_SIZE             4
#define  WRAP_SIZE            (HDR_SIZE*2)


void mem_log_message (char *msg, ... )
{
  FILE *                outfile;
  va_list               arglist;

  outfile = fopen ("mem.log", "at");
  if (outfile == NULL)
    return;
  va_start (arglist, msg);
  vfprintf (outfile, msg, arglist);
  va_end (arglist);
  fprintf (outfile, "\n");
  fclose (outfile);
}

void mem_init_log (void)
{
  remove ("mem.log");
  mem_log_message ("Memory Log file initialized.....");
  mem_log_message ("-------------------------");
}


void  wclose_memory_manager (void)
{
HEAPLIST  *Cur = MemArray, *Next;

  if (!InitFlag)
    return;

  if ((TotalMemInUse) || (TotalElements))
    {
     if (DebugMemory)
       mem_log_message ("\n\n%d memory leak(s) detected using %d bytes", TotalElements, TotalMemInUse);

     while (Cur)
       {
        if (DebugMemory)
          mem_log_message ("Memory leak At:0x%08X Size:%d Owner:%s", Cur->address, Cur->size, Cur->name);
       
        Next = Cur->next;
        free ((char *)Cur->address - HDR_SIZE);
        free (Cur);
        Cur = Next;
      }
   }

   MemArray = 0;
   InitFlag = 0;
   TotalMemInUse = 0;
   TotalElements = 0;
}


void  wopen_memory_manager (void)
{
  if (InitFlag)
    wclose_memory_manager ();

   InitFlag = 1;

   MemArray = (HEAPLIST *)malloc (sizeof (HEAPLIST));

   if (!MemArray)
     exit (1);

   MemArray->address = 0;
   MemArray->next = 0;
   TotalElements = 0;

   if (DebugMemory)
     mem_init_log ();

   return;
}


void  wmemadd (void *Address, int Size, char *Owner)
{
HEAPLIST  *Cur = MemArray;

  if (!InitFlag)
    return;

  // Not top of list?
  if (Cur->address)
    {
     while (Cur->next)
       Cur = Cur->next;

     Cur->next = (HEAPLIST *)malloc (sizeof(HEAPLIST));

     if (!Cur->next)
       {
        mem_log_message ("Unable to add member to mem list");
        exit (1);
       }

     Cur = Cur->next;
    }

  Cur->address = Address;
  Cur->next = 0;
  Cur->size = Size;
  strcpy (Cur->name, Owner);
  TotalElements++;

  return;
}





int mvalidatechunk (HEAPLIST *Chunk)
{
int i;
unsigned char *Ptr;
HEAPLIST *Cur;

  if (Chunk == NULL)
    return 0;

  Cur = Chunk;
  Ptr = (unsigned char *) Cur->address - HDR_SIZE;

  for (i = 0; i < HDR_SIZE; i++)
    {
     if (Ptr[i] != HDR_BYTES)
       {
        if (DebugMemory)
          mem_log_message ("Memory Overrun (< 0) at address 0x%08X, Owner is %s", Ptr, Cur->name);
         return 1;
       }

     if (Ptr[i+Cur->size+HDR_SIZE] != HDR_BYTES)
       {
        if (DebugMemory)
          mem_log_message ("Memory Overrun (> Size) at address 0x%08X, Owner is %s", Ptr, Cur->name);
        return 1;
       }
    }

   return 0;
}



void * _wmalloc (int size, char *filename, int line)
{
char Owner[255]=" ";
void  *Ptr;

  if (!InitFlag)
    return NULL;

  size += WRAP_SIZE;

  Ptr = malloc (size);

  if (DebugMemory)
    mem_log_message ("%s (L%d) allocated %d bytes at 0x%08X", filename, line, size-WRAP_SIZE, Ptr);

  if (!Ptr)
    {
     if (DebugMemory)
       mem_log_message ("%s (L%d) failed to allocate RAM for %d bytes", filename, line, size-WRAP_SIZE);
     return 0;
    }

  memset (Ptr, 0, size);

  if (DebugMemory)
    sprintf (Owner, "%s (L%d)", filename, line);

  wmemadd ((unsigned char *) Ptr + HDR_SIZE, size-WRAP_SIZE, Owner);

  TotalMemInUse += size;

  if (TotalMemInUse > MaxMemAtOneTime)
    MaxMemAtOneTime = TotalMemInUse;

  memset (Ptr, HDR_BYTES, HDR_SIZE);
  memset (&((unsigned char *) Ptr)[size-HDR_SIZE], HDR_BYTES, HDR_SIZE);
  return (char *)Ptr + HDR_SIZE;
}



void  _wfree (void *Address, char *filename, int line)
{
HEAPLIST  *Cur = MemArray, *Prev = 0;

   if (!InitFlag)
     return;

  if (DebugMemory)
    mem_log_message ("%s (L%d) called deallocated memory at 0x%08X", filename, line, Address);

  while (Cur->address != Address)
    {
     if (Cur->next)
       {
        Prev = Cur;
        Cur = Cur->next;
       }
     else
       {   
        if (DebugMemory)
          mem_log_message ("%s (L%d) Unable to find free address in mem list at 0x%08X", filename, line, Address);
        return;
       }
    }

   mvalidatechunk (Cur);

   free( (char *)Address - HDR_SIZE);

   TotalMemInUse -= Cur->size+WRAP_SIZE;
   TotalElements--;

   // First element in list?
   if (!Prev)
      MemArray = Cur->next;
   else
      Prev->next = Cur->next;

   free (Cur);

   return;
}


int mvalidatememory (void)
{
int TotalErrors = 0;
HEAPLIST *Cur = MemArray;

  if (!InitFlag)
    return 0;

  for (;;)
    {
     if (Cur->address)
       {
        TotalErrors += mvalidatechunk (Cur);

        if (Cur->next)
          Cur = Cur->next;
        else
          break;
       }
     else
       {
        break;
       }
    }

  return TotalErrors;
}



void  wmemdumplog (void)
{
int Count = 0, TotalMemUsed = 0;
FILE *FP;
HEAPLIST *Cur = MemArray;

  FP = fopen ("mem.log", "at");
  if (!FP)
    return;

  fprintf (FP, "\n\nMemory Dump Follows:-\n");

  if (Cur->address)
    {
     while (Cur->address)
       {
        fprintf (FP, "----------------------------------\n");
        fprintf (FP, "     Owner:  %s\n", Cur->name);
        fprintf (FP, "   Address:  0x%08X\n", Cur->address);
        fprintf (FP, "    Length:  %d\n", Cur->size);

        Count++;
        TotalMemUsed += Cur->size + WRAP_SIZE;

        if (Cur->next)
          Cur = Cur->next;
        else
          break;
       }
    }

   fprintf (FP, "--------------------------------------------------------\n");
   fprintf (FP, "     Total memory in use:  %d\n", TotalMemUsed);
   fprintf (FP, "Total pointers allocated:  %d\n", Count);

   if (Count != TotalElements)
     fprintf( FP, "COUNTS ARE OUT OF SYNC!\n (%d & %d)", Count, TotalElements);

   if (TotalMemUsed != TotalMemInUse)
     fprintf (FP, "USES ARE OUT OF SYNC! (%d & %d)\n", TotalMemUsed, TotalMemInUse);

   fprintf (FP, "Most memory used by this program:  %d\n\n", MaxMemAtOneTime);

   fclose(FP);
}

/*
CHR   *SPDXFindMemOwner( void *Address )
{
MEMLIST  *Cur = MemArray;

   FUNC("_SPDXFindMemOwner");
   Assert(InitFlag == TRUE);
   Assert( Address );

   while( Cur )
   {
      if (Cur->Address == Address )
         return Cur->Owner;

      Cur = Cur->Next;
   }

   return NULL;
}
*/
