#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <io.h>
#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wloadfon.c                                         
  Contains:     wloadfont,  wfreefont                              
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter       Windows 95 Version             
*/


/*
  Loads a WGT font file                                            
*/
wgtfont WGTAPI wloadfont (char *filename)
{
wgtfont fptr,orig;
long size;

  /*
  Font file structure:
  header=15 bytes; (ignore)
  position of offset table=int
  128*data {
  int width;
  int height;
  char data (w*h bytes long);
  }
  offset table: 128 integers
  */
  

  /* Standard WGT library loading procedure */
  if (wgtlibrary == NULL)             /* Not loading from library file */
    {
     if ((libf = fopen (filename, "rb")) == NULL)
      return NULL;
    }
  else                                 /* Load font from within library file */
    {
     if ((libf = fopen (wgtlibrary, "rb")) == NULL)
       return NULL;
     readheader ();
     findfile (filename);
     if (lresult == 1)
       fseek (libf, lfpos, SEEK_SET);
     if (checkpassword (password) == 0)
       wfatalerror ("Incorrect password");
    }

  if ((wgtlibrary != NULL) && (lresult == 0))
    goto fontstop;


  if (wgtlibrary != NULL)
    size = lsize;
  else
    size = filelength(fileno(libf));

  fptr = wmalloc (size);

  if (fptr == NULL) 
    return NULL;
  
  orig = fptr;
  
  if  ((fread (fptr, size, 1, libf)) < 1)
    wfatalerror ("Read error (FONT) %s", filename);

  fontstop:
  ;
  fclose (libf);
  return orig;
}


/*
  Frees memory allocated by a font                                 
*/
void WGTAPI wfreefont (wgtfont ptr)
{
  wfree (ptr);
}
