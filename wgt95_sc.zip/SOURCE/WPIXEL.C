#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wpixel.c                                           
  Contains:     wgetpixel, wputpixel, wfastputpixel                
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter        Windows 95 Version            
*/



/*
  Gets the color at a point on the screen                          
*/
unsigned char WGTAPI wgetpixel (int x, int y)
{
  return abuf[y * WGT_SYS.screenwidth + x];
}

/*
  Puts a pixel on the current screen (with clipping)               
*/
void WGTAPI wputpixel (int x, int y)
{
  if  ((y <= by) & (x <= bx) & (y >= ty) & (x >= tx))
    abuf[y * WGT_SYS.screenwidth + x] = currentcolor;
}

/*
  Puts a pixel on the current screen (no clipping)                 
*/
void WGTAPI wfastputpixel (int x, int y)
{
  abuf[y * WGT_SYS.screenwidth + x] = currentcolor;
}
