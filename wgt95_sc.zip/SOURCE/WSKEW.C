#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wskew.c                                            
  Contains:     wskew                                              
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Barry Egerter           Windows 95 Version         
*/

/*
  This function takes a bitmap, screen coordinates, and number of  
  degress as parameters. The image is then redrawn to the virtual  
  screen, shifting each row of the bitmap to the left or the       
  right, depending on the degree value passed (negative/positive). 
*/
void WGTAPI wskew (int x, int y, block image, int degrees)
{
LPBYTE blkbits;
float newx, offs, slope;
int lnewx, lslope;
/* long values converted from floats (speed up) */
short ctr;                             /* y ctr */
short hgt, wid, display, shx, of2;
short onewx;
long pitch;


  hgt = wgetblockheight (image);       /* Find height of block */
  wid = wgetblockwidth (image);        /* Find width of block */
  slope = (float)degrees / 45;         /* Calculate slope of new image */
  offs = ((float)hgt / 2)*slope;       /* Find distance to shift horiz. */
  newx = (float)x + offs;              /* Calculate new x position */
  onewx = (int)newx;                   /* Store it as integer for clipping */
  lnewx = (int)((float)newx * 2000);   /* Convert floating pt to long int */
  lslope = (int)((float)slope * 2000); /* Convert floating pt to long int */

  blkbits = wgetblocksurface (image, &pitch);
  if (blkbits == NULL)
    return;

  /* Draw each row of image */
  for (ctr = y; ctr < y + hgt - 1; ctr++)
    {
     if (onewx + wid > bx)    /* Clip width */
       display = bx + 1 - onewx;
     else display = wid;

     if (onewx < tx)                   /* See if image overlaps left clip */
       {
        of2 = tx - onewx;                /* Find offset into bitmap */
        shx = tx;                        /* Set to draw starting here */
        display = display - of2;         /* New width to draw */
       }
     else
       {
        shx = onewx;                     /* X value is fine */
        of2 = 0;                         /* Use entire bitmap */
       }

    /* If width to display >0, and <= original width, and
    we are within top and bottom Y clipping boundaries:
    Copy row of bitmap to visual screen, using DISPLAY contiguous
    bytes.
    */

    if ((display > 0) & (display <= wid) & (ctr >= ty) & (ctr <= by))
      memcpy (&abuf[(ctr)*WGT_SYS.screenwidth + shx], &blkbits[(ctr - y)*pitch 
        + of2], display);
    lnewx = lnewx - lslope;
    /* Find X position after shifting next row */
    onewx = lnewx / 2000;
    /* Calculate integer value from long int   */
   }

 wunlocksurface (image);
}

