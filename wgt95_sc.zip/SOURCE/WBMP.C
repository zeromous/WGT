#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>


/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wbmp.c                                             
  Contains:     wloadbmp, wsavebmp                                 
                                                                   
  Last Revised: July 22, 1997
                                                                   
  Written by:   Barry Egerter         Windows 95 Version           
*/



#define pixels2bytes(n) ((n+7)/8)
#define greyvalue(r, g, b) (((r*30)/100) + ((g*59)/100) + ((b*11)/100))

typedef struct {
        char id[2];
        int  filesize;
        short reserved[2];
        int headersize;
        int infoSize;
        int width;
        int depth;
        short biPlanes;
        short bits;
        int biCompression;
        int biSizeImage;
        int biXPelsPerMeter;
        int biYPelsPerMeter;
        int biClrUsed;
        int biClrImportant;
        } BMPHEAD;

static void WGTAPI mono2vga (char *dst, char *p, short width);
static void WGTAPI ega2vga (char *dst, char *p, short width);
static void WGTAPI rgb2vga (char *dst, char *p, short width);
static void WGTAPI storeline (unsigned char *dst, char *p, int n, int pitch);

static unsigned char masktable[8]={0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};

static BMPHEAD bmp;
extern block currentscreen;


block WGTAPI wloadbmp (char *filename, color *pal)
/*
   Load a BMP file, store file in memory as a BLK format image
   Handles all formats and mode conversions..... returns NULL if any errors
   (24-bit color included)
*/
{
unsigned char *pr, *linebuf;
short i,n;
unsigned short bytes;
fpos_t fileposition;
block blk, result;
unsigned char *blkbits;
long pitch;

  /* set a default monochrome palette */
  memcpy (&pal[0], "\000\000\000\377\377\377", 6);
  
  if (wgtlibrary == NULL)
    {
     if ((libf = fopen (filename, "rb")) == NULL)
       return NULL;
    }
  else
    {
     if ((libf = fopen (wgtlibrary, "rb")) == NULL)
       return NULL;
     readheader ();
     findfile (filename);
     if (lresult == 1)
       fseek (libf, lfpos, SEEK_SET);
     if (checkpassword (password) == 0)
       {
        wfatalerror ("Incorrect password");
       }
    }
  
  if ((wgtlibrary != NULL) & (lresult == 0)) goto lblkstop;
  
  fgetpos (libf, &fileposition);
  /* get the header */
  if  (fread ((char *)&bmp, 1, sizeof(BMPHEAD), libf) == sizeof(BMPHEAD)) 
    {
     /* check the header */
     if (!memcmp (bmp.id, "BM", 2)) 
       {
        /* set the details */
        if (bmp.biCompression)
          {  
           fclose (libf);
           return NULL;
          }

        blk = wallocblock (bmp.width, bmp.depth);
        if (blk == NULL)
          {
           fclose (libf);
           return NULL;
          }

      result = blk;
      blkbits = wgetblocksurface (blk, &pitch);
      if (blkbits == NULL)
        {
         fclose (libf);
         return NULL;
        }

      /* work out the line width */
      if  (bmp.bits == 1) bytes = pixels2bytes(bmp.width);
      else if  (bmp.bits == 4) bytes = pixels2bytes(bmp.width) << 2;
      else if  (bmp.bits == 8) bytes = bmp.width;
      else if  (bmp.bits == 24) bytes = bmp.width*3;
      
      /* round up to an even dword boundary */
      if (bytes & 0x0003) 
        {
         bytes |= 0x0003;
         ++bytes;
        }
      
      /* get the palette */
      if  (bmp.bits > 1 && bmp.bits <= 8) 
      {
        n = 1 << bmp.bits;
        for  (i = 0; i < n; ++i)
        {
          pal[i].b = fgetc (libf) >> 2;
          pal[i].g = fgetc (libf) >> 2;
          pal[i].r = fgetc (libf) >> 2;
          fgetc (libf);
        }
      }
      else if  (bmp.bits == 24) 
      {
        for  (i = 0; i < 256; i++)
          memset (&pal[i].r, (i >> 2), 3);
      }
      
      /* allocate a line buffer */
      if  (((linebuf = wmalloc (bytes)) != NULL) &&
          ((pr = wmalloc (bmp.width)) != NULL))
      {
        /* find the end of the header data */
        fseek (libf, (long)fileposition + bmp.headersize, SEEK_SET);
        
        for  (i = 0; i < bmp.depth; i++) 
        {
          if  (fread (linebuf, 1, bytes, libf) != bytes) 
          {
            wfree (result);
            wfree (linebuf);
            wfree (pr);
            result = NULL;
            goto lblkstop;
          }
          
          /* translate the line types into VGA */
          switch  (bmp.bits) 
          {
            case 1:  mono2vga (pr, linebuf, (short)bmp.width);  break;
            case 4:  ega2vga (pr, linebuf, (short)bmp.width);   break;
            case 8:  storeline (blkbits, linebuf, bmp.depth - 1 - i, pitch); break;
            case 24: rgb2vga (pr, linebuf, (short)bmp.width);   break;
          }
          if (bmp.bits != 8)
            storeline (blkbits, pr, bmp.depth - 1 - i, pitch);
        }
        wfree (linebuf);
        wfree (pr);
        wunlocksurface (blk);
        goto lblkstop;
      } else 
      {
        wfree (pr);
        wfree (linebuf);
        wunlocksurface (blk);
        wfree (result);
        result = NULL;
        goto lblkstop;
      }
    } else result = NULL;
  } else result = NULL;
  lblkstop:
  ;
  fclose (libf);
  return (result);
}



short WGTAPI wsavebmp (char *filename, block image, color *pal)
/*
   Save a BMP file, from screen location to disk file
*/
{
FILE *fp;
int i, bytes;
BMPHEAD bmp;
unsigned char *blkbits;
long pitch;
  
  fp = fopen (filename, "wb");
  if (fp == NULL)
    return (1);

  bmp.id[0] = 'B';
  bmp.id[1] = 'M';
  bytes = bmp.width = wgetblockwidth (image);
  bmp.depth = wgetblockheight (image);
  bmp.bits = 8;
  bmp.biPlanes = 1;
  bmp.headersize = sizeof(BMPHEAD) + 1024;
  bmp.infoSize = 0x28;
  bmp.biCompression = 0;
  bmp.biClrUsed = 0;
  bmp.biSizeImage = bytes*bmp.depth;
  bmp.biClrImportant = 0;
  bmp.biXPelsPerMeter = 0;
  bmp.biYPelsPerMeter = 0;
  fwrite (&bmp, sizeof(BMPHEAD), 1, fp);

  /* round up to an even dword boundary */
  if  (bytes & 0x0003)
  {
    bytes |= 0x0003;
    ++bytes;
  }

  for  (i = 0; i < 256; ++i)
  {
    fputc (pal[i].b << 2, fp);
    fputc (pal[i].g << 2, fp);
    fputc (pal[i].r << 2, fp);
    fputc (0, fp);
  }

  blkbits = wgetblocksurface (image, &pitch);
  for (i = 0; i < bmp.depth; i++)
    fwrite (blkbits + (bmp.depth - 1 - i) * pitch, 1, bytes, fp);

  fclose (fp);
  return (0);
}


/* convert a monochrome line into an eight bit line */
void WGTAPI mono2vga (char *dst, char *p, short width)
{
  short i;
  
  for  (i = 0;i < width;++i) 
  {
    if  (p[i >> 3] & masktable[i & 0x0007]) dst[i] = 1;
    else dst[i] = 0;
  }
}


/* convert a four bit line into an eight bit line */
void WGTAPI ega2vga (char *dst, char *p, short width)
{
  short i,j = 0;
  
  for  (i = 0;i < width;) 
  {
    dst[i++] = (p[j] >> 4) & 0x0f;
    dst[i++] = p[j] & 0x0f;
    ++j;
  }
}


/* convert an RGB line into an eight bit line */
void WGTAPI rgb2vga (char *dst, char *p, short width)
{
  short i;
  
  for  (i = 0;i < width;++i) 
  {
    dst[i] = greyvalue (p[0], p[1], p[2]);
    p += 3;
  }
}


void WGTAPI storeline (unsigned char *dst, char *p, int n, int pitch)
{
  memcpy (dst + (n * pitch), p, bmp.width);
}

