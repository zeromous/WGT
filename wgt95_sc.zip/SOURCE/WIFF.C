#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wiff.c                                             
  Contains:     wloadiff, wsaveiff (not working)                   
  Last Revised: April 29, 1996                                     
                                                                   
  Written by:   Barry Egerter        Windows 95 Version            
*/


#define GOOD_READ       0       /* return codes */
#define BAD_FILE        1
#define GOOD_WRITE      0       /* return codes */
#define BAD_WRITE       1
#define BAD_READ        2
#define MEMORY_ERROR    3

#define pixels2bytes(n) ((n+7)/8)

typedef struct {
	short width,depth,bytes,bits;
	short flags;
	short background;
	char subtype[4];
	} FILEINFO;

typedef struct {
	unsigned short w,h;
	short x,y;
	char nPlanes;
	char masking;
	char compression;
	char pad1;
	unsigned short transparentColor;
	char xAspect,yAspect;
	short pageW,pageH;
	} BMHD;

int WGTAPI motr2intl (int l);
void WGTAPI getline (char *p, unsigned char *image, short n, short line, long pitch);
void WGTAPI fputlong (FILE *fp, int n);
void WGTAPI fputword (FILE *fp, short n);
unsigned short WGTAPI motr2inti (unsigned short n);
char * WGTAPI planes2bytes (char *p, FILEINFO *fi);
int WGTAPI readline (char *p, FILE *fp, short bytes);

void WGTAPI putiffline (unsigned char *buffer, char *p, unsigned short n, long pitch);
block WGTAPI unpackiff (FILE *fp, FILEINFO *fi, color *pal);
void writeline (FILE *fp, char *p, short n);

FILEINFO fi;


block WGTAPI wloadiff (char *filename, color *pal)
{
block buffer = NULL;

  if  (wgtlibrary == NULL)
  {
    if  ((libf = fopen (filename, "rb")) == NULL)
      return NULL;
  }
  else
  {
    if  ((libf = fopen (wgtlibrary, "rb")) == NULL)
      return NULL;
    readheader ();
    findfile (filename);
    if  (lresult == 1)
      fseek (libf, lfpos, SEEK_SET);
    if  (checkpassword (password) == 0)
     {
      wfatalerror ("Incorrect password");
     }
  }
  
  if  ((wgtlibrary != NULL) & (lresult == 0)) goto lblkstop;
  buffer = unpackiff (libf, &fi, pal);
  lblkstop:
  ;
  fclose (libf);
  return buffer;
}


/* unpack an IFF/LBM file */
block WGTAPI unpackiff (FILE *fp, FILEINFO *fi, color *pal)
{
block buffer = NULL;
char *blkbits= NULL;
BMHD bmhd;
unsigned int l;
char *p, *pr, b[4];
short i, n;
long pitch;

  /* get the type */
  fread (b, 1, 4, fp);
  if(!memcmp(b, "FORM", 4) || !memcmp(b, "LIST", 4) || !memcmp(b, "CAT ", 4))
  {
    /* ignore the size */
    fread ((char *)&l, 1, 4, fp);

    /* get the subtype */
    fread (fi->subtype, 1, 4, fp);

    /* read all the chunks */
    do {
      fread (b, 1, 4, fp);
      fread ((char *)&l, 1, 4, fp);
      l = motr2intl (l);
      if (l & 1L)
	++l;

      /* check for a bitmap header */
      if (!memcmp (b, "BMHD", 4))
      {
	if (fread ((char *)&bmhd, 1, sizeof(BMHD), fp) != sizeof (BMHD))
	  return (NULL);
	fi->width = motr2inti (bmhd.w);
	fi->depth = motr2inti (bmhd.h);
	fi->bits = bmhd.nPlanes;
	if (!memcmp (fi->subtype, "ILBM", 4))
	  fi->bytes = pixels2bytes (fi->width) * fi->bits;
	else
	  fi->bytes = fi->width;
      }

      /* check for a palette */
      else if (!memcmp (b, "CMAP", 4))
      {
	if ((short)l <= 768)
	{
	  if (fread (pal, 1, (short)l, fp) != (unsigned short)l)
	    return (NULL);
	}
	  else
	{
	  if (fread (pal, 1, 768, fp) != 768)
	    return (NULL);
	  fseek (fp, l-768L, SEEK_SET);
	}

	for (i = 0; i < 256; i++)
	{
	  pal[i].r >>= 2;
	  pal[i].g >>= 2;
	  pal[i].b >>= 2;
	}
      }

      /* check for an image */
      else if (!memcmp (b, "BODY", 4))
      {
         buffer = wallocblock (fi->width, fi->depth);
         if (buffer == NULL)
           return (NULL);
         blkbits = wgetblocksurface (buffer, &pitch);
         if (blkbits == NULL)
           return (NULL);

         if ((p = wmalloc (fi->width)) != NULL)
           {
            for (i = 0; i < fi->depth; ++i) 
              {
               if (bmhd.compression)
                 n = readline (p, fp, fi->bytes);
               else
                 n = fread (p, 1, fi->bytes, fp);

               if (n != fi->bytes)
                 {
                  wunlocksurface (buffer);
                  wfreeblock (buffer);
                  buffer = NULL;
                  wfree (p);
                  return (NULL);
	    }

	    if (!memcmp (fi->subtype, "ILBM", 4) ||
	       (!memcmp(fi->subtype, "PBM ", 4) && fi->bits < 8))
	    {
	      if ((pr = planes2bytes (p, fi)) == NULL)
	      {
		wfree (buffer);
		buffer = NULL;
		wfree (p);
		return (NULL);
	      }
              putiffline (blkbits, pr, i, pitch);
	      wfree (pr);
            } else putiffline (blkbits, p, i, pitch);
	  }
	  wfree(p);
          wunlocksurface (buffer);
	  return (buffer);
	} else return (NULL);
      }

      /* skip an unknown chunk */
      else fseek(fp, l, SEEK_CUR);

    } while(!ferror (fp) && memcmp (b, "BODY", 4));
    return (buffer);
  } else return (NULL);
}

/* convert a planar line to a VGA line */
char * WGTAPI planes2bytes (char *line, FILEINFO *fi)
{
  char masktable[8]={0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
  char bittable[8] ={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

  char *p, *pr;
  short i, j, n;

  /* allocate a place to put the line */
  if((p = wmalloc (fi->width)) != NULL) {

    /* get the width of one plane */
    n = pixels2bytes (fi->width);

    /* sscan through the pixels */
    for(i = 0; i < fi->width; ++i)
     {
      pr = line;
      p[i] = 0;

      /* fetch each planar pixel */
      for(j = 0;j < fi->bits; ++j)
	{
	 if(pr[i>>3] & masktable[i & 0x0007])
	   p[i] |= bittable[j];
	 pr += n;
	}
    }
    return (p);
  }
  return (NULL);
}


/* read a compressed PackBits line */
int WGTAPI readline (char *p, FILE *fp, short bytes)
{
  short c, i, n = 0;

  do {
    c = fgetc (fp) & 0xff;
    if (c & 0x80)
    {
      if (c != 0x80)
      {
	i = ((~c) & 0xff)+2;
	c = fgetc (fp);
	while (i--) 
	  p[n++] = (unsigned char)c;
      }
    }
      else 
    {
      i = (c & 0xff)+1;
      while (i--)
	p[n++] = fgetc (fp);
    }
  } while (n < bytes);
  return (n);
}



int WGTAPI motr2intl (int l)
{
  return(((l & 0xff000000L) >> 24) + ((l & 0x00ff0000L) >> 8) +
	 ((l & 0x0000ff00L) << 8) + ((l & 0x000000ffL) << 24));
}



/* save one line to memory */
void WGTAPI putiffline (unsigned char *buffer, char *p, unsigned short n, long pitch)
{
  if (n < fi.depth)
    memcpy (buffer + (int)n * (int)pitch, p, fi.width);
}


void WGTAPI writeiff (FILE *fp, unsigned short width, unsigned short depth, block image,
	  color *palette);

short WGTAPI wsaveiff (char *filename, block image, color *pal)
{
FILE *out;

  if ((out = fopen (filename, "wb")) != NULL) 
  {
    writeiff (out, wgetblockwidth (image), wgetblockheight (image), image, pal);
    fclose(out);
    return 0;
  } else return 1;
}


/* write an IFF/LBM file */
void WGTAPI writeiff (FILE *fp, unsigned short width, unsigned short depth, block image,
       	  color *palette)
{
color pal[256];
BMHD bmhd;
int l,pos;
char *p;
short i;
char *blkbits= NULL;
long pitch;

  blkbits = wgetblocksurface (image, &pitch);

  /* write the header */
  fwrite ("FORM", 1, 4, fp);

  /* write a dummy long to hold the final length */
  fputlong (fp, 0);

  /* write the subtype */
  fwrite("PBM ", 1, 4, fp);

  /* allocate a line buffer */
  if ((p = wmalloc (width)) == NULL)
    return;

  /* write the bitmap header chunk */
  fwrite ("BMHD", 1, 4, fp);
  fputlong (fp, (int)sizeof (BMHD));

  /* load up the BMHD struct with this image's data */
  memset ((char *)&bmhd, 0, sizeof (BMHD));
  bmhd.w = motr2inti (width);
  bmhd.h = motr2inti (depth);
  bmhd.nPlanes = 8;
  bmhd.compression = 1;
  bmhd.pageW = motr2inti (width);
  bmhd.pageH = motr2inti (depth);
  fwrite ((char *)&bmhd, 1, sizeof(BMHD), fp);

  /* write the colour map*/
  memcpy (pal, palette, 768);
  for (i = 0; i < 256; i++)
  {
    pal[i].r <<= 2;
    pal[i].g <<= 2;
    pal[i].b <<= 2;
  }
  fwrite ("CMAP", 1, 4, fp);
  fputlong (fp, 768);
  fwrite (pal, 1, 768, fp);

  /* write the image */
  fwrite("BODY", 1, 4, fp);

  /* put in a dummy long for the chunk size */
  fputlong (fp, 0);
  pos = ftell (fp);

  /* compress all the lines */
  for (i = 0; i < depth; ++i)
  {
    /* get a line */
    getline (p, blkbits, width, i, pitch);
    /* write the line */
    writeline (fp, p, width);
  }

  /* the chunk size must be filled in */
  l=ftell (fp)-8L;
  if(l & 1L)
  {
    fputc (0, fp);
    ++l;
  }
  fseek (fp, pos, SEEK_SET);
  fputlong (fp, l - pos);

  /* since this is the last chunk, the file size must also be filled in */
  fseek (fp, 4, SEEK_SET);
  fputlong (fp, l);

  wfree (p);
  wunlocksurface (image);
}


/* do packbits compression for one line of image data */
void writeline (FILE *fp, char *p, short n)
{
 signed char b[128];
 unsigned short bdex = 0,i = 0,j = 0,t = 0;

     do {
		i = 0;
		while((p[t+i] == p[t+i+1]) &&
		      (i < 127) &&
		      (i < (n-1)) &&
		      ((t+i+1) < n)) ++i;

		if((i > 0) || (bdex >= 127)) {
			if(bdex) {
				fputc (((bdex-1) & 0x7f), fp);
				++j;
				fwrite (b, 1, bdex, fp);
				j += bdex;
				bdex = 0;
			}
			if(i) {
				fputc (((~i)+1), fp);
				fputc (p[t+i], fp);
				j += 2;
				t += (i + 1);
			}
		} else b[bdex++] = p[t++];
	} while (t < n);

	if(bdex) {
		fputc (((bdex-1) & 0x7f), fp);
		++j;
		fwrite (b, 1, bdex, fp);
		j += bdex;
	}
	if((j & 0x0001)) fputc (0x80, fp);
}


void WGTAPI getline (char *p, unsigned char *image, short n, short line, long pitch)
{
  memcpy (p, image + (int)((int)pitch * (int)line), n);
}


/* write one long to the file in motorola format */
void WGTAPI fputlong(FILE *fp, int n)
{
 fputc ((n >> 24), fp);
 fputc ((n >> 16), fp);
 fputc ((n >> 8), fp);
 fputc (n, fp);
}


/* write one integer to the file in mototola format */
void WGTAPI fputword(FILE *fp, short n)
{
 fputc ((n >> 8), fp);
 fputc (n, fp);
}


unsigned short WGTAPI motr2inti (unsigned short n)
{
 return (((n & 0xff00) >> 8) | ((n & 0x00ff) << 8));
}

