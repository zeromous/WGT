#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wresize.c                                          
  Contains:     wresize                                            
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Chris Egerter       Windows 95 Version             
*/


/*              ----REVISION HISTORY----

                1.0     Initial Release
                1.1     Altered wresize_column to correct clipping problems.
                        (10/14/95)
*/


#ifdef __WATCOMC__
void WGTAPI resize_horizontal_line (unsigned char *src, unsigned char *dest,
        unsigned int whole, unsigned int xfrac, unsigned short step,
        int length);
#pragma aux resize_horizontal_line = \
  "push ebp" \
  "mov ebp, eax" \
  "cmp ecx, 1"\
  "je hresizeonepixel" \
  "push ecx" \
  "shr ecx, 1" \
  "hresizeloop: mov al, [esi]" \
  "add esi, ebp" \
  "add bx, dx" \
  "adc esi, 0" \
  "mov ah, [esi]" \
  "mov [edi], ax" \
  "add edi, 2" \
  "add esi, ebp" \
  "add bx, dx" \
  "adc esi, 0" \
  "dec ecx" \
  "jnz hresizeloop" \
  "pop ecx" \
  "and ecx, 1" \
  "jz hdoneresize"\
  "hresizeonepixel: movsb" \
  "hdoneresize: pop ebp " \
parm [esi] [edi] [eax] [ebx] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_horizontal_line (unsigned char *src, unsigned char *dest,
        unsigned int whole, unsigned int xfrac, unsigned short stepval,
        int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov ebx,xfrac
		mov dx,stepval
		mov ecx,leng
		mov eax,whole
		push ebp
		mov ebp, eax
		cmp ecx, 1
		je hresizeonepixel
		push ecx
		shr ecx, 1
		hresizeloop: mov al, [esi]
		add esi, ebp
		add bx, dx
		adc esi, 0
		mov ah, [esi]
		mov [edi], ax
		add edi, 2
		add esi, ebp
		add bx, dx
		adc esi, 0
		dec ecx
		jnz hresizeloop
		pop ecx
		and ecx, 1
		jz hdoneresize
		hresizeonepixel: movsb
		hdoneresize: pop ebp 
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI resize_horizontal_line_xray (unsigned char *src,
           unsigned char *dest, unsigned int whole,
           unsigned int xfrac, unsigned short stepval, int leng);
#pragma aux resize_horizontal_line_xray = \
  "push ebp" \
  "mov ebp, eax" \
  "resizeloop: mov al, [esi]" \
  "add esi, ebp" \
  "add bx, dx" \
  "adc esi, 0" \
  "or al, al" \
  "jz resize_xray_nopixel" \
  "mov [edi], al" \
  "resize_xray_nopixel: inc edi" \
  "dec ecx" \
  "jnz resizeloop" \
  "doneresize: pop ebp " \
parm [esi] [edi] [eax] [ebx] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_horizontal_line_xray (unsigned char *src,
           unsigned char *dest, unsigned int whole,
           unsigned int xfrac, unsigned short stepval, int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov ebx,xfrac
		mov dx,stepval
		mov ecx,leng
		mov eax,whole
		push ebp
		mov ebp, eax
		resizeloop: mov al, [esi]
		add esi, ebp
		add bx, dx
		adc esi, 0
		or al, al
		jz resize_xray_nopixel
		mov [edi], al
		resize_xray_nopixel: inc edi
		dec ecx
		jnz resizeloop
		pop ebp
	}
}
#endif

int resize_width_asm;
int screen_width_asm;
#ifdef __WATCOMC__
void WGTAPI resize_vertical_line (unsigned char *src, unsigned char *dest,
     unsigned int whole, unsigned int xfrac, unsigned short step,
     int length);
#pragma aux resize_vertical_line = \
  "push ebp" \
  "mov ebp, eax" \
  "vresizeloop: mov al, [esi]" \
  "add esi, ebp" \
  "add bx, dx" \
  "jnc novres" \
  "add esi, resize_width_asm" \
  "novres: mov [edi], al" \
  "add edi, screen_width_asm" \
  "dec ecx" \
  "jnz vresizeloop" \
  "doneresize: pop ebp " \
parm [esi] [edi] [eax] [ebx] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_vertical_line (unsigned char *src, unsigned char *dest,
     unsigned int whole, unsigned int xfrac, unsigned short stepval,
     int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov ebx,xfrac
		mov dx,stepval
		mov ecx,leng
		mov eax,whole
		push ebp
		mov ebp, eax
		vresizeloop: mov al, [esi]
		add esi, ebp
		add bx, dx
		jnc novres
		add esi, resize_width_asm
		novres: mov [edi], al
		add edi, screen_width_asm
		dec ecx
		jnz vresizeloop
		pop ebp
	}
}
#endif


#ifdef __WATCOMC__
void WGTAPI resize_vertical_line_xray (unsigned char *src, unsigned char *dest,
     unsigned int whole, unsigned int xfrac, unsigned short step,
     int length);
#pragma aux resize_vertical_line_xray = \
  "push ebp" \
  "mov ebp, eax" \
  "vresizeloopx: mov al, [esi]" \
  "add esi, ebp" \
  "add bx, dx" \
  "jnc novresxray" \
  "add esi, resize_width_asm" \
  "novresxray: and al, al" \
  "je vresize_xray_nopixel" \
  "mov [edi], al" \
  "vresize_xray_nopixel: add edi, screen_width_asm" \
  "dec ecx" \
  "jnz vresizeloopx" \
  "doneresize: pop ebp " \
parm [esi] [edi] [eax] [ebx] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_vertical_line_xray (unsigned char *src, unsigned char *dest,
     unsigned int whole, unsigned int xfrac, unsigned short stepval,
     int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov ebx,xfrac
		mov dx,stepval
		mov ecx,leng
		mov eax,whole
		push ebp
		mov ebp, eax
		vresizeloopx: mov al, [esi]
		add esi, ebp
		add bx, dx
		jnc novresxray
		add esi, resize_width_asm
		novresxray: and al, al
		je vresize_xray_nopixel
		mov [edi], al
		vresize_xray_nopixel: add edi, screen_width_asm
		dec ecx
		jnz vresizeloopx
		pop ebp
	}
}
#endif

/*
  Resizes a block to a new width and height on the current screen  
  Supports XRAY or NORMAL modes.                                   
*/
void WGTAPI wresize (int x, int y, int x2, int y2, block image, int mode)
{
int xdif,ydif;
int finalwidth, finalheight, endwidth, endheight;
int origwidth,origheight;
int i;

LPBYTE to;
LPBYTE from;
unsigned short whole;
unsigned short step;
unsigned short ywhole;
unsigned short ystep;
  
unsigned int xstepper, ystepper;
unsigned int yfrac;
unsigned int xfrac;
long pitch;

  if (image == NULL)
  {
     if (diagnostics_level & 2)
        wgt_log_message ("ERROR - Attempt to resize NULL block");
        return;
  }
  origwidth = wgetblockwidth (image);
  origheight = wgetblockheight (image);
  /* Get the original width and height of the block */

  finalwidth = abs (x2 - x) + 1;
  finalheight = abs (y2 - y) + 1;
  /* Find the new width and height */

  xstepper = ((int)(origwidth) << 16) / ((int)(finalwidth));
  /* Calculate the amount to add to the source bitmap for every pixel across.
  This is done using a fixed point number by multiplying it by 65536 (<<16)
  and using 0-65535 as a fractional amount. */

  whole = xstepper >> 16;               /* Keep the whole amount */
  step = xstepper - whole * 65536;
  /* and the fractional amount (1/65536th of a pixel) */

  ystepper = ((int)(origheight) << 16) / ((int)(finalheight));
  ywhole = ystepper >> 16;
  ystep = ystepper - ywhole * 65536;
  /* Do the same with the vertical height */


  to = &abuf[y*WGT_SYS.screenwidth + x];
  /* Make an initial pointer to the destination */
  from = wgetblocksurface (image, &pitch);
  /* Skip over the width/height integers */
  if (from == NULL)
    return;

  endwidth = finalwidth;
  endheight = finalheight;

  xdif = 0;
  /* Differences between actual coordinates and */
  ydif = 0;                            /* the clipped coordinates. */
  yfrac = 0;                              /* Reset step to 0 */
  xfrac = 0;                              /* Reset step to 0 */

  /* Do the clipping */
  if (x < tx)
    {
     xdif = tx - x;
     /* Find the difference between   x<--->tx */
     /* if we know that tx is the greater number */
     to += xdif;
     /* Make sure dest is within left clipping */
     endwidth -= xdif;
     /* Decrease the horizontal number of pixels drawn */
    
     xfrac = (xdif * step) % 65536;

     from += ((int)xdif * xstepper) >> 16;
     /* Now adjust the source pointer according to the whole and step values.
        We multiply the number of pixels and the rate and add this to our
        pointer.  The fractional part is divided by 65536 because we're only
        concerned with the whole pixel amounts. */
    }

  if (y < ty)
    {
     ydif = ty - y;
     endheight = finalheight - (ydif);
     to += ydif * WGT_SYS.screenwidth;
     yfrac = (ydif * ystep) % 65536;

    /* Do the same for the height */
    from += (((int)ydif * (int)ystepper)>>16) * (int)pitch;
    /* Same as above but also multiply be the width of the source since we're
       going down a row instead of one pixel across. */
   }

  if (x + finalwidth - 1 > bx)
    endwidth -= ((x + finalwidth - 1) - bx);
  if (y + finalheight - 1 > by)
    endheight -= ((y + finalheight - 1) - by);
  /* Clip the right and bottom edges simply by decreasing the number of
      pixels drawn. */


  if ((x2 > tx) && (y2 > ty) && (endwidth > 0))
  /* If it is even on the screen at all */
    {
     if (mode == NORMAL)               /* Plain and simple */
       for (i = 1; i <= endheight; i++) /* Vertical loop */
         {
          resize_horizontal_line (from, to, whole, xfrac, step, endwidth);
          /* Resize one line using our assembly routine */

          yfrac += ystep;
          if (yfrac > 65535)
            {
             yfrac -= 65535;
             from += pitch;
            }

          from += ywhole * pitch;
          to += WGT_SYS.screenwidth;
         }
     else                               /* Use XRAY mode */
       for  (i = 1; i <= endheight; i++)
         {
          resize_horizontal_line_xray (from, to, whole, xfrac, step, endwidth);

          yfrac += ystep;
          if (yfrac > 65535)
            {
             yfrac -= 65535;
             from += pitch;
            }

          from += ywhole * pitch;
          to += WGT_SYS.screenwidth;
         }
     }

 wunlocksurface (image);
}

/*
  Resizes a block to a new width and height on the current screen  
  Supports XRAY or NORMAL modes.                                   
*/
void WGTAPI wresize_column (int x, int y, int y2, block image,
                            int column, int mode)
{
int origheight;
int finalheight;
int endheight;
int ystepper;
int ywhole;
short ystep;
int yfrac;

int ydif;
LPBYTE dest;
LPBYTE src;
long pitch;


  if (image == NULL)
  {
     if (diagnostics_level & 2)
        wgt_log_message ("ERROR - Attempt to resize column of NULL block");
        return;
  }
  /* Skip over the width/height integers */
  origheight = wgetblockheight (image);
  resize_width_asm = wgetblockwidth (image);
  src = wgetblocksurface (image, &pitch) + column;
  if (y2 < y)
    {
     src += (origheight - 1) * pitch;
     origheight *= -1;
     ydif = y;
     y = y2;
     y2 = ydif;
    }

  finalheight = (y2 - y) + 1;

  if (finalheight > 0)
    {
     ystepper = ((origheight << 16) / finalheight);
     ywhole = ystepper >> 16;
     ystep = ystepper - (ywhole << 16);
   
     dest = &abuf[y * WGT_SYS.screenwidth + x];
     /* Make an initial pointer to the destination */
    
     endheight = finalheight;

     /* Differences between actual coordinates and */
     ydif = 0;                            /* the clipped coordinates. */
     yfrac = 0;                           /* Reset step to 0 */
   
     if (y < ty)
       {
        ydif = ty - y;
        endheight = finalheight - ydif;
        dest += ydif * WGT_SYS.screenwidth;
        yfrac = (ydif * ystep) % 65536;

        src += ((ydif * ystepper) >> 16) * pitch;
       }
  
     if (y + finalheight > by + 1) 
        endheight -= ((y + finalheight) - by);
     /* Clip the bottom edge by decreasing the number of pixels drawn. */

     if (endheight > 0)
       {
        screen_width_asm = WGT_SYS.screenwidth;
        ywhole *= resize_width_asm;
        if (mode == NORMAL)
          resize_vertical_line (src, dest, ywhole, yfrac, ystep, endheight);
        else
          resize_vertical_line_xray (src, dest, ywhole, yfrac, ystep, endheight);
       }
   }
 wunlocksurface (image);
}

