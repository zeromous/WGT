#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wclip.c                                            
  Contains:     wclip                                              
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter         Windows 95 Version           
*/



/*
  Set clipping bounds                                              
*/
void WGTAPI wclip (int x, int y, int x2, int y2)
{
  tx = x;                              /* Upper x limit */
  ty = y;                              /* Upper y limit */
  bx = x2;                             /* Lower x limit */
  by = y2;                             /* Lower y limit */
  /* Stay within screen bounds, no negatives */

  if (tx < 0)
    tx = 0;

  if (ty < 0)
    ty = 0;

  if (bx >= WGT_SYS.xres)
    bx = WGT_SYS.xres - 1;

  if (by >= WGT_SYS.yres)
    by = WGT_SYS.yres - 1;
}

