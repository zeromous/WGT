#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       winitply.c                                         
  Contains:     winitpoly, wdeinitpoly                             
                                                                   
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/


int *pinit_array;
int *pstartx;
int *pendx;
int *pinten1;
int *pinten2;
int *polyx2;
int *polyy2;
int polygon_buffer_size;


void WGTAPI winitpoly (int maxrows)
{
int bytes;
int ctr;

  polygon_buffer_size = maxrows;

  bytes = 2 * maxrows;
  pstartx = wmalloc (bytes);
  pendx   = wmalloc (bytes);
  pinten1 = wmalloc (bytes);
  pinten2 = wmalloc (bytes);
  polyx2  = wmalloc (bytes);
  polyy2  = wmalloc (bytes);
  pinit_array = wmalloc (bytes);
  for (ctr = 0; ctr < maxrows; ctr++)
    pinit_array[ctr] = -16000;
}


void WGTAPI wdeinitpoly (void)
{
  wfree (pstartx);
  wfree (pendx);
  wfree (pinten1);
  wfree (pinten2);
  wfree (polyx2);
  wfree (polyy2);
  wfree (pinit_array);
}
