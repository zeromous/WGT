#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       fill.c                                             
  Contains:     wregionfill                                        
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Barry Egerter             Windows 95 Version       
*/


static int fill_start, fill_end;
/* Start and end x coords for filled line */

typedef struct {
        int x, y, start, finish;    /* values for filled scan line */
        void *next;                 /* Points to next node in linked list */
} node;

/*
  Builds a custom stack using a linked list                        
*/
static node * WGTAPI push_fill (node *s, int x, int y)
{
  node *newnode;
  s->start = fill_start;                    /* Store start of line */
  s->finish = fill_end;                     /* Store end of line */

  newnode = (node *)wmalloc (sizeof (node));
  /* Allocate new node */

  newnode->next = (node *)s;           /* Make it point to previous node */
  newnode->x = x;                      /* Store current x and y */
  newnode->y = y;
  return newnode;                      /* Return pointer to new head node */
}


/*
  Removes a node off our custom stack                              
*/
static node * WGTAPI pop_fill (node *s, int *x, int *y)
{
  node *headnode;

  headnode = s;                        /* Store pointer to head node */
  s = (node *)s->next;                 /* Go back in the chain */
  *x = s->x;
  /* Find out where we were last (in that row) */
  *y = s->y;
  fill_start = s->start;               /* Restore start and end of line */
  fill_end = s->finish;
  wfree (headnode);                     /* Free head node, no longer needed */
  return s;                            /* Return pointer to new head node */
}


/*
  Performs a region fill using currentcolor and starting at (x,y)  
  Only pixels matching the color at (x,y) will be filled, any      
  other color acts as a border area.                               
*/
void WGTAPI wregionfill (int x, int y)
{
short color2fill;                    /* Color to change */
node *s;                             /* Pointer to head of linked list */
LPBYTE ptr;                           /* Used to scan through screen data */

  if (diagnostics_level & 2)
        wgt_log_message ("Entry of wregionfill");

  if ((x >= tx) && (y >= ty) && (x <= bx) && (y <= by) &&
     (abuf[WGT_SYS.screenwidth * y + x] != currentcolor))
  /* Only fill if within clipping region and color to fill isn't same as
     color we're filling with */
    {
     color2fill = abuf[WGT_SYS.screenwidth * y + x];
     /* Find out color to fill */

     s = (node *)wmalloc (sizeof (node));
     /* Allocate head node */
     s->next = NULL;                    /* No previous nodes */
     s->x = x;                          /* Store current coords */
     s->y = y;
     
     filllabel1:
     ;
     fill_start = x;
     /* Start of line will be our x position */

     ptr = &abuf[WGT_SYS.screenwidth * y + fill_start - 1];
     /* Make pointer to screen data */

     while ((fill_start > tx) && (*ptr == color2fill))
       {
        /* Now scan left until we hit a different color */
        ptr--;
        fill_start--;
       }

     fill_end = x;
     /* End of line will be our y position */
     ptr = &abuf[WGT_SYS.screenwidth * y + fill_end + 1];

     while ((fill_end < bx) && (*ptr == color2fill))
       {
        /* Scan right until we hit a different color */
        fill_end++;
        ptr++;
       }
    
     memset (&abuf[WGT_SYS.screenwidth * y + fill_start], currentcolor,
             fill_end - fill_start + 1);
     /* Fill line segment */

     filllabel2:
     ;
     if (y < by)
       {
        /* Proceed to check below every pixel in current line segment to see
           if we can advance down a row and continue the fill */

        ptr = &abuf[(y + 1) * WGT_SYS.screenwidth + fill_start];
        for (x = fill_start; x <= fill_end; x++)
          {
           if (*ptr == color2fill)
             {
              /* We've found a way to 'leak' into next row,
                 store our position */
              s = push_fill (s, x, y + 1);
          
              y++;
             /* Now move down a row */
          
             goto filllabel1;
            }
           ptr++;
          }
       }
    /* The next area of code does the same thing, except checking upwards */
     if (y > ty)
       {
        ptr = &abuf[(y - 1) * WGT_SYS.screenwidth + fill_start];
        for (x = fill_start; x <= fill_end; x++)
          {
           if (*ptr == color2fill)
             {
              s = push_fill (s, x, y - 1);
              y--;
              goto filllabel1;
             }
           ptr++;
          }  
       }
    
    /* Now we've filled all we can in one direction, move to previous node */
    if (s->next != NULL)
      {
       s = pop_fill (s, &x, &y);
       /* Get data for previous node so we can continue scanning */
       goto filllabel2;
      }
    /* Free the node now that we're done with it */
    wfree (s);
  }
  if (diagnostics_level & 2)
        wgt_log_message ("Exit of wregionfill");
}
