#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>

#include <ddraw.h>
#include <wgt95.h>

short WGTAPI wloadsprites (color *pal, char *filename,
                           block *image_array, int start, int end)
{
short maxsprite; /* maximum # of sprites in the file */
short startingsprite;  /* First sprite in the file. Version <=3 = 1
                                                      Version 4   = 0 */
unsigned short width, height, i, spritemade, ver;
char buf[14];
unsigned char *blkbits;
long pitch, y;


    /* Standard WGT library loading procedure */
    if (wgtlibrary == NULL)
    {
        if ((libf = fopen (filename, "rb")) == NULL)
            return(-1);
    }
    else
    {
        if ((libf = fopen (wgtlibrary, "rb")) == NULL)
        {
            return(-1);
        }
        readheader ();
        findfile (filename);
        if (lresult == 1)
            fseek (libf, lfpos, SEEK_SET);
        if (checkpassword (password) == 0)
        {
         wfatalerror ("Incorrect password");
        }
    }

    if ((wgtlibrary != NULL) & (lresult == 0)) goto sprstop;
    fread (&ver, 2, 1, libf);
    /* Get the version number, and change the startingsprite accordingly.
     If version <= 3, maxsprite contains the maximum number of sprites
     that can be stored in a file.  If version > 4, maxsprite contains
     the number of the highest sprite in the file. (empty sprites at
     the end are not kept in the file. */
    if (ver <= 3)
      startingsprite = 1;
    else startingsprite = 0;


    fread (buf, 1, 13, libf); /* sprite header */
    if (0 == strnicmp (" Sprite File ", buf, 13))
       /* see if it is a sprite file */
    {

        fread(pal, 3, 256, libf);

        fread (&maxsprite, 2, 1, libf);   /* maximum sprites in this file */
        for (i = start; i <= end; i++) /* make all sprites null
                                      (still need to call wfreesprites) */
            image_array[i] = NULL;

        for (i = startingsprite; i <= maxsprite; i++) /* load them in */
        {
          fread (&spritemade, 2, 1, libf); /* flag to see if sprite exists */
          if (spritemade == 1)
          {
            fread (&width, 2, 1, libf); /* get width and height */
            fread (&height, 2, 1, libf);
            if ((i >= start) && (i <= end)) /* Load this one */
            {
              image_array[i] = wallocblock (width, height);
              if (image_array[i] != NULL)
                {
                 blkbits = wgetblocksurface (image_array[i], &pitch);
                 if (blkbits == NULL)
                   {
                    fclose (libf);
                    return 0;
                   }

                 for (y = 0; y < height; y++)
                   {
                    fread (blkbits, width, 1, libf); /* read the sprite data */
                    blkbits += pitch;
                    }
                 wunlocksurface (image_array[i]);
                }
            }
            else /* Don't load this one */
              fseek(libf, width * height, SEEK_CUR);
          }
        }
    }
    sprstop:
    ;
    fclose (libf);
    return(0);
}



short WGTAPI wsavesprites (color *pal, char *filename, block *image_array,
                           int start, int end)
{
  short maxsprite; /* maximum # of sprites in the file */
  unsigned short a, i, spritemade, wid, hei;
  char buf[14];

  if ( (libf = fopen (filename, "wb")) == NULL)
    return (-1);    

  a = 4;        /* Version 4.0 format */
  fwrite (&a, 2, 1, libf);

  strcpy (buf, " Sprite File ");
  fwrite (buf, 1, 13, libf);            /* sprite header */
  fwrite (pal, 768, 1, libf);           /* palette */
                
  maxsprite = 0;
  for (i = 0; i <= end; i++)            /* check for null sprites */
    if (image_array[i] != NULL)
      maxsprite = i;

  fwrite (&maxsprite, 2, 1, libf);      /* maximum sprites in this file */

  spritemade = 0;
  if (start > 0)
  for (i = 0; i < start; i++)           /* save NULL for first few sprites */
  {
    fwrite (&spritemade, 2, 1, libf);
  }

  for (i = start; i <= maxsprite; i++)      /* save them */
  {
    spritemade = (image_array[i] != NULL);
    fwrite (&spritemade, 2, 1, libf);   /* flag to see if sprite exists */
    if (spritemade)
    {
      wid = *(short *)image_array[i];
      hei = *(short *)(image_array[i] + 2);
      fwrite (image_array[i], wid * hei + 4, 1, libf);
    }
  }
  fclose (libf);
  return (0);
}



void WGTAPI wfreesprites (block *image_array, int start, int end)
{
  short i;

  for (i = start; i <= end; i++)
  {
    if (image_array[i] != NULL)
    {
      wfreeblock (image_array[i]);
      image_array[i] = NULL;
    }
  }
}
