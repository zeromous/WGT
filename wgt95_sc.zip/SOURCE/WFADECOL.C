#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                
 
  Module:       wfadecol.c                                         
  Contains:     wfade_out, wfade_out_once, wfade_in, wfade_in_once 
                wfade_between, wfade_between_once                  
                                                                   
  Last Revised: March 22, 1996                                     
                                                                   
  Written by:   Barry and Chris Egerter   Windows 95 Version       
*/



/*
  Fades the palette out to black                                   
*/
void WGTAPI wfade_out (unsigned char start, unsigned char finish, 
                       int speed, color *pal)
{
int ctr;
int sensitivity = 64;
color palt[256];

  for (ctr = 0; ctr < 256; ctr++)
    {
     palt[ctr].r = pal[ctr].r;
     palt[ctr].g = pal[ctr].g;
     palt[ctr].b = pal[ctr].b;
    }

  /* Make a copy of the original palette */
  while (sensitivity > 0)
    {
     /* Decrease each R,G,B until all reach 0 */
     for (ctr = start; ctr <= finish; ctr++)
       {
        if (palt[ctr].r > 0)
          palt[ctr].r--;
        if (palt[ctr].g > 0)
          palt[ctr].g--;
        if (palt[ctr].b > 0)
          palt[ctr].b--;
       }

    wsetpalette (start, finish, palt); /* Set palette on screen */
    sensitivity--;
    Sleep (speed);                     /* Pause for requested time */
  }
}

/*
  Fades out the palette once                                       
*/
void WGTAPI wfade_out_once (unsigned char start, unsigned char finish,
                            color *pal)
{
int ctr;

  /* Decrease each R,G,B until all reach 0 */
  for  (ctr = start; ctr <= finish; ctr++)
    {
     if (pal[ctr].r > 0)
       pal[ctr].r--;
     if (pal[ctr].g > 0)
       pal[ctr].g--;
     if (pal[ctr].b > 0)
       pal[ctr].b--;
   }
}


/*
  Fades the palette in from black to a palette                     
  Technique used is not proper when fading colors in.  Best method 
  would involve allowing some RGB values to increase before        
  adjusting others, but would require more work and would probably 
  be slower.  This method looks half decent, and simply increases  
  all 3 RGB values simultaneously.                                 
*/
void WGTAPI wfade_in (unsigned char start, unsigned char finish, 
                      int speed, color *pal)
{
int ctr;
int sensitivity;
color palt2[256];

  /* Make copy of palette, zero out values to fade in */
  for (ctr = 0; ctr <= 255; ctr++)
    {
     palt2[ctr].r = pal[ctr].r;
     palt2[ctr].g = pal[ctr].g;
     palt2[ctr].b = pal[ctr].b;
     if ((ctr >= start) && (ctr <= finish))
       {
        palt2[ctr].r = 0;
        palt2[ctr].g = 0;
        palt2[ctr].b = 0;
       }
    }

  wsetpalette (start, finish, palt2);
  sensitivity = 64;
  /* Now increase each R,G,B until they meet required levels */
  while (sensitivity > 0)
    {
     for (ctr = start; ctr <= finish; ctr++)
       {
        if (pal[ctr].r > 0)
          {
           palt2[ctr].r++;
           pal[ctr].r--;
          }
        if (pal[ctr].b > 0)
          {
           palt2[ctr].b++;
           pal[ctr].b--;
          }
        if (pal[ctr].g > 0)
          {
           palt2[ctr].g++;
           pal[ctr].g--;
          }
       }
    wsetpalette (start, finish, palt2);
    sensitivity--;
    Sleep (speed);
  }
  
  for (ctr = start; ctr <= finish; ctr++)
    {
     pal[ctr].r = palt2[ctr].r;
     pal[ctr].g = palt2[ctr].g;
     pal[ctr].b = palt2[ctr].b;
    }                                    /* Restore palette */
}



/*
  Fades the palette in from black once                             
*/
void WGTAPI wfade_in_once (unsigned char start, unsigned char finish,
                           color *pal, color *temppal)
{
int ctr;
  
  /* Increase each R,G,B until they meet required levels */
  
  for (ctr = start; ctr <= finish; ctr++)
    {
     if (temppal[ctr].r < pal[ctr].r)
       temppal[ctr].r++;
     if (temppal[ctr].b < pal[ctr].b)
       temppal[ctr].b++;
     if (temppal[ctr].g < pal[ctr].g)
       temppal[ctr].g++;
    }
}
    

/*
  Fades between two palettes, one step at a time                   
*/
void WGTAPI wfade_between_once (unsigned char start, unsigned char finish, 
                                color *pal1, color *pal2)
{
int ctr;

  for (ctr = start; ctr <= finish; ctr++)
    {
     if (pal1[ctr].r > pal2[ctr].r)
       pal1[ctr].r--;
     if (pal1[ctr].g > pal2[ctr].g)
       pal1[ctr].g--;
     if (pal1[ctr].b > pal2[ctr].b)
       pal1[ctr].b--;
     if (pal1[ctr].r < pal2[ctr].r)
       pal1[ctr].r++;
     if (pal1[ctr].g < pal2[ctr].g)
       pal1[ctr].g++;
     if (pal1[ctr].b < pal2[ctr].b)
       pal1[ctr].b++;
    }
}

/*
  Fades between two palettes                                       
*/
void WGTAPI wfade_between (unsigned char start, unsigned char finish,
                           int speed, color *pal1, color *pal2)
{
int ctr;
int i;

  for (i = 0; i < 64; i++)
    {
     for  (ctr = start; ctr <= finish; ctr++)
       {
        if (pal1[ctr].r > pal2[ctr].r)
          pal1[ctr].r--;
        if (pal1[ctr].g > pal2[ctr].g)
          pal1[ctr].g--;
        if (pal1[ctr].b > pal2[ctr].b)
          pal1[ctr].b--;
        if (pal1[ctr].r < pal2[ctr].r)
          pal1[ctr].r++;
        if (pal1[ctr].g < pal2[ctr].g)
          pal1[ctr].g++;
        if (pal1[ctr].b < pal2[ctr].b)
          pal1[ctr].b++;
       }
     Sleep (speed);
     wsetpalette (start, finish, pal1);
    }
}
