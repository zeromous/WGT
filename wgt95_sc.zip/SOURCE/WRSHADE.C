#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
          Source Code    Copyright 1996 Egerter Software           

  Module:       wrshade.c                                          
  Contains:     wresize_shade                                      
  Last Revised: April 29, 1996                                     
                                                                   
  Written by:   Chris Egerter       Windows 95 Version             
*/


static unsigned char *shadeptrasm;
static unsigned int wholevalueasm;
static unsigned char shademonocolor;

#ifdef __WATCOMC__
void WGTAPI resize_horizontal_line_shade (unsigned char *src, unsigned char *dest,
                                   unsigned int xfrac, unsigned short step,
                                   int length);
#pragma aux resize_horizontal_line_shade = \
  "push ebp" \
  "mov ebp, shadeptrasm" \
  "mov ebx, 0" \
  "sresizeloop: mov bl, [esi]" \
  "mov bl, [ebp + ebx]" \
  "mov [edi], bl" \
  "add ax, dx" \
  "adc esi, wholevalueasm" \
  "inc edi" \
  "dec ecx" \
  "jnz sresizeloop" \
  "pop ebp" \
parm [esi] [edi] [eax] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_horizontal_line_shade (unsigned char *src, unsigned char *dest,
                                   unsigned int xfrac, unsigned short stepval,
                                   int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov dx,stepval
		mov ecx,leng
		mov eax,xfrac
		push ebp
		mov ebp, shadeptrasm
		mov ebx, 0
		sresizeloop: mov bl, [esi]
		mov bl, [ebp + ebx]
		mov [edi], bl
		add ax, dx
		adc esi, wholevalueasm
		inc edi
		dec ecx
		jnz sresizeloop
		pop ebp
	}
}
#endif

/* shl eax and edx for add eax, edx */

#ifdef __WATCOMC__
void WGTAPI resize_horizontal_line_xray_shade (unsigned char *src,
                                        unsigned char *dest,
                                        unsigned int xfrac,
                                        unsigned short step, int length);
#pragma aux resize_horizontal_line_xray_shade = \
  "push ebp" \
  "mov ebp, shadeptrasm" \
  "mov ebx, 0" \
  "xresizeloop: mov bl, [esi]" \
  "test bl, bl"\
  "jz nopixelxrayshade" \
  "mov bl, [ebp + ebx]" \
  "mov [edi], bl" \
  "nopixelxrayshade: " \
  "add ax, dx" \
  "adc esi, wholevalueasm" \
  "inc edi" \
  "dec ecx" \
  "jnz xresizeloop" \
  "pop ebp" \
parm [esi] [edi] [eax] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_horizontal_line_xray_shade (unsigned char *src,
                                        unsigned char *dest,
                                        unsigned int xfrac,
                                        unsigned short stepval, int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov dx,stepval
		mov ecx,leng
		mov eax,xfrac
		push ebp
		mov ebp, shadeptrasm
		mov ebx, 0
		xresizeloop: mov bl, [esi]
		test bl, bl
		jz nopixelxrayshade
		mov bl, [ebp + ebx]
		mov [edi], bl
		nopixelxrayshade: 
		add ax, dx
		adc esi, wholevalueasm
		inc edi
		dec ecx
		jnz xresizeloop
		pop ebp
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI resize_horizontal_line_shade_screen (unsigned char *src,
                                          unsigned char *dest,
        unsigned int xfrac, unsigned short step, int length);
#pragma aux resize_horizontal_line_shade_screen = \
  "push ebp" \
  "mov ebp, shadeptrasm" \
  "mov ebx, 0" \
  "sdresizeloop: mov bl, [esi]" \
  "test bl, bl"\
  "jz nopixelshadow" \
  "mov bl, [edi]" \
  "mov bl, [ebp + ebx]" \
  "mov [edi], bl" \
  "nopixelshadow:" \
  "add ax, dx" \
  "adc esi, wholevalueasm" \
  "inc edi" \
  "dec ecx" \
  "jnz sdresizeloop" \
  "pop ebp" \
parm [esi] [edi] [eax] [edx] [ecx] \
modify exact [eax ebx ecx dx esi edi] nomemory;
#else
void WGTAPI resize_horizontal_line_shade_screen (unsigned char *src,
                                          unsigned char *dest,
        unsigned int xfrac, unsigned short stepval, int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov dx,stepval
		mov ecx,leng
		mov eax,xfrac
		push ebp
		mov ebp, shadeptrasm
		mov ebx, 0
		sdresizeloop: mov bl, [esi]
		test bl, bl
		jz nopixelshadow
		mov bl, [edi]
		mov bl, [ebp + ebx]
		mov [edi], bl
		nopixelshadow:
		add ax, dx
		adc esi, wholevalueasm
		inc edi
		dec ecx
		jnz sdresizeloop
		pop ebx
	}
}
#endif

#ifdef __WATCOMC__
void WGTAPI resize_horizontal_line_translucent (unsigned char *src,
                                         unsigned char *dest,
        unsigned int xfrac, unsigned short step, int length);
#pragma aux resize_horizontal_line_translucent = \
  "push ebp" \
  "mov ebp, shadeptrasm" \
  "mov ebx, 0" \
  "tresizeloop: mov bl, [esi]" \
  "test bl, bl"\
  "jz nopixeltranslucent" \
  "mov bh, [edi]" \
  "mov bl, [ebp + ebx]" \
  "mov [edi], bl" \
  "nopixeltranslucent: " \
  "add ax, dx" \
  "adc esi, wholevalueasm" \
  "inc edi" \
  "dec ecx" \
  "jnz tresizeloop" \
  "pop ebp" \
parm [esi] [edi] [eax] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_horizontal_line_translucent (unsigned char *src,
                                         unsigned char *dest,
        unsigned int xfrac, unsigned short stepval, int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov dx,stepval
		mov ecx,leng
		mov eax,xfrac
		push ebp
		mov ebp, shadeptrasm
		mov ebx, 0
		tresizeloop: mov bl, [esi]
		test bl, bl
		jz nopixeltranslucent
		mov bh, [edi]
		mov bl, [ebp + ebx]
		mov [edi], bl
		nopixeltranslucent: 
		add ax, dx
		adc esi, wholevalueasm
		inc edi
		dec ecx
		jnz tresizeloop
		pop ebp
	}
}
#endif


#ifdef __WATCOMC__
void WGTAPI resize_horizontal_line_mono (unsigned char *src, unsigned char *dest,
        unsigned int xfrac, unsigned short step, int length);
#pragma aux resize_horizontal_line_mono = \
  "push ebp" \
  "mov ebp, wholevalueasm" \
  "mov bh, shademonocolor" \
  "mresizeloop: mov bl, [esi]" \
  "test bl, bl"\
  "jz nopixelmono" \
  "mov [edi], bh" \
  "nopixelmono: " \
  "add ax, dx" \
  "adc esi, ebp" \
  "inc edi" \
  "dec ecx" \
  "jnz mresizeloop" \
  "pop ebp" \
parm [esi] [edi] [eax] [dx] [ecx] \
modify exact [eax ebx ecx edx esi edi] nomemory;
#else
void WGTAPI resize_horizontal_line_mono (unsigned char *src, unsigned char *dest,
        unsigned int xfrac, unsigned short stepval, int leng)
{
	__asm {
		mov esi,src
		mov edi,dest
		mov dx,stepval
		mov ecx,leng
		mov eax,xfrac
		push ebp
		mov ebp, wholevalueasm
		mov bh, shademonocolor
		mresizeloop: mov bl, [esi]
		test bl, bl
		jz nopixelmono
		mov [edi], bh
		nopixelmono: 
		add ax, dx
		adc esi, ebp
		inc edi
		dec ecx
		jnz mresizeloop
		pop ebp
	}
}
#endif


/*
  Resizes a block to a new width and height on the current screen  
  Supports XRAY or NORMAL modes.                                   

Modes available:
 Shading original source: normal or xray
 Shading screen, xray
 transparent, xray
 solid color

*/

/*
  Resizes a block to a new width and height on the current screen  
  Supports XRAY or NORMAL modes.                                   
*/
void WGTAPI wresize_shade (int x, int y, int x2, int y2,
                    block resizeblock, unsigned char *shadetable, int mode)
{
int xdif, ydif;
int finalwidth, finalheight, endwidth, endheight;
int origwidth,origheight;
int i;

LPBYTE to;
LPBYTE from;
LPBYTE fromt;

unsigned short whole;
unsigned short step;
unsigned short ywhole;
unsigned short ystep;

unsigned int xstepper, ystepper;
unsigned int yfrac;
unsigned int xfrac;
long pitch;

  if (resizeblock == NULL)
  {
     if (diagnostics_level & 2)
        wgt_log_message ("ERROR - Attempt to resize shaded NULL block");
        return;
  }
  shadeptrasm = shadetable;

  origwidth = wgetblockwidth (resizeblock);
  origheight = wgetblockheight (resizeblock);
  /* Get the original width and height of the block */

  finalwidth = abs (x2 - x) + 1;
  finalheight = abs (y2 - y) + 1;
  /* Find the new width and height */


  xstepper = ((int)(origwidth) << 16) / ((int)(finalwidth));
  /* Calculate the amount to add to the source bitmap for every pixel across.
  This is done using a fixed point number by multiplying it by 65536 (<<16)
  and using 0-65535 as a fractional amount. */

  whole = xstepper >> 16;               /* Keep the whole amount */
  step = xstepper - whole * 65536;
  /* and the fractional amount (1/65536th of a pixel) */

  ystepper = ((int)(origheight) << 16) / ((int)(finalheight));
  ywhole = ystepper >> 16;
  ystep = ystepper - ywhole * 65536;
  /* Do the same with the vertical height */

  whole = xstepper >> 16;               /* Keep the whole amount */
  step = xstepper - whole * 65536;
  /* and the fractional amount (1/256th of a pixel) */

  to = &abuf[y * (int)WGT_SYS.screenwidth + x];
  /* Make an initial pointer to the destination */

  from = wgetblocksurface (resizeblock, &pitch);
  /* Skip over the width/height integers */
  if (from == NULL)
    return;

  endwidth = finalwidth;
  endheight = finalheight;

  xdif = 0;
  /* Differences between actual coordinates and */
  ydif = 0;                            /* the clipped coordinates. */
  yfrac = 0;                              /* Reset step to 0 */
  xfrac = 0;                              /* Reset step to 0 */

  /* Do the clipping */
  if (x < tx)
    {
     xdif = tx - x;
     /* Find the difference between   x<--->tx */
     /* if we know that tx is the greater number */
     to += xdif;
     /* Make sure dest is within left clipping */
     endwidth -= xdif;
     /* Decrease the horizontal number of pixels drawn */

     xfrac = (xdif * step) % 65536;

     from += ((int)xdif * xstepper) >> 16;
     /* Now adjust the source pointer according to the whole and step values.
     We multiple the number of pixels and the rate and add this to our
     pointer.  The fractional part is divided by 256 because we're only
     concerned with the whole pixel amounts. */
    }


  if (y < ty)
    {
     ydif = ty - y;
     endheight = finalheight - (ydif);
     to += ydif * (int)WGT_SYS.screenwidth;
     yfrac = (ydif * ystep) % 65536;
 
     /* Do the same for the height */

     from += (((int)ydif * (int)ystepper)>>16) * pitch;

     /* Same as above but also multiply be the width of the source since we're
        going down a row instead of one pixel across. */
    }



  if (x + finalwidth - 1 > bx)
    endwidth -= ((x + finalwidth - 1) - bx);
  if (y + finalheight - 1 > by)
    endheight -= ((y + finalheight - 1) - by);
  /* Clip the right and bottom edges simply by decreasing the number of
  pixels drawn. */

  if ((x2 > tx) & (y2 > ty) && (endwidth > 0))
  /* If it is even on the screen at all */
    {
     if  (mode == SHADE_NORMAL)               /* Plain and simple */
       {
        for  (i = 0; i < endheight; i++)       /* Vertical loop */
          {
           fromt = from;
           wholevalueasm = whole;
           resize_horizontal_line_shade (fromt, to, xfrac, step, endwidth);
           /* Resize one line using our assembly routine */

           yfrac += ystep;
           if (yfrac > 65535)
             {
              yfrac -= 65535;
              from += pitch;
             }

           from += ywhole * pitch;
           to += WGT_SYS.screenwidth;
          }
      }
    else if (mode == SHADE_XRAY)             /* Use XRAY mode */
      {
       for  (i = 0; i < endheight; i++)
         {
          fromt = from;
          wholevalueasm = whole;
          resize_horizontal_line_xray_shade (fromt, to, xfrac, step, endwidth);

          yfrac += ystep;
          if (yfrac > 65535)
            {
             yfrac -= 65535;
             from += pitch;
            }

          from += ywhole * pitch;
          to += WGT_SYS.screenwidth;
         }
      }
    else if (mode == SHADE_SHADOW)         /* Use shadow mode */
      {
       for (i = 0; i < endheight; i++)
         {
          fromt = from;
          wholevalueasm = whole;
          resize_horizontal_line_shade_screen (fromt, to, xfrac, step, endwidth);

          yfrac += ystep;
          if (yfrac > 65535)
            {
             yfrac -= 65535;
             from += pitch;
            }

          from += ywhole * pitch;
          to += WGT_SYS.screenwidth;
         }
       }
    else if (mode == SHADE_TRANSLUCENT)  /* Use translucent mode */
     {
      for (i = 0; i < endheight; i++)
       {
        fromt = from;
        wholevalueasm = whole;
        resize_horizontal_line_translucent (fromt, to, xfrac, step, endwidth);

        yfrac += ystep;
        if (yfrac > 65535)
          {
           yfrac -= 65535;
           from += pitch;
          }

        from += ywhole * pitch;
        to += WGT_SYS.screenwidth;
      }
    }
    else if (mode == SHADE_MONO)    /* Use monochrome mode */
     {
      shademonocolor = *shadetable;
      for (i = 0; i < endheight; i++)
      {
        fromt = from;
        wholevalueasm = whole;
        resize_horizontal_line_mono (fromt, to, xfrac, step, endwidth);

        yfrac += ystep;
        if (yfrac > 65535)
         {
          yfrac -= 65535;
          from += pitch;
         }

        from += ywhole * pitch;
        to += WGT_SYS.screenwidth;
      }
    }
  }

 wunlocksurface (resizeblock);
}







