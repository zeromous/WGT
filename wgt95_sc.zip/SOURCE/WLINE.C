#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wline.c                                            
  Contains:     wline, whline                                      
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/


/*
  Draws a line between two points on the current screen            
*/
void WGTAPI wline (int x, int y, int x2, int y2)
{
        int             t;
        int             wx = 0, wy = 0;
        int             dx, dy;
        int             bdx, bdy;
        int             incx, incy, addrow;
        LPBYTE          temp;
        
  if ((x != x2) && (y != y2))    /* Diagonal lines */
    {
     dx = x2 - x;
     dy = y2 - y;
     t = 0; 
     wx = 0; 
     wy = 0;
     if (dy < 0) 
       incy = - 1; 
     else
       incy = 1;

     addrow = incy * WGT_SYS.screenwidth;
     if (dx < 0) 
       incx = - 1; 
     else
       incx = 1;

     bdx = abs (dx);
     bdy = abs (dy);

     temp = &abuf[y * WGT_SYS.screenwidth + x];

     if (bdx > bdy)
       {
        while (t <= bdx)
          {
           if ((x >= tx) && (y >= ty) && (y <= by) && (x <= bx)) /* Clip */
             *temp = currentcolor;
           wy += bdy;
           x += incx;
           temp += incx;
           t++;

           if (wy >= bdx)
             {
              wy -= bdx;
              y += incy;
              temp += addrow;
             }
          }
       }
     else 
       {
        while (t <= bdy)
          {
           if ((x >= tx) && (y >= ty) && (y <= by) && (x <= bx))
             *temp = currentcolor;
           wx += bdx;
           if (wx >= bdy) 
             {
              wx -= bdy;
              x += incx;
              temp += incx;
             }
           y += incy;
           temp += addrow;
           t++;
          }
       }
    }
  else if ((y == y2) && (y >= ty) && (y <= by))
    /* Horizontal line */
    {
     if (x > x2)  /* Swap x coords */
       {
        t = x; 
        x = x2; 
        x2 = t;
       }

     if (x < tx)
       x = tx;   /* Clip the line */
     if (x2 > bx) 
       x2 = bx;
     if (x2 - x >= 0)
       memset (&abuf[y * WGT_SYS.screenwidth + x], currentcolor, x2 - x + 1);
    }
  else if ((x == x2) && (x >= tx) && (x <= bx))
    /* Vertical line */
    {
     if (y > y2)  /* Swap y coords */
       {
        t = y; 
        y = y2; 
        y2 = t;
       }
     if (y < ty) 
       y = ty;   /* Clip the line */
     if (y2 > by) 
       y2 = by;
     temp = &abuf[y * WGT_SYS.screenwidth + x];

     for (t = y; t <= y2; t++)
       {
        *temp = currentcolor;
        temp += WGT_SYS.screenwidth;
       }
    }
}


/*
  Draws a horizontal line.                                         
*/
void WGTAPI whline (int x1, int x2, int y)
{
int t;
int length;

  if (x1 > x2)  /* Swap x coords */
    {
     t = x1;
     x1 = x2;
     x2 = t;
    }

  if (x1 < tx)
    x1 = tx;   /* Clip the line */
  if (x2 > bx)
    x2 = bx;

  length = x2 - x1 + 1;
  if (length > 0)
    memset (&abuf[y * WGT_SYS.screenwidth + x1], currentcolor, length);
}
