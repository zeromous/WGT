#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                   WordUp Graphics Toolkit V5.1                    
     Source Code    Copyright 1996 Egerter Software                

  Module:       wgpoly.c                                           
  Contains:     wgouraudpoly                                       
                                                                   
  Last Revised: February 19, 1996                                  
                                                                   
  Written by:   Chris Egerter          Windows 95 Version          
*/


extern int *pinit_array;
extern int *pstartx;
extern int *pendx;
extern int *pinten1;
extern int *pinten2;
extern int polygon_buffer_size;

#ifdef __WATCOMC__
void WGTAPI gourasm (unsigned char *dst, int length, int colorvalue, int step);
#pragma aux gourasm = \
  "mov esi,ecx" \
  "cmp ecx,1" \
  "je  gour_one" \
  "shr ecx,1" \
  "gourlineloop: mov dl,ah" \
  "add eax,ebx" \
  "mov dh,ah" \
  "add eax,ebx" \
  "mov [edi],dx" \
  "add edi,2" \
  "dec ecx" \
  "jnz gourlineloop" \
  "and esi,1" \
  "jz  gour_done" \
  "gour_one: mov [edi],ah" \
  "gour_done:" \
  parm [edi] [ecx] [eax] [ebx] \
  modify exact [eax ebx ecx edi esi];
#else
void WGTAPI gourasm (unsigned char *dst, int leng, int colorvalue, int stepval)
{
	__asm {
	mov edi,dst
	mov ecx,leng
	mov ebx,stepval
	mov eax,colorvalue
    mov esi,ecx
    cmp ecx,1
    je  gour_one
    shr ecx,1
    gourlineloop: mov dl,ah
    add eax,ebx
    mov dh,ah
    add eax,ebx
    mov [edi],dx
    add edi,2
    dec ecx
    jnz gourlineloop
    and esi,1
    jz  gour_done
    gour_one: mov [edi],ah
    gour_done:
	}
}
#endif

void WGTAPI wgourline (int x1,int x2, int y, int n1, int n2)
{
LPBYTE temp;
int numcolors;
int colorvalue;
int length;
short dist;
int step;

  if (x1 > x2)
    {
     dist = x1; 
     x1 = x2; 
     x2 = dist;
     dist = n1;
     n1 = n2; 
     n2 = dist;
    }
  
  length = x2 - x1 + 1;
  numcolors = n2 - n1 + 1;
  colorvalue = n1 << 8;
  step = ((int)numcolors << 8) / length;

  if (x1 < tx) 
    {
     dist = tx - x1;
     colorvalue += dist * step;
     x1 = tx;        
    }

  if (x2 > bx)
    x2 = bx;

  temp = abuf + (y * WGT_SYS.screenwidth) + x1;

  length = x2 - x1 + 1;
  if (length > 0)
    gourasm (temp, length, colorvalue, step);
}


void WGTAPI wgpolyline (int x1, int y1, int n1, int x2, int y2, int n2)
{
int tmx, tmy, y;
int x, m;
int col2, colinc;

  if (y2 != y1)
    {
     if (y2 < y1)
       {
        tmy = y1;
        y1 = y2;
        y2 = tmy;
      
        tmx = x1;
        x1 = x2;
        x2 = tmx;

        tmx = n1;
        n1 = n2;
        n2 = tmx;
       }

     x = (int)x1 << 8;
     m = ((int)(x2 - x1) << 8) / ((int)(y2 - y1));
     col2 = (int)n1 << 8;
     colinc = ((int)(n2 - n1) << 8) / ((int)(y2 - y1));
     x++;
     y1++;
 
     for (y = y1; y <= y2; y++)
       {
        if ((y >= 0) && (y < WGT_SYS.yres))
          if (pstartx[y] == -16000)
            {
             pstartx[y] = x >> 8;
             pinten1[y] = col2 >> 8;
            }
          else
            {
             pendx[y] = x >> 8;
             pinten2[y] = col2 >> 8;
            }
        x += m;
        col2 += colinc;
       }
   }
}


void WGTAPI wgouraudpoly (tpolypoint *vertexlist, int numvertex,
                          int x, int y)
{
int i;
tpolypoint *curpt,*nextpt;

  curpt = vertexlist;
  nextpt = vertexlist + 1;

  memcpy (pstartx, pinit_array, polygon_buffer_size << 1);
  memcpy (pendx, pinit_array, polygon_buffer_size << 1);

  for (i = 0; i < numvertex - 1; i++)
    {
     wgpolyline (curpt->x + x, curpt->y + y, curpt->sx, nextpt->x + x, nextpt->y + y, nextpt->sx);
     curpt++;
     nextpt++;
    }

  nextpt = vertexlist;
  wgpolyline (curpt->x + x, curpt->y + y, curpt->sx, nextpt->x + x, nextpt->y + y, nextpt->sx);

  for (i = 0; i < WGT_SYS.yres; i++)
    {
     if (pstartx[i] != -16000)
       {
        if (pendx[i] == -16000) 
          pendx[i] = pstartx[i];
        wgourline (pstartx[i], pendx[i], i, pinten1[i], pinten2[i]);
       }
    }
}

