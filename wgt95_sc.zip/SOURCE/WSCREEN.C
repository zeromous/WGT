#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include <ddraw.h>
#include <wgt95.h>

/*
                 WordUp Graphics Toolkit 95
         Source Code Copyright 1996 Egerter Software               

  Module:       wscreen.c                                         
  Contains:     wsetscreen, wnormscreen, wcopyscreen              
  Last Revised: February 19, 1996                                 
                                                                  
  Written by:   Chris Egerter           Windows 95 Version        
*/


block wgtbltdest;


/*-----
  Set the active virtual page, NULL is the base screen at 0xA000  
*/
void WGTAPI wsetscreen (block image)
{
  if (image != NULL)
  {
    WGT_SYS.xres = wgetblockwidth (image);       /* Get virtual screen size */
    WGT_SYS.yres = wgetblockheight (image);
    wgtbltdest = image;
  }
  else  /* Use the primary surface as a virtual screen */
  {
    wnormscreen ();
    return;
  }
                
  tx = 0;                       /* Set up clipping values */
  ty = 0;
  bx = WGT_SYS.xres - 1;
  by = WGT_SYS.yres - 1;
}

/*-----
  Locks the current drawing surface

// LR 2/6/98 :return surface ptr, so we can see if we failed or not (ALT-TAB)
*/
LPBYTE WGTAPI wopenscreen(void)
{
long   pitch;
LPBYTE temp;

  temp = wgetblocksurface (wgtbltdest, &pitch);
  if (temp != NULL)
    abuf = temp;

  WGT_SYS.screenwidth = (short)pitch;

  return (temp);
}


/*-----
  Closes a surface (unlocks)                                      
*/
void WGTAPI wclosescreen (void)
{
  DDSURFACEDESC         ddsd;
  int                   result;

  ddsd.dwSize = sizeof (ddsd);
  result = IDirectDrawSurface4_Unlock (wgtbltdest, NULL);
  if (result != DD_OK)
    if (diagnostics_level & 2)
        wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
}


/*-----
  Set the normal base screen                                      
*/
void WGTAPI wnormscreen (void)
{
  WGT_SYS.xres = wgetblockwidth (wgtpdds);     /* Get virtual screen size */
  WGT_SYS.yres = wgetblockheight (wgtpdds);

  if (wopenscreen())           //LR only req. if we don't fail lock
    wclosescreen();

  tx = 0;
  ty = 0;
  bx = WGT_SYS.xres - 1;
  by = WGT_SYS.yres - 1;
}



/*-----
  Copy part of a screen to another                                
  Takes a region of one screen and copies it onto another at a    
  different location. 
  Full clipping is performed to make sure memory outside the      
  screen is not destroyed.                                        
*/
void WGTAPI wcopyscreen (int x, int y, int x2, int y2,
                block source, int destx, int desty, block dest)
{
int     srcwidth;
int     srcheight;
DWORD   dwTransType;
RECT    rcRect;
RECT    dRect;
int     result;
int     temp;
DDBLTFX         ddbltfx;

  if( !source || !dest )	//LR :neither can be nil!
    return;

  srcwidth = wgetblockwidth (source);
  srcheight = wgetblockheight (source);

  if (y2 < y)
        {
        temp = y2;
        y2 = y;
        y = temp;
        }
  if (x2 < x)
        {
        temp = x2;
        x2 = x;
        x = temp;
        }

  if (x < 0)
        x = 0;

  if (y < 0)
        y = 0;

  if (x2 > srcwidth)
        x2 = srcwidth;

  if (y2 > srcheight)
        y2 = srcheight;
  
  rcRect.left   = x;
  rcRect.top    = y;
  rcRect.right  = x2+1;
  rcRect.bottom = y2+1;

  dRect.left   = destx;
  dRect.top    = desty;
  dRect.right  = destx + (x2-x)+1;
  dRect.bottom = desty + (y2-y)+1;

  dwTransType = DDBLT_WAIT | DDBLTFAST_NOCOLORKEY;

  memset (&ddbltfx, 0, sizeof (ddbltfx));
  ddbltfx.dwSize = sizeof (ddbltfx);
  ddbltfx.dwFillColor = 0;

  result = IDirectDrawSurface4_Blt (dest, &dRect, source, &rcRect, dwTransType,
           &ddbltfx);
  if (result != DD_OK)
  {
     if (diagnostics_level & 2)
       wgt_log_message ("Source (%d,%d,%d,%d)     Dest (%d,%d)", rcRect.left, rcRect.top,
         rcRect.right, rcRect.bottom, destx, desty);
     if (diagnostics_level & 2)
       wgt_log_message ("File: %s\nLine: %d\nError: %s\n", __FILE__, __LINE__, getErrorString(result));
  }
}

